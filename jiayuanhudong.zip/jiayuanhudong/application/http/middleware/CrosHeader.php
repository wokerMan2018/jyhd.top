<?php

namespace app\http\middleware;

/**
 * ajax 跨域请求中间件
 * Class CrosHeader
 * @package app\http\middleware
 */
class CrosHeader
{
    public function handle($request, \Closure $next)
    {
        // 解决 ajax 跨域问题
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
        header('Access-Control-Allow-Origin:' . $origin);//允许所有来源访问
        header('Access-Control-Allow-Method:*');//允许访问的方式
        header('Access-Control-Allow-Headers:Origin,Content-Type,Authorization,Cookie,X-CSRF-TOKEN,X-AUTH-TOKEN,X-Requested-With');//允许的header
        header('Access-Control-Allow-Credentials:true'); // 使用cookie
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            exit();
        }

        $response = $next($request);

        return $response;
    }
}
