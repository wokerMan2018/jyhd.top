<?php


namespace app\http\middleware;


use app\test\model\Auth;
use think\exception\HttpResponseException;
use think\facade\Cache;
use helper\framework\JsonResult;

class AuthMiddleware
{
    use JsonResult;
    public function handle($request, \Closure $next)
    {
        /**
         * 权限控制 中间件
         */
        $this->dataCache();
        $this->functionAuth($request);
        $response = $next($request);

        return $response;
    }
    /**
     * 权限表缓存
     */
    public function dataCache()
    {
        $data = Cache::get('auth');
        if (false === $data) {
            $auth_data = Auth::all();
            Cache::set('auth', $auth_data, 60 * 60 * 24 * 30);
        }
    }
    /**
     * 确定函数访问权限
     */
    public function functionAuth($request)
    {
        //当前访问url
        $str = $request->module() .DIRECTORY_SEPARATOR . $request->controller() . DIRECTORY_SEPARATOR . $request->action();
        if (true !== $this->check($request)) {
            $res = $this->jsonFailed('auth failed','2001');
            throw new HttpResponseException($res);
        }
    }
    /**
     * 确定是否能访问
     */
    public function check($request)
    {
        $str = $request->module() .DIRECTORY_SEPARATOR . $request->controller() . DIRECTORY_SEPARATOR . $request->action();
        $data = Cache::get('auth');
        if (false === $data ) {
            //没有缓存时
            $res = Auth::where('auth_type', $this->user->auth_type)
                ->where('module',$request->module())
                ->where('controller',$request->controller())
                ->where('action',$request->action())
                ->findOrEmpty();
            if (!$res->isEmpty()) {
                if (1 === $res['auth']) {
                    return true;
                }
            }else{
                //表中没有记录，可以访问
                return true;
            }
        }else{
            $status = false;
            $array = null;
            foreach ($data as $key => $value) {
                if (strtolower($value['module']) == $request->module() and
                    strtolower($value['controller']) == $request->controller() and
                    strtolower($value['action']) == $request->action()) {
                    $status = true;
                    $array = $value;
                }
            }
            if (false === $status) {
                //访问路由没有加入td_auth表中， 可以访问
                return true;
            }
            if (true === $status) {
                if ($array['auth_type'] == $this->user->auth_type and $array['auth'] === 1) {
                    return true;
                }
            }
        }
    }
}