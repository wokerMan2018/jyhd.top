<?php

namespace app\http\middleware;

use Exception;
use helper\framework\JsonResult;
use think\exception\HttpResponseException;
use think\exception\HttpException;

/**
 * 异常处理中间件
 * Class Error
 * @package app\http\middleware
 */
class Error
{
    use JsonResult;

    public function handle($request, \Closure $next)
    {
        // log_error('error start...', 'test-middleware');
        $is_dev_mode = env('DEVELOP_MODE');
        try {
            $response = $next($request);
        }
        catch (Exception $ex) {
            $error_code = log_error($ex);
            if($is_dev_mode) {
                throw $ex;
            }
            else {
                $module = $request->module();
                if($request->isAjax() || $module == 'api') {
                    return $this->jsonFailed('error', $error_code);
                }
                else {
                    //跳转到错误页面
                    return redirect('td/info/ex?code=' . $error_code);
                }
            }
        }
        // log_error('error end...', 'test-middleware');
        return $response;
    }
}