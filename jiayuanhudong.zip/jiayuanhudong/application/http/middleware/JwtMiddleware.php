<?php

namespace app\http\middleware;
use \Firebase\JWT\JWT;
use \Firebase\JWT\ExpiredException;
use helper\framework\JsonResult;

class JwtMiddleware
{
    use JsonResult;
    const ALG = array('HS256');
    const AUTH_HEADER = 'X-AUTH-TOKEN';

    public function handle($request, \Closure $next)
    {
        $this->clearExpireToken();
        $key = env('JWT_KEY');

        $auth = $request->header(self::AUTH_HEADER);

        if(!empty($auth)) {
            try {
                $payload = (array)JWT::decode($auth, $key, self::ALG);
            }
            catch (ExpiredException $ex) {
                return $this->jsonResult(false, null, '验证过期', 'TOKEN_EXPIRE');
            }
            // user token缓存60秒
            $userToken = db('user_token')->where('token', $payload['jti'])->find();
            if(empty($userToken)) {
                return $this->jsonResult(false, null, '验证过期', 'TOKEN_EXPIRE');
            }
            $request->jwt_payload = $payload;
        }

        $response = $next($request);

        if(!empty($request->param('jwt_payload'))) {
            $jwt = JWT::encode($request->jwt_payload, $key);
            header(self::AUTH_HEADER . ':' . $jwt);
        }
        return $response;
    }


    /**
     * 清理过期token
     * 每天只清理一次
     */
    private function clearExpireToken() {
        $today = date('Y-m-d');
        $last_clear_day = cache('last_clear_token_day', $today);
        if($today > $last_clear_day) {
            db('user_token')->where('expire_time', '<', now())->delete();
        }
    }

}

