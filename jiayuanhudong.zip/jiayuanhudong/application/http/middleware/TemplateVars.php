<?php
/**
 * Created by cheng. Time: 2018-05-21 10:53:32
 */

namespace app\http\middleware;

/**
 * 模版变量中间件
 * Class TemplateVars
 */
class TemplateVars
{
    /**
     * @param $request \think\Request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {
        $module = $request->module();
        $controller = $request->controller();
        $TD_PAGE = [
            'module' => $module,
            'controller' => $controller,
            'action' => $request->action(),
            'url' => $request->url(),
            'index_url' =>  url("$module/$controller/index"),
            'edit_url' => url("$module/$controller/edit"),
            'detail_url' => url("$module/$controller/detail"),
            'add_url' => url("$module/$controller/add"),
            'delete_url' => url("$module/$controller/delete"),
            'keyword_query' => '',
            'is_advance_query' => $request->param('is_advance_query/b', false),
        ];
        $request->TD_PAGE = $TD_PAGE;
        $response = $next($request);

        if(!$request->isAjax()) {
            $TD_PAGE = array_replace($TD_PAGE, $request->TD_PAGE ?? []);
            app('view')->assign('TD_PAGE', $TD_PAGE);
        }
        return $response;
    }
}
