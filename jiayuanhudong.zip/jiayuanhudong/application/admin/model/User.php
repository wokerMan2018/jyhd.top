<?php

namespace app\admin\model;

use think\Model;
use app\td\model\User as TdUser;

/**
 * @property string cids
 * @property integer integral
 * @property string wx_openid
 * Class User
 * @package app\admin\model
 */
class User extends TdUser
{
    protected $name='user';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];

}
