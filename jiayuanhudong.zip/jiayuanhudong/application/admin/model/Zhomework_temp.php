<?php

namespace app\admin\model;

use think\Model;
use think\model\concern\SoftDelete;

/**
 * @property mixed status
 * @property mixed id
 * Class Zhomework_temp
 * @package app\admin\model
 */
class Zhomework_temp extends Model
{
    use SoftDelete;
    protected $name='homework_temp';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
    protected $deleteTime = 'delete_time';
}
