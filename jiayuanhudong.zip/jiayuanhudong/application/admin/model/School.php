<?php

namespace app\admin\model;

use think\Model;
use think\model\concern\SoftDelete;

class School extends Model
{
    use  SoftDelete;
    protected $deleteTime = 'delete_time';
//    protected $defaultSoftDelete = 0;
    protected $name='school';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];

    public function getGrade()
    {
        return $this->hasOne('Grade','sid','id');
    }

}
