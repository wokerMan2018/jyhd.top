<?php

namespace app\admin\model;

use think\Model;

class Integconfig extends Model
{
    protected $name='integ_config';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
