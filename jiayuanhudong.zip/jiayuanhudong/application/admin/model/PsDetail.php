<?php

namespace app\admin\model;

use think\Model;

class PsDetail extends Model
{
    protected $name='ps_detail';
    protected $pk = 'id';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];

    public function spec()
    {
        return $this->belongsTo('ProductSpec', 'ps_id', 'id');
    }
}
