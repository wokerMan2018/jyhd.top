<?php

namespace app\admin\model;

use think\Model;

class Grade extends Model
{
    protected $name='grade';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];

    public function getSchool()
    {
        return $this->hasOne('School','id','sid');
    }
}
