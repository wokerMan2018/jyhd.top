<?php

namespace app\admin\model;

use think\Model;

/**
 * @property int cid
 * @property mixed status
 * Class Homework
 * @package app\admin\model
 */
class Homework extends Model
{
    protected $name='homework';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
