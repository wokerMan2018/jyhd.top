<?php

namespace app\admin\model;

use think\Model;

/**
 * @property integer stock_id
 * @property integer goods_id
 * @property integer goods_num
 * @property integer goods_skus
 * @property integer uid
 * Class Car
 * @package app\admin\model
 */
class Car extends Model
{
    protected $name='car';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
