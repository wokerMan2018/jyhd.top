<?php

namespace app\admin\model;

use think\Model;

class Regicode extends Model
{
    protected $name='regi_code';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
