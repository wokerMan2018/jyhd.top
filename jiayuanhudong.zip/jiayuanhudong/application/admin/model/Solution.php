<?php

namespace app\admin\model;

use think\Model;

/**
 * @property int id
 * @property int type
 * @property string content
 * @property string video
 * Class Solution
 * @package app\admin\model
 */
class Solution extends Model
{
    protected $name='solution';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
