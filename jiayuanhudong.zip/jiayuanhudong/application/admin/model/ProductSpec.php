<?php

namespace app\admin\model;

use think\Db;
use think\Model;

class ProductSpec extends Model
{
    protected $name='product_specifications';
    protected $pk = 'id';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];

    public function getDetail()
    {
        return $this->hasMany('PsDetail','ps_id','id');
    }
}
