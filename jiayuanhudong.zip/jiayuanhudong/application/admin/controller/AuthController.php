<?php
/**
 * Created by cheng. Time: 2018-05-21 05:22:49
 */
namespace app\admin\controller;

use app\td\model\Role;
use app\td\model\User;
use app\td\model\Balance;
use app\td\model\UserRole;

class AuthController extends BaseController {

    protected $isRequireStaff = false;

    /**
     * 用户登录
     * @return \think\response\Json|\think\response\View
     */
    public function login() {
        if($this->request->isGet()) {
            return view();
        }

        $username = $this->request->param('username');
        $pwd = $this->request->param('password');
        $user =  User::checkPassword($username, $pwd);
        if(empty($user)) {
            return $this->jsonFailed('用户名或密码不正确');
        }
        elseif (!$user->enable) {
            return $this->jsonFailed('用户已禁用');
        }
        elseif($user->is_staff != 1) {
            return $this->jsonFailed('此用户没有登录后台权限');
        }
        else {
            $this->handlerUserLogin($user);
            $redirect_url = $this->getLoginRedirectUrl($user['id']);
//            return $this->jsonSuccess(null, '登陆成功', $redirect_url);
            return $this->jsonSuccess(null, '登陆成功', '/admin/zcode/index');

        }
    }

    public function logout() {
        session('uid', null);
        return $this->redirect(url('/admin/auth/login'));
//        return $this->jsonSuccess(null, '登出成功');
    }

    /*
     * 修改管理员密码
     */
    public function change_admin_pwd() {
        $this->requireStaff();

        $old_pwd = $this->request->param('oldpassword');
        $new_pwd = $this->request->param('password');
        $user =  User::checkPassword($this->user->username, $old_pwd);
        if(empty($user)) {
            return $this->jsonFailed('旧密码输入错误');
        }
        $result = User::changePassword($this->user->username, $new_pwd);
        $message = $result ? '修改成功' : '修改失败';
        return $this->jsonResult($result, null, $message);
    }

    public function profile() {

        return $this->view();
    }

    private function getLoginRedirectUrl($uid) {
        $uid_list = UserRole::getUserRoleIds($uid);
        if(empty($uid_list)) {
            return '';
        }
        $home_page = Role::where('id', 'in', $uid_list)->where('home_page', 'not null')->value('home_page');

        if(empty($home_page)) {
            return '';
        }

        return url($home_page);
    }

    public function test() {
        $result = Balance::change(102, 333, Balance::CHANGE_TYPE_DEPOSIT);
    }
}