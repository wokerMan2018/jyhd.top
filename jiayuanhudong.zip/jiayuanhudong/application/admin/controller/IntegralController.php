<?php

namespace app\admin\controller;

use app\admin\model\Integconfig;
use think\Controller;
use think\Request;

class IntegralController extends BaseController
{
    public function integManaView()
    {
        $config = Integconfig::where('id', '<', '11')
            ->field('integ_num')
            ->select();
        $equal = $config['0']['integ_num'];
        $publishHomework = $config['1']['integ_num'];
        $reviewHomework = $config['2']['integ_num'];
        $submitAnswer = $config['3']['integ_num'];
        $login = $config['4']['integ_num'];
        $shareInfo = $config['5']['integ_num'];
        $monthCard = $config['6']['integ_num'];
        $seasonCard = $config['7']['integ_num'];
        $yearCard = $config['8']['integ_num'];
        $checkin = $config['9']['integ_num'];
        $this->assign('equal', $equal);
        $this->assign('publishHomework', $publishHomework);
        $this->assign('reviewHomework', $reviewHomework);
        $this->assign('submitAnswer', $submitAnswer);
        $this->assign('login', $login);
        $this->assign('shareInfo', $shareInfo);
        $this->assign('monthCard', $monthCard);
        $this->assign('seasonCard', $seasonCard);
        $this->assign('annualCard', $yearCard);
        $this->assign('checkin', $checkin);
        return view();
    }

    public function saveConfig()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'config1|' => 'require|integer',
                'config2|' => 'require|integer',
                'config3|' => 'require|integer',
                'config4|' => 'require|integer',
                'config5|' => 'require|integer',
                'config6|' => 'require|integer',
                'config7|' => 'require|integer',
                'config8|' => 'require|integer',
                'config9|' => 'require|integer',
                'config10|' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $config = Integconfig::where('id', 1)
                    ->findOrEmpty();
                if (!$config->isEmpty()) {
                    $update = [
                        [
                            'id' => 1,
                            'key' => 'equal',
                            'integ_num' => $post['config1'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 2,
                            'key' => 'publishHomework',
                            'integ_num' => $post['config2'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 3,
                            'key' => 'reviewHomework',
                            'integ_num' => $post['config3'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 4,
                            'key' => 'submitAnswer',
                            'integ_num' => $post['config4'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 5,
                            'key' => 'login',
                            'integ_num' => $post['config5'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 6,
                            'key' => 'shareInfo',
                            'integ_num' => $post['config6'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 7,
                            'key' => 'monthCard',
                            'integ_num' => $post['config7'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 8,
                            'key' => 'seasonCard',
                            'integ_num' => $post['config8'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 9,
                            'key' => 'yearCard',
                            'integ_num' => $post['config9'],
                            'update_time' => date('Y-m-d H:i:s')
                        ],
                        [
                            'id' => 10,
                            'key' => 'checkin',
                            'integ_num' => $post['config10'],
                            'update_time' => date('Y-m-d H:i:s')
                        ]
                    ];
                    $config = new Integconfig();
                    $bool = $config->saveAll($update);
                    if ($bool) {
                        return $this->jsonResult(true, null, '更新配置成功', '2000');
                    }

                }else{
                    $add = [
                        [
                            'key' => 'equal',
                            'operate' => '10积分等于',
                            'integ_num' => $post['config1']
                        ],
                        [
                            'key' => 'publishHomework',
                            'operate' => '教师发布作业',
                            'integ_num' => $post['config2']
                        ],
                        [
                            'key' => 'reviewHomework',
                            'operate' => '教师点评作业',
                            'integ_num' => $post['config3']
                        ],
                        [
                            'key' => 'submitAnswer',
                            'operate' => '家长提交答案',
                            'integ_num' => $post['config4']
                        ],
                        [
                            'key' => 'login',
                            'operate' => '登录',
                            'integ_num' => $post['config5']
                        ],
                        [
                            'key' => 'shareInfo',
                            'operate' => '分享资讯',
                            'integ_num' => $post['config6']
                        ],
                        [
                            'key' => 'monthCard',
                            'operate' => '月卡',
                            'integ_num' => $post['config7']
                        ],
                        [
                            'key' => 'seasonCard',
                            'operate' => '季卡',
                            'integ_num' => $post['config8']
                        ],
                        [
                            'key' => 'yearCard',
                            'operate' => '年卡',
                            'integ_num' => $post['config9']
                        ],
                        [
                            'key' => 'checkin',
                            'operate' => '签到获得积分',
                            'integ_num' => $post['config10']
                        ]
                    ];
                    $config = new Integconfig();
                    $bool = $config->saveAll($add);
                    if ($bool) {
                        return $this->jsonResult(true, null, '新增配置成功', '2000');
                    }
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
