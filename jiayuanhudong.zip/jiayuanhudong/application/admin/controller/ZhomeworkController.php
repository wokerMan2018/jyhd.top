<?php

namespace app\admin\controller;

use app\admin\model\Classes;
use app\admin\model\Grade;
use app\admin\model\Homework;
use app\admin\model\Solution;
use app\admin\model\User;
use app\admin\model\Zhomework_temp;
use think\Db;
use think\exception\DbException;
use think\facade\Request;

//use think\Request;

class ZhomeworkController extends BaseController
{
    protected $page_count = 10;

    /**
     * 作业列表视图
     * @throws DbException
     */
    public function showHomeworkList()
    {
        $param = $this->getQueryParams([], ['push_time']);
        //halt($param);
        $grades = Grade::where([])->group('graname')->column('graname');
        $this->assign('grades', $grades);


        $data = Zhomework_temp::
//        withTrashed()
//            ->
        order('create_time desc')
            ->where($param)
            ->field('id,title,gname,push_time,create_time,status')
            ->paginate($this->page_count, false);

        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }

    /**
     * 查看作业提交列表视图
     */
    public function showSolutionList()
    {
        $param = $this->getQueryParams([
            'type' => 's.type',
            'rate' => 'r.rate'
        ]);
        $data = Solution::order('s.create_time desc')
            ->alias('s')
            ->leftJoin('td_homework h', 'h.id = s.hid')
            ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
            ->leftJoin('td_remark r', 's.id = r.sid')
            ->leftJoin('td_user u', 'u.id = s.uid')
            ->leftJoin('td_school sc', 'sc.id = h.sid')
            ->leftJoin('td_grade g', 'g.id = h.gid')
            ->leftJoin('td_class c', 'c.id  = h.cid')
            ->where($param)
            ->field('s.id , ht.title , u.s_uid , sc.name, g.graname, c.gname, s.create_time, s.type, r.rate, r.content')
            ->paginate($this->page_count, false)
            ->each(function ($item, $key) {
                $student = User::where('id', $item['s_uid'])
                    ->field('username')
                    ->findOrEmpty();
                if (!$student->isEmpty()) {
                    $item['s_uid'] = $student['username'];
                }else{
                    $item['s_uid'] = '-';
                }
                return $item;
            });
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }

    public function seeSolution()
    {
        $id = Request::param('id');
        $solution = Solution::where('s.id', $id)
            ->alias('s')
            ->leftJoin('td_homework h', 'h.id = s.hid')
            ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
            ->leftJoin('td_remark r', 's.id = r.sid')
            ->leftJoin('td_user u', 'u.id = s.uid')
            ->leftJoin('td_school sc', 'sc.id = h.sid')
            ->leftJoin('td_grade g', 'g.id = h.gid')
            ->leftJoin('td_class c', 'c.id  = h.cid')
            ->field('s.id, ht.title, ht.content as homework_content , s.video, s.content, r.content as remark_content ')
            ->findOrEmpty();
        if (!empty(json_decode($solution['video'],true)[0])) {
            $solution['video'] = json_decode($solution['video'], true)[0];
        }else{
            $solution['video'] = null;
        }

        $this->assign('solution', $solution);
        return view();
    }

    /**
     * 新建作业视图
     */
    public function addHomeworkView()
    {
        $gnames = Grade::order('create_time asc')
            ->field('graname')
            ->select();
//        $gnames = gettype($gnames);
        foreach ($gnames as $value) {
            $data[] = $value['graname'];
        }
        $gnames = array_unique($data);
        $this->assign('gname', $gnames);
//        self::ReturnAjax(2000,'',$gnames);
        return view();
    }

    /**
     * 添加作业  添加作业模板为草稿或发布
     */
    public function addHomework()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'title|作业标题' => 'require',
                'gname|适用年级' => 'require',
                'text|作业内容' => 'require',
                'status|作业模板状态' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 添加作业模板为草稿或发布
            Db::startTrans();
            try {
                $add = [
                    'title' => $post['title'],
                    'gname' => $post['gname'],
                    'status' => $post['status'],
                    'content' => $post['text']
                ];
                if ($post['status'] == 2) {
                    $add['push_time'] = date('Y-m-d H:i:s', time());
                    // 每次新增一个发布的作业模板，就将这个作业模板和作业自动绑定
                } else {
                    $add['push_time'] = null;
                }
                $bool = Zhomework_temp::create($add);
                if ($bool->status == 2) {
                    // 每次新增一个发布的作业模板，就将这个作业模板和作业自动绑定
                    $classIds = Grade::order('c.create_time desc')
                        ->alias('g')
                        ->where('g.graname', trim($post['gname']))
                        ->join('td_class c', 'g.id = c.graid')
                        ->field('c.sid,c.graid,c.id')
                        ->select();
                    if (!$classIds->isEmpty()) {
                        foreach ($classIds as $key => $value) {
                            $add = [
                                'sid' => $value['sid'],
                                'gid' => $value['graid'],
                                'cid' => $value['id'],
                                'status' => 0,
                                'htid' => $bool->id
                            ];
                            $res = Homework::create($add);
                        }
                    }
                    Db::commit();
                }
                if ($bool->status == 1){
                    $classIds = Grade::order('c.create_time desc')
                        ->alias('g')
                        ->where('g.graname', trim($post['gname']))
                        ->join('td_class c', 'g.id = c.graid')
                        ->field('c.sid,c.graid,c.id')
                        ->select();
                    if (!$classIds->isEmpty()) {
                        foreach ($classIds as $key => $value) {
                            $add = [
                                'sid' => $value['sid'],
                                'gid' => $value['graid'],
                                'cid' => $value['id'],
                                'status' => 2,
                                'htid' => $bool->id
                            ];
                            $res = Homework::create($add);
                        }
                    }
                    Db::commit();
                }
                if (!$bool->isEmpty()) {
                    self::ReturnAjax(2000, '添加作业成功');
                }
            } catch (\Exception $e) {
                throw $e;
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    /**
     * 编辑作业视图
     */
    public function editView()
    {
        $id = Request::param('id');
        if ($id) {
            $homework = Zhomework_temp::withTrashed()->get($id);
            $this->assign('homework', $homework);
        }
        $gnames = Grade::order('create_time asc')
            ->field('graname')
            ->select();
//        $gnames = gettype($gnames);
        foreach ($gnames as $value) {
            $data[] = $value['graname'];
        }
        $gnames = array_unique($data);
        $this->assign('gname', $gnames);
        return view();
    }

    /**
     * 编辑作业
     */
    public function edit()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|作业模板id' => 'require',
                'title|作业标题' => 'require',
                'gname|适用年级' => 'require',
                'text|作业内容' => 'require',
                'status|作业模板状态' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 编辑作业
            Db::startTrans();
            try {
                $homework = Zhomework_temp::get($post['id']);
                $homework->title = $post['title'];
                $homework->gname = $post['gname'];
                $homework->content = $post['text'];
                $homework->status = $post['status'];
                if ($post['status'] == 2) {
                    $homework->push_time = date('Y-m-d H:i:s', time());
                } else {
                    $homework->push_time = null;
                }
                $bool = $homework->save();
                if ($homework->status == 2) {
                    //2 为作业模板发布状态
                    Homework::where('htid', $homework->id)
                        ->update([
                            'status' => 0
                        ]);
                    Db::commit();
                }
                if ($homework->status == 1) {
                    //1 为作业模板 草稿状态
                    Homework::where('htid', $homework->id)
                        ->update([
                            'status' => 2
                        ]);
                    Db::commit();
                }
                if ($bool) {
                    self::ReturnAjax(2000, '编辑成功');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    /**
     * 撤回作业模板
     */
    public function withdraw()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|作业模板id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 撤回模板
            Db::startTrans();
            try {
                $homework = Zhomework_temp::get($post['id']);
                $homework->status = 1;
                $homework->push_time = null;
                $bool = $homework->save();
                Homework::where('htid', $homework->id)
                    ->update([
                        'status' => 2
                    ]);
                Db::commit();
                if ($bool) {
                    self::ReturnAjax(2000, '撤回成功');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }

        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }

    }

    /**
     * 删除作业模板
     * @return \think\response\Json|void
     */
    public function delete()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|作业模板id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            // 删除模板
            Db::startTrans();
            try {
                $temp = Zhomework_temp::get($post['id']);
                $temp->status = 3;
                $temp->save();
                $result = Zhomework_temp::destroy($post['id']);
                Homework::destroy(function ($query) use ($post) {
                    $query->where('htid', trim($post['id']));
                });
                Db::commit();
                if ($result) {
                    self::ReturnAjax(2000, '删除作业成功', $result);
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }

    }

    public function deleteAll()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'ids|id集合' => 'require',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            Db::startTrans();
            try {
                $ids = explode(',', $post['ids']);
                foreach ($ids as $id) {
                    Zhomework_temp::destroy($id);
                    Homework::destroy(function ($query) use ($id) {
                        $query->where('htid', trim($id));
                    });
                }
                Db::commit();
                self::ReturnAjax(2000, '删除成功');
            } catch (DbException $e) {
                Db::rollback();
                self::ReturnAjax(2001, 'server error');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }


}
