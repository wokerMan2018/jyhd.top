<?php

namespace app\admin\controller;

use app\td\model\UserRole;
use app\td\TdController;
use app\td\model\Menu;
use app\td\model\User;
use app\td\model\Config;
use think\Db;

class BaseController extends TdController
{

    protected $model;

    /**
     * 强制登录验证标记
     * @var bool
     */
    protected $isRequireStaff = true;

    /**
     * 需要登录认证的方法
     * @var array
     */
    protected $exceptAuthActions = ['test'];

    /**
     * 严格验证模式，不在角色菜单配置都不通过验证
     * @var boolean
     */
    protected $strictAuthMode = false;

    /**
     * 重写action激活的菜单
     * @var array  ['action' => 'module/controller/action']
     */
    protected $actionActiveMenuMap = [];


    /**
     * 初始化方法
     */
    protected function initialize()
    {
        parent::initialize();
        $this->initUser();
        $this->requireStaff();
        $this->initMenu();
        $this->initAdminConfig();
    }

    /**
     * 初始化菜单
     */
    private function initMenu() {
        //$cur_url = $this->request->url();
        $module = $this->request->module();
        $controller = $this->request->controller();
        $action = $this->request->action();

        $cur_url = url("$module/$controller/$action");
        $cur_url = !array_key_exists($action, $this->actionActiveMenuMap) ? $cur_url : url($this->actionActiveMenuMap[$action]);

        $menuTree = Menu::getTCache($this->uid);
        if(empty($menuTree)) {
            $menuTree = Menu::getMenuTree('admin', $this->uid);
            Menu::setTCache($this->uid, $menuTree);
        }

        foreach ($menuTree as $key => &$val) {
            $has_sub_active = false;
            if ($val['children']) {
                foreach ($val['children'] as $sk => &$sval) {

                    $menu_active = $cur_url == $sval['ext_url'];
                    if ($menu_active) {
                        $has_sub_active = true;
                    }
                    $sval['active_class'] = $menu_active ? 'active' : '';
                }
                unset($sval);
            }
            $val['active_class'] = $has_sub_active ? 'active menu-open' : '';
        }
        unset($val);

        $this->assign('menuTree', $menuTree);
    }

    /**
     * 登录验证
     */
    protected function requireLogin() {
        if(in_array($this->request->action(), $this->exceptAuthActions)) {
            return;
        }
        if(empty($this->uid)) {
            $this->redirect('admin/auth/login');
        }
    }

    /**
     * 判断是否能后台登录
     */
    protected function requireStaff() {
        if(in_array($this->request->action(), $this->exceptAuthActions)) {
            return;
        }
        if(!$this->isRequireStaff) {
            return;
        }

        if(empty($this->user) || $this->user->is_staff != 1) {
            $this->redirect('admin/auth/login');
        }
    }

    protected function initAdminConfig() {
        $config = Config::where('grouping', 'admin')->order(['grouping' => 'desc', 'sorting' => 'desc'])->column('val', 'key');
        $this->assign('ADMIN_CONFIG', $config);
    }

    /**
     * 权限验证
     * @param string $url module/controller/action 默认为空
     */
    protected function checkAuth($url='') {
        if(in_array($this->request->action(), $this->exceptAuthActions)) {
            return;
        }
        if(User::isAdmin($this->uid)) {
            return;
        }
        $module = $this->request->module();
        $controller = $this->request->controller();
        $action = $this->request->action();
        if(array_key_exists($action, $this->actionActiveMenuMap)) {
            $new_url = $this->actionActiveMenuMap[$action];
            $url_info = explode('/', $new_url);
            if(count($url_info) != 3) {
                exit('error actionActiveMenuMap');
            }
            list($module, $controller, $action) = $url_info;
        }
        $q = Db::name('menu')->alias('m')
            ->join('role_menu rm', 'm.id=rm.menu_id')
            ->join('role r', 'rm.role_id=r.id');
        $exist_role = $q->where('m.module', $module)
            ->where('m.controller', $controller)
            ->where('m.action', $action)
            ->where('r.role_id', 'in', UserRole::getUserRoleIds($this->uid))->find();

        if($this->strictAuthMode) {
            if(empty($exist_role)) {
                $this->requireAuthException();
            }
        }
        else {
            if(empty($exist_role)) {
                $menu = Db::name('menu')->alias('m')->where('m.module', $module)
                    ->where('m.controller', $controller)
                    ->where('m.action', $action)->find();
                if(!empty($menu)) {
                    $this->requireAuthException();
                }
            }
        }
    }

    protected function requireAuthException() {
        $res = [
            'success' => false,
            'data' => null,
            'message' => '权限不够',
            'error_code' => 'REQUIRE_AUTH'
        ];
        header('Content-Type:application/json; charset=utf-8');
        echo json_encode($res);
        die();
    }
    /*
     * @purpose   自定义ajax返回函数
     * @author drzhong2015@gmail.com
     * @date  2019/4/29 14:22
     * @access  public
     * @param
     * @return
     */
    public function ReturnAjax($code, $msg, &$array=null)
    {
        if(empty($code)) {
            $return_array= ['code' => 200,'data' => $array, 'msg' => '获取数据成功','time' => time()];
        }else{
            $return_array = ['code' => $code,'data' => $array,'msg' =>$msg,'time' => time()];
        }
        header('Content-type:text/json');
        header("Access-Control-Allow-Origin: *");
        echo json_encode($return_array,JSON_UNESCAPED_UNICODE);die;
    }

    /**
     * 列表页面
     */
    protected function index() {

    }

    /**
     * 按id查询
     * @param $id int
     */
    protected function detail($id) {

    }

    /**
     * 新增
     */
    protected function add() {

    }

    /*
     * 修改
     */
    protected function edit() {

    }

    /*
     * 删除
     */
    protected function delete() {
        if($this->model == null) {
            return $this->jsonFailed('$this->model未赋值');
        }
        $id = $this->request->param('id');
        $idList = explode(',', $id);
        if(empty($idList)) {
            return $this->jsonFailed('删除失败, id参数错误');
        }
        else {
            $result = $this->model->destroy($idList);
            if(!$result) {
                return $this->jsonFailed('删除失败');
            }
            else {
                return $this->jsonSuccess('删除成功');
            }
        }
    }

}