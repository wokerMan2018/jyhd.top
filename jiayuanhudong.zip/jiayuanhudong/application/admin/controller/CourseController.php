<?php

namespace app\admin\controller;

use app\admin\model\CourseClassification;
use app\admin\model\Video;
use app\api\model\CourseComments;
use app\common\library\storage\engine\Qiniu;
use function GuzzleHttp\Promise\all;
use helper\QinNiu;
use helper\UuidHelper;
use phpDocumentor\Reflection\Types\This;
use Qiniu\Storage\UploadManager;
use think\Controller;
use think\Db;
use think\exception\DbException;
use think\Request;

class CourseController extends BaseController
{
    /**
     * 课程视频列表视图
     */
    public function index()
    {
        $param = $this->getQueryParams();
        $data = Video::where($param)
            ->field('id, title, upload_type, video_url, like_num, video_introduction, create_time')
            ->order('create_time DESC')
            ->paginate(10, false);
        $page = $data->render();
        $this->assign('page', $page);
        $this->assign('dataList', $data);
        return view();
    }

    /**
     * 新增课程视图
     */
    public function addView()
    {
        $all = CourseClassification::all();
        $this->assign('tracla', $all);
        return view();
    }
    public static $MAX_FILE_SIZE = 1024 * 1024 * 100; // 100M
    public static $ALLOW_FILE_EXT = [
        "mp4", "webm"
    ];
    /**
     * 新增课程操作
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'articleTitle' => 'require',
                'upload_type' => 'require',
                'video_introduction' => 'require',
                'video_url' => 'url',
                'thumb' => 'require|url'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 七牛云上传文件 并写入video表数据
                 */
                if (false) {
//                if ($post['upload_type'] === '1' and $this->request->has('uploadvideo', 'file')) {
                    $file = $this->request->file('uploadvideo');
                    $fileName = UuidHelper::generate()->string . '.' . $file->getExtension();
                    $filePath = $file->getInfo()['tmp_name'];
                    $qiniu = new QinNiu();
                    $token = $qiniu->getUploadToken($fileName);
                    $uploadMgr = new UploadManager();
                    list($response , $err) = $uploadMgr->putFile($token, $fileName, $filePath);//数组
                    if ($err !== null) {
                        return $this->jsonFailed('七牛云上传错误', '2001');
                    }else{
                        $file_path = env('QINIU_URL') . '/' . $response['key'];
                    }
                }else{
                    $file_path = trim($post['video_url']);
                }
                $result = Video::create([
                    'title' => $post['articleTitle'],
                    'upload_type' => $post['upload_type'],
                    'video_introduction' => $post['video_introduction'],
                    'video_url' => $file_path,
                    'watch_num' => 0,
                    'like_num' => 0,
                    'comment_num' => 0,
                    'thumb' => $post['thumb'],
                    'cc_id' => $post['cc_id']
                ]);
                if (!$result->isEmpty()) {
                    return $this->jsonResult(true, null, '添加成功', '2000');
                }else{
                    return $this->jsonFailed('添加失败', '2001');
                }
            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 编辑视图
     */
    public function editView()
    {
        if ($this->request->has('id', 'param')) {
            $all = CourseClassification::all();
            $this->assign('tracla', $all);
            $id = $this->request->param('id');
            $video = Video::where('id', $id)
                ->findOrEmpty();
            $this->assign('item', $video);
            return view();
        }
        $this->redirect('/admin/Course/index');
    }
    /**
     * 编辑操作
     */
    public function edit()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer',
                'articleTitle' => 'require',
                'upload_type' => 'require',
                'video_introduction' => 'require',
                'video_url' => 'url',
                'thumb' => 'require|url'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 七牛云上传文件 并写入video表数据
                 */
                if(false) {
//                if ($post['upload_type'] === '1' and $this->request->has('uploadvideo', 'file')) {
                    $file = $this->request->file('uploadvideo');
                    $fileName = UuidHelper::generate()->string . '.' . $file->getExtension();
                    $filePath = $file->getInfo()['tmp_name'];
                    $qiniu = new QinNiu();
                    $token = $qiniu->getUploadToken($fileName);
                    $uploadMgr = new UploadManager();
                    list($response , $err) = $uploadMgr->putFile($token, $fileName, $filePath);//数组
                    if ($err !== null) {
                        return $this->jsonFailed('七牛云上传错误', '2001');
                    }else{
                        $file_path = env('QINIU_URL') . '/' . $response['key'];
                    }
                }else{
                    $file_path = trim($post['video_url']);
                }
                $video = Video::get($post['id']);
                $video->title = $post['articleTitle'];
                $video->upload_type = $post['upload_type'];
                $video->video_introduction = $post['video_introduction'];
                $video->video_url = $file_path;
                $video->thumb = $post['thumb'];
                $video->cc_id = $post['cc_id'];
                $bool = $video->save();
                if (false !== $bool) {
                    return $this->jsonResult(true, null, '修改成功', '2000');
                }else{
                    return $this->jsonFailed('修改失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('server error', '2001');
            }

        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 删除记录操作
     */
    public function del()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $bool = Video::destroy($post['id']);
                if ($bool) {
                    return $this->jsonResult(true, null, '删除成功', '2000');
                }else{
                    return $this->jsonFailed('删除失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 批量删除
     */
    public function delAll()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'ids|id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 批量删除
                 */
                Db::startTrans();
                try {
                    $ids = explode(',', $post['ids']);
                    foreach ($ids as $id) {
                        Video::destroy($id);
                    }
                    Db::commit();
                    return $this->jsonResult(true, null, '删除成功', '2000');
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 新增课程辅助分类视图
     */
    public function addCourseClassificationView()
    {
        return view();
    }
    /**
     * 新增课程辅助分类
     */
    public function addCourseClassification()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'title|课程辅助分类' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            $result = CourseClassification::create([
                'type_name' => $post['title']
            ]);
            $result->type = $result->id;
            $result->save();
            if (!$result->isEmpty()) {
                return $this->jsonResult(true, null, '添加成功', '2000');
            }else{
                return $this->jsonFailed('添加失败', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 课程分类列表视图
     * @return \think\response\View
     * @throws DbException
     */
    public function course_class_list()
    {
        $data = CourseClassification::field('id, type_name, create_time')
            ->paginate($this->page_count, false);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }

    /**
     * 删除课程分类操作
     * @return \think\response\Json
     */
    public function del_course_class()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|课程分类id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                /**
                 * 删除课程分类和分类下的视频
                 */
                CourseClassification::destroy($post['id']);
                Video::destroy(function ($query) use ($post) {
                    $query->where('cc_id', $post['id']);
                });
                Db::commit();
                return $this->jsonResult(true, null, '删除成功', '2000');
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 课程评论列表
     */
    public function comment_list()
    {
        $param = $this->getQueryParams([
            'status' => 'cc.status'
        ]);
        $data = CourseComments::order('cc.create_time', 'desc')
            ->where($param)
            ->alias('cc')
            ->leftJoin('td_video v', 'cc.video_id = v.id')
            ->leftJoin('td_user u', 'cc.uid = u.id')
            ->field('cc.id, v.title, cc.create_time, u.username, cc.content, cc.status')
            ->paginate($this->page_count, false);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }
    /**
     * 课程评论通过
     */
    public function pass()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|课程评论id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 通过评论
                 */
                $courseComment = CourseComments::where('id', $post['id'])
                    ->findOrEmpty();
                if ($courseComment->isEmpty()) {
                    return $this->jsonFailed('没有该评论', '2001');
                }
                $courseComment->status = 2;
                $result = $courseComment->save();
                if ($result) {
                    return $this->jsonResult(true, null, '通过成功', '2000');
                }else{
                    return $this->jsonFailed('通过失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 课程评论批量通过
     */
    public function pass_all()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'ids|课程评论id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $ids = explode(',', $post['ids']);
                foreach ($ids as $id) {
                    $cc = CourseComments::get($id);
                    $cc->status = 2;
                    $cc->save();
                }
                Db::commit();
                return $this->jsonResult(true, null, '通过成功', '2000');
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 删除评论
     */
    public function delete()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|课程评论id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 删除评论
                 */
                $result = CourseComments::destroy($post['id']);
                if ($result) {
                    return $this->jsonResult(true, null, '删除成功', '2000');
                }else{
                    return $this->jsonFailed('删除失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
