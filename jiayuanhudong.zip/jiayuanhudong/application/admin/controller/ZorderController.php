<?php

namespace app\admin\controller;

use app\admin\model\Goods;
use app\admin\model\ProductSpec;
use app\admin\model\PsDetail;
use app\admin\model\Stock;
use app\api\model\Notice;
use app\api\model\Order;
use app\api\model\OrderGoods;
use Hashids\Hashids;
use helper\QinNiu;
use helper\UuidHelper;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Qiniu\Storage\UploadManager;
use think\Controller;
use think\Db;
use think\facade\Log;
use think\Request;
use think\exception\DbException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ZorderController extends BaseController
{
    /**
     * 商城订单 - 列表视图
     */
    public function showOrderList()
    {
        $param = $this->getQueryParams([
            'status' => 'o.order_status'
        ]);

        $data = Db::name('order')->where($param)
            ->alias('o')
            ->order('o.update_time DESC')
//            ->leftJoin('td_order_goods og', 'o.id = og.oid')
            ->leftJoin('td_user u', 'u.id = o.uid')
            ->field('o.id, o.order_num,o.order_status, u.username,o.create_time, o.pay_time, o.id as goodsName, o.total_price, o.reduce_integral , o.tracking_number')
            ->paginate(10, false)
            ->each(function ($item, $key) {
                $order_goods = OrderGoods::where('oid', $item['goodsName'])
                    ->field('gname')
                    ->select();
                if (!$order_goods->isEmpty()) {
                    $item['goodsName'] = '';
                    foreach ($order_goods as $key => $value) {
                        $item['goodsName'] .= $value['gname'] . "  ";
                    }
                }else{
                    $item['goodsName'] = '';
                }
//                $arr = ['0'=> '已取消','10'=> '待付款','20'=> '已付款','30'=> '已发货','40'=> '已收货'];
//                $item['order_status'] = $arr[$item['order_status']];
                return $item;
            });
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }
    /**
     * 已支付的订单添加运单号视图 废弃
     */
    public function trackingNumberView()
    {
        return view();
    }
    /**
     * 已支付订单添加运单号
     */
    public function trackingNumber()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'oid|订单id' => 'require|integer',
                'tracking_number|运单号' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //补充该订单的运单号信息
            Db::startTrans();
            try {
                $order = Order::get($post['oid']);
                $order->tracking_number = $post['tracking_number'];
                $order->order_status = 30;
                $bool = $order->save();
                /**
                 * 写入商品已发货 站内信 消息类型 2
                 */
                $order_goods = OrderGoods::where('oid', $order->id)
                    ->field('gname')
                    ->select();
                $goods_name = '';
                foreach ($order_goods as $goods) {
                    $goods_name .= $goods['gname'];
                }
                $notice = Notice::create([
                    'uid' => $order->uid,
                    'nt_id' => 2,
                    'message' => '您购买的' . $goods_name . '已发货！',
                    'status' => 2
                ]);
                Db::commit();
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
            if ($bool) {
                self::ReturnAjax(2000, '运单号保存成功');
            }else{
                self::ReturnAjax(2001, '运单号保存失败');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    /**
     * 收入统计视图  废弃
     */
    public function incomeStatistics()
    {
        return view();
    }

    /**
     * 出售中的商品列表视图
     */
    public function showUpGoodsList()
    {
        $param = $this->getQueryParams([
            'gc_id' => 'g.gc_id'
        ]);
        // 查询出下架商品列表所需字段数据
        //序号 商品名称 商品分类 价格 总库存 总销量
        $data = Db::name('goods')
            ->alias('g')
            ->where($param)
            ->where('g.status', 1)
            ->field('g.id,g.gc_id,g.status,g.gimages,g.gname,s.skus,s.stock,s.price,s.specs, g.sales_volume')
            ->order('g.create_time desc')
            ->join('stock s', 'g.id = s.gid')
            ->paginate(10, false)
            ->each(function ($item, $key) {
                $item['gname'] = $item['gname'] . ' ' .$item['specs'] ;
                return $item;
            });
//        $this->ReturnAjax(2000, '', $data);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
//        self::ReturnAjax(2000, '', $data);
        return view();
    }
    /**
     * 上架商品
     */
    public function up()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|商品id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                $result = Db::name('goods')
                    ->where(['id' => $post['id']])
                    ->update(['status' => 1]);
                if ($result) {
                    return $this->jsonResult(true, null, '上架成功', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }
    /**
     * 批量上架商品
     */
    public function upAll()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'ids|商品id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                //TODO 批量上架商品
                $arr = explode(',', $post['ids']);
                $goods = new Goods;
                if ($arr) {
                    foreach ($arr as $id) {
                        $data[] = ['id' => $id,'status'=>1];
                    }
                    $result = $goods->saveAll($data);
                    if (!$result->isEmpty()) {
                        return $this->jsonResult(true, null, '批量上架成功', '2000');
                    }
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }
    /**
     * 上架商品
     */
    public function down()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|商品id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                $result = Db::name('goods')
                    ->where(['id' => $post['id']])
                    ->update(['status' => 2]);
                if ($result) {
                    return $this->jsonResult(true, null, '下架成功', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }
    /**
     * 批量下架商品
     */
    public function downAll()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'ids|商品id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                //TODO 批量下架商品
                $arr = explode(',', $post['ids']);
                $goods = new Goods;
                if ($arr) {
                    foreach ($arr as $id) {
                        $data[] = ['id' => $id,'status'=>2];
                    }
                    $result = $goods->saveAll($data);
                    if (!$result->isEmpty()) {
                        return $this->jsonResult(true, null, '批量下架成功', '2000');
                    }
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }
    /**
     * 修改商品信息视图
     */
    public function editGoodsView()
    {
        $id = $this->request->param('id');
        $info = Goods::where(['g.id' => $id])
            ->alias('g')
            ->field('g.gc_id,g.status,g.gimages,g.gname,g.gdetail,s.price,s.stock')
            ->join('td_stock s','g.id = s.gid')
            ->find();
        $this->assign('info', $info);
//        self::ReturnAjax(2000, '', $info);
        return view();
    }
    /**
     * 编辑商品信息
     */
    public function editGoods()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
//            dump($post);die;
            $rule = [
                'id|商品id' => 'require',
                'gc_id|商品类别' => 'require',
                'gname|商品名称' => 'require',
                'text|商品详情' => 'require',
                'goodsImgs|商品图片' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                $path = upload_photofix('goodsImgs');
                Db::startTrans();
                try {
                    $goods = Goods::get($post['id']);
                    $goods->gname = $post['gname'];
                    $goods->gdetail = $post['text'];
                    $goods->gimages = $path;
                    $result = $goods->save();
                    if ($result) {
                        if ($post['gc_id'] == 2) {
                            /**
                             * 更新虚拟商品的排序价格
                             */
                            $goods->price = $post['price'];
                            $goods->save();
                            //虚拟商品价格修改
                            $upda = Db::name('stock')
                                ->where(['gid' => $post['id']])
                                ->update([
                                    'price' => $post['price'],
                                    'update_time' => date('Y-m-d H:i:s', time())
                                ]);
                            Db::commit();
                            if ($upda) {
                                return $this->jsonResult(true, null, '保存修改成功', '2000');
                            }

                        }else{
                            Db::commit();
                            return $this->jsonResult(true, null, '保存修改成功', '2000');
                        }

                    }
                } catch (DbException $exception) {
                    Db::rollback();
                    return null;
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }

    }
    /**
     * 编辑实物商品规格信息视图
     */
    public function editGoodsSpecView()
    {
        $id = $this->request->param('id');
        if ($id) {
            $data = ProductSpec::with('getDetail')
                ->hidden([
                    'create_time',
                    'update_time',
                    'get_detail' => [
                        'gid',
                        'ps_id',
                        'create_time',
                        'update_time',
                        'id',
                        'sku'
                    ]
                ])
                ->where(['gid' => $id])
                ->select();
            foreach ($data as $key => $value) {
                foreach ($value['get_detail'] as $kkey => $vvalue) {
                    $arr[] = $vvalue['detail'];
                }
                $array[] = implode('，', $arr);
                $arr = [];
            }
        }
        $this->assign('info', $data);
        $this->assign('guige', $array);
//        self::ReturnAjax(2000, '', $data);
        return view();
    }
    /**
     * 编辑实物商品规格信息
     */
    public function editGoodsSpec()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
//            self::ReturnAjax(2000, '', $post);
            $rule = [
                'id|商品id' => 'require',
                'ps_detail|商品规格名称'=>'require',
                'ps_name|商品规格详情' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                //TODO 修改实物商品的规格详情
                //step 1
                Db::startTrans();
                try {
                    $result = ProductSpec::destroy(function ($query) use($post) {
                        $query->where(['gid' => $post['id']]);
                    });
                    if ($result) {
                        $bool = PsDetail::destroy(function ($query) use ($post) {
                            $query->where(['gid' => $post['id']]);
                        });
//                        Db::commit();
                        if ($bool) {
                            foreach ($post['ps_name'] as $key => $value) {
                                $ps_id = Db::name('product_specifications')
                                    ->insertGetId([
                                        'gid' => $post['id'],
                                        'ps_type' => $key,
                                        'ps_name' => $value,
                                        'create_time' => date('Y-m-d H:i:s', time()),
                                        'update_time' => date('Y-m-d H:i:s', time())
                                    ]);
                                $psd = explode('，', $post['ps_detail'][$key]);
                                $zCode = new ZcodeController();
                                foreach ($psd as $kkey => $vvalue) {
                                    $bool = Db::name('ps_detail')
                                        ->insertGetId([
                                            'gid' => $post['id'],
                                            'ps_id' => $ps_id,
                                            'detail' => $vvalue,
                                            'sku' => $zCode->randcode(8),
                                            'create_time' => date('Y-m-d H:i:s', time()),
                                            'update_time' => date('Y-m-d H:i:s', time())
                                        ]);
                                }
//                                Db::commit();

                            }
                            Db::commit();
                            return $this->jsonResult(true, null, '保存修改成功', '2000');
                        }

                    }
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', 5000);
                }



                
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }

    /**
     * 编辑实物商品价格和库存
     */
    public function editGoodsPriceView()
    {
        return view();
    }

    /**
     * 下架商品列表
     */
    public function showDownGoodsList()
    {
        $param = $this->getQueryParams([
            'gc_id' => 'g.gc_id'
        ]);
        // 查询出下架商品列表所需字段数据
        //序号 商品名称 商品分类 价格 总库存 总销量
        $data = Db::name('goods')
            ->alias('g')
            ->where('g.status',2)
            ->where($param)
            ->field('g.id,g.gc_id,g.status,g.gimages,g.gname,s.skus,s.stock,s.price,s.specs, g.sales_volume')
            ->order('g.create_time desc')
            ->join('stock s', 'g.id = s.gid')
            ->paginate(10, false)
            ->each(function ($item, $key) {
                $item['gname'] = $item['gname'] . ' ' .$item['specs'] ;
                return $item;
            });
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
//        self::ReturnAjax(2000, '', $data);
        return view();
    }

    /**
     * 添加商品视图
     */
    public function addGoodsView()
    {
        $cates = Db::name('goods_cate')
            ->where(['status' => 1])
            ->field('id,cate_name,status,cate_type')
            ->order('id desc')
            ->select();
        $this->assign('types', $cates);
//        self::ReturnAjax(2000, '', $cates);
        return view();
    }
    /**
     * 生成兑换码excel模板
     */
    public function getExcel()
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', '序号');
        $sheet->setCellValue('B1', '激活码');

        $writer = new Xlsx($spreadsheet);
//        $writer->save('hello world.xlsx');
        header('Pragma: public');
        header('Expires: 0');
        header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
        header('Content-Type:application/force-download');
        header('Content-Type:application/vnd.ms-execl');
        header('Content-Type:application/octet-stream');
        header('Content-Type:application/download');
        header("Content-Disposition:attachment;filename=兑换码模板.xlsx");
        header('Content-Transfer-Encoding:binary');
        $writer->save('php://output');
        exit;
    }


    /**
     * 添加商品  (没有添加实物商品的库存和价格)
     */
    public function addGoods()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
//            dump($post);
//            die;
            $rule = [
                'type|商品类型' => 'require',
                'gname|商品名称' => 'require',
                'text|商品介绍' => 'require',
                'goodsImgs|商品图片' => 'require',
            ];
            /**
             * type 1为实物商品 2为虚拟商品
             */
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 图片保存到本地
                 */
                $path = upload_photofix('goodsImgs');
//                /**
//                 * 图片保存在七牛云
//                 */
//                $file = $this->request->file('goodsImgs');
//                $fileName = $file->validate(['size' => self::$MAX_FILE_SIZE,'ext'=> implode(',', self::$ALLOW_FILE_EXT) ])->getInfo()['name'];
//                $extension = $file->getExtension();
//                $fileName = UuidHelper::generate()->string . '.' . $extension;
//                $filePath = $file->getInfo()['tmp_name'];
//                $qiniu = new QinNiu();
////                $token = $qiniu->get_upload_token();
//                $token = $qiniu->getUploadToken($fileName);
////                $response = self::uploadVideo($token, $file, $fileName);
//                // 初始化 UploadManager 对象并进行文件的上传。
//                $uploadMgr = new UploadManager();
//                // 调用 UploadManager 的 putFile 方法进行文件的上传。
//                list($response , $err) = $uploadMgr->putFile($token, $fileName, $filePath);//数组
//                $path =env('QINIU_URL') .'/'. $response['key'];

                Db::startTrans();
                try {
                    $goodsId = Db::name('goods_cate')
                        ->field('id')
                        ->where(['cate_type' => $post['type'], 'status' => 1])
                        ->find();
                    //TODO 通过导入的excel计算虚拟商品库存
                    if ($goodsId) {
                        $add = [
                            'gc_id' => $goodsId['id'],
                            'status' => $post['status'],
                            'gimages' => $path,
                            'gname' => $post['gname'],
                            'gdetail' => $post['text'],
                        ];
                        $result = Goods::create($add);
                        if ($post['type'] == 2) {
                            //虚拟商品
                            //TODO 计算虚拟商品库存 并将cdkey入库
                            /**
                             * 写入虚拟商品排序价格
                             */
                            $result->price = $post['price'];
                            $result->save();
                            $file = $this->request->file('duihuanma');
                            if ($file) {
                                if (!file_exists("uploads/")){
                                    mkdir("uploads/");
                                }
                                $info = $file->move('uploads/');
                                if (!$info) {
                                    $this->jsonFailed('文件上传错误', '5000');
                                }else{
                                    $path = str_replace('\\','/',UPLOAD_DIR . '/'.$info->getSaveName(),$i);
                                }
                                $sheet = IOFactory::load($path);
                                $sheetData = $sheet->getActiveSheet()->toArray(null, true, true, true);
                                unset($sheetData['1']);
                                try {
                                    foreach ($sheetData as $key => $value) {
                                        $addKey = [
                                            'gid' => $result->id,
                                            'cdkey' => $value['B'],
                                            'serial' => $value['A'],
                                            'status' => 1,
                                            'create_time' => date('Y-m-d H:i:s', time()),
                                            'update_time' => date('Y-m-d H:i:s', time())
                                        ];
                                        Db::name('cdkey')
                                            ->insert($addKey);

                                    }
                                    Db::commit();
                                } catch (DbException $e) {
                                    Db::rollback();
                                    return $this->jsonFailed('server error', 5000);
                                }
                            }
//                            $add['virtual_product_stock'] = count($sheetData) -1 ;
//                            $add['gprice'] = $post['price'];
                            //废弃goods表的virtual_product_stock和gprice字段
                            // 改为在stock表中增加一条记录
                            $stock_id = Db::name('stock')
                                ->insertGetId([
                                    'gid'=>$result->id,
                                    'stock'=>count($sheetData),
                                    'price' => $post['price'],
                                    'create_time' => date('Y-m-d H:i:s', time()),
                                    'update_time' => date('Y-m-d H:i:s', time())
                                ]);
                        }

//                        Db::commit();
                        if ($gid = $result->id) {
                            if ($post['type'] == 1) {
                                //实物商品
                                $guige = json_decode($post['guige']);
                                try {
                                    foreach ($guige as $key => $value) {
                                        $add_ps = [
                                            'gid' => $gid,
                                            'ps_type' => $key,
                                            'ps_name' => $value->ps_name,
                                            'create_time' => date('Y-m-d H:i:s', time()),
                                            'update_time' => date('Y-m-d H:i:s', time())
                                        ];
                                        $ps = Db::name('product_specifications')
                                            ->insertGetId($add_ps);
                                        Db::commit();
                                        $ps_detail = explode('，', $value->ps_detail);
                                        $zCode = new ZcodeController();

                                        try {
                                            foreach ($ps_detail as $kkey => $vvalue) {
                                                $code = $zCode->randcode(8);

                                                $add_ps_detail = [
                                                    'gid' => $gid,
                                                    'ps_id' => $ps,
                                                    'detail' => $vvalue,
                                                    'sku' => $code,
                                                    'create_time' => date('Y-m-d H:i:s', time()),
                                                    'update_time' => date('Y-m-d H:i:s', time())
                                                ];
                                                $ps_detail_id = Db::name('ps_detail')
                                                    ->insertGetId($add_ps_detail);
                                            }
                                        } catch (DbException $e) {
                                            Db::rollback();
                                            return $this->jsonFailed('server error', 5000);
                                        }
                                    }
                                } catch (DbException $e) {
                                    Db::rollback();
                                    return $this->jsonFailed('server error', 5000);
                                }
                            }
                        }
                        if ($result) {
                            return $this->jsonResult(true,['goods_type' =>$post['type'],'goods_id'=> $result->id],'添加商品成功','2000');
                        }
                    }
                } catch (DbException $e) {
//                    Db::rollback();
                    return $this->jsonFailed('server error', 5000);
                }


            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求类型错误', 4003);
        }
    }

    /**
     * hashids 编码
     */
    public static function encode($id)
    {
        $hashids = new Hashids('td',6);
        $code = $hashids->encode($id);
        return $code;
    }
    /**
     * hashids 解码
     */
    public static function decode($code)
    {
        $hashids = new Hashids('td', 6);
        $inviteID = $hashids->decode($code);
        if (!$inviteID) {
            return [];
        }
        return $inviteID;
    }
    /**
     * 点击添加库存与价格按钮
     */
    public function button()
    {
        if ($this->request->isPost()){
            $isAjax = $this->request->param('isAjax');
            if (1 == $isAjax) {
                //查询属性详情
//        $guige = Db::name('product_specifications')
//            ->order('psd.create_time desc')
//            ->alias('ps')
//            ->field('ps.ps_name,psd.id,psd.ps_id,psd.detail,psd.sku')
//            ->where(['ps.gid' => $id])
//            ->join('td_ps_detail psd', 'ps.id = psd.ps_id')
//            ->select();
                $id = $this->request->param('id');
                $ids = ProductSpec::where(['gid' => $id])
                    ->order('create_time asc')
                    ->field('id,ps_name')
                    ->select();
                $data = [];
                foreach ($ids as $key => $value) {
                    $data[$key]['ps_name'] = $value['ps_name'];
                    $data[$key]['detail'] = Db::name('ps_detail')
                        ->order('create_time asc')
                        ->hidden('create_time,update_time')
                        ->where(['ps_id' => $value['id']])
                        ->select();
                }
                //        foreach ($guige as $key => $value) {
                //            $value->visible(['PSDetail']);
                //        }
//                self::ReturnAjax(2000, '', $data);
                $this->assign('spec', $data);
                $html = $this->fetch('zorder:temp');
                self::ReturnAjax(2000, '', $html);
            }
        }else{
            $this->jsonFailed('请求类型错误', '5000');
        }
    }
    /**
     * 添加商品信息补充视图
     */
    public function commInfoSuppView()
    {
        //商品id
        $id = $this->request->param('id');
        if ($bool = $this->request->has('list') and 'true' == $bool) {
            $this->assign('history', 1);
        }else{
            $this->assign('history', 0);
        }
        $info = Db::name('goods')
            ->where(['id' => $id])
            ->field('id,gname')
            ->find();
        //去除之前编辑的库存和价格
        $old = Stock::where(['gid' => $id])
            ->field('skus,stock,price,specs, skus as sku')
            ->select();
//        $old = Db::name('stock')
//            ->where(['gid' => $id])
//            ->field('skus,stock,price,specs')
//            ->select();
        $old->withAttr('sku', function ($value, $data) {
            return explode(',', $value);
            });

        $id = $this->request->param('id');
        $ids = ProductSpec::where(['gid' => $id])
            ->order('create_time asc')
            ->field('id,ps_name')
            ->select();
        $data = [];
        foreach ($ids as $key => $value) {
            $data[$key]['ps_name'] = $value['ps_name'];
            $data[$key]['detail'] = Db::name('ps_detail')
                ->order('create_time asc')
                ->hidden('create_time,update_time')
                ->where(['ps_id' => $value['id']])
                ->select();
        }
        $this->assign('spec', $data);
        $this->assign('data', $old);
//        self::ReturnAjax(2000, '', $old);
        $this->assign('info', $info);
        return view();
    }
    /**
     * 删除某个商品的所有的价格和库存
     */
    public function deletePrice()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|商品id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, 2001);
            }
            try {
                $bool = Stock::destroy(function ($query) use ($post) {
                    $query->where(['gid' => $post['id']]);
                });
                if ($bool) {
                    return $this->jsonResult(true, null, '删除成功', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', 5000);
            }
        } else {
            return $this->jsonFailed('请求否错误', 4003);
        }
    }

    /**
     * 添加商品信息补充 （添加实物商品的库存和价格）
     * 商品信息补充  Commodity information supplement
     */
    public function commInfoSupp()
    {
        if ($this->request->isPost()){
            $post = $this->request->param();

            $id = $this->request->param('id');
            if ($id) {
//                halt($post);
                //step 1 检查stock是否存在该商品的数据，有则清空
                Db::startTrans();
                try {
                    $bool = Stock::destroy(function ($query) use ($id) {
                        $query->where(['gid' => $id]);
                    });
                    if ($bool) {
                        //step 2 在stock 表中创建的该商品新的数据
                        $number = Db::name('product_specifications')
                            ->where(['gid' => $id])
                            ->count('id');
                        $arr = array_chunk($post['skus'],$number);
                        /**
                         * 写入实物商品的排序价格
                         */
                        $goods = Goods::get($id);
                        $goods->price = $post['price']['0'];
                        $goods->save();
                        foreach ($arr as $key => $value) {

                            $add = [
                                'gid' => $id,
                                'skus' => implode(',', $arr[$key]),
                                'stock' => $post['stock'][$key],
                                'price' => $post['price'][$key],
                                'create_time' => date('Y-m-d H:i:s', time()),
                                'update_time' => date('Y-m-d H:i:s', time())
                            ];
                            $stock_id = Db::name('stock')
                                ->insertGetId($add);
                            Db::commit();
                            //更新 specs 分类字符串字段
                            foreach ($arr[$key] as $kkey=> $value) {
                                $string = Db::name('ps_detail')
                                    ->where(['sku' => $value])
                                    ->field('detail')
                                    ->find();
//                        dump($string);
                                $specsArr[$kkey] = $string['detail'];
                            }
//                    dump($specsArr);
                            $specs = implode(',', $specsArr);
                            $specsArr = [];
                            Db::name('stock')
                                ->where(['id'=>$stock_id])
                                ->update(['specs'=>$specs]);
                            Db::commit();
                            $specs = '';

                        }
                        if ($stock_id) {
                            return $this->jsonResult(true, null,'库存与价格保存成功','2000');
                        }
                    }
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', 5000);
                }

            }

        }else{
            return $this->jsonFailed('请求类型错误', '4003');
        }

    }
}
