<?php

namespace app\admin\controller;

use app\admin\model\School;
use app\admin\model\User;
use think\Controller;
//use think\Request;
use think\facade\Request;

class ZparentsController extends BaseController
{
    protected $page_count = 10;
    /**
     *家长列表视图
     */
    public function showParentsList()
    {
        $Schools = School::column('name', 'id');
        $this->assign('schools', $Schools);
        $param = $this->getQueryParams([
            'school' => 'c.sid',
            'grade' => 'c.graid',
            'classes' => 'c.id'
        ]);
        $data = User::order('u.create_time desc')
            ->alias('u')
            ->where('u.u_type', 3)//家长类型
            ->where($param)
            ->join('td_school s', 's.id = u.sids')
            ->join('td_grade g', 'g.id = u.graids')
            ->join('td_class c', 'c.id = u.cids')
            ->leftJoin('td_user uu', 'u.s_uid = uu.id')
            ->field('u.id,u.username,s.name,g.graname,c.gname,u.phone,u.regi_code, u.s_uid, uu.username as studentName, uu.gender as studentGender, u.enable')
            ->paginate($this->page_count,false);

        $page = $data->render();
//        if (is_array($data->toArray())){
//            foreach ($data as  $key => $value){
//                $student = User::where(['id'=>$value['s_uid']])->field('username,gender,id')->find();//家长下有一个学生
//                $value['studentName'] = $student['username'];
//                $value['studentGender'] = $student['gender'];
//            }
//        }
        $this->assign('dataList',$data);
        $this->assign('page',$page);
        return view();
    }

    public function cancel()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'id|用户id'=>'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $user = User::get($post['id']);
            if ($user->enable === 1){
                $user->enable = 2;
                $bool = $user->save();
                if ($bool){
                    self::ReturnAjax(2000,'已注销');
                }
            }else{
                $user->enable = 1;
                $bool = $user->save();
                if ($bool){
                    self::ReturnAjax(2000,'已启用');
                }
            }


        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
}
