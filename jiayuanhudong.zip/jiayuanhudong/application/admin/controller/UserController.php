<?php
/**
 * Created by cheng. Time: 2018-05-22 17:07:50
 */

namespace app\admin\controller;

use app\td\model\User;
use app\td\model\File;

class UserController extends BaseController
{
    public function initialize()
    {
        parent::initialize();
        $this->model = new User();
    }

    public function index() {

        $where = $this->getQueryParams();
        $list = User::where('is_staff', 0)->where($where)->field('id,username,nickname,enable,create_time,last_login_time,last_login_ip,is_staff')
            ->paginate($this->page_count, false, ['query' => $this->paginateParams()]);
        $page = $list->render();

        $this->assign('dataList', $list);
        $this->assign('page', $page);
        return view();
    }

    public function delete() {
        return parent::delete();
    }

    public function enable() {
        $id = $this->request->param('id');
        $enable =$this->request->param('enable');
        $user = User::get($id);
        if(empty($user)) {
            return $this->jsonFailed('用户不存在');
        }
        if($user->username == 'admin') {
            return $this->jsonFailed('系统管理员帐号无法禁用');
        }
        $new_val = $enable == 1 ? 0 : 1;
        $user->enable = $new_val;
        $user->save();
        return $this->jsonSuccess(['enable' => $new_val], $message='更新成功');
    }

    /**
     * 用户设置
     */
    public function profile() {

        if($this->isGet()) {
            if(!empty($this->user->photo_fid)) {
                $file = File::where('id', $this->user->photo_fid)->find();
                $this->assign('photo_file', $file);
            }


            return view();
        }
        else {
            $nickname = $this->request->param('nickname');
            $photo_fid = $this->request->param('photo_fid');
            $password = $this->request->param('password');
            $password2 = $this->request->param('password2');
            $data = ['nickname' => $nickname];
            if(!empty($password) || !empty($password2)) {
                if($password != $password2) {
                    return $this->jsonFailed('两次密码不一致');
                }
                $data['password'] = User::genPassword($password);
            }
            if(!empty($photo_fid)) {
                $data['photo_fid'] = $photo_fid;
            }
            User::where('id', $this->user->id)->update($data);

            return $this->jsonSuccess();
        }
    }

    /**
     * 新增控制器
     */
    public function add() {
        return view();
    }

}