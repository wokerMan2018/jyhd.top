<?php

namespace app\admin\controller;

use app\admin\model\Classes;
use app\admin\model\Regicode;
use app\admin\model\School;
use think\Controller;

use think\Db;
use think\facade\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style;

/**
 * Class ZcodeController
 * @package app\admin\controller
 */
class ZcodeController extends BaseController
{
    /**注册码管理列表视图
     * @return \think\response\View|void
     * @throws \think\exception\DbException
     */
    public function index()
    {
        $where = $this->getQueryParams();
        $limit = 10;
        foreach ($where as $key=>$value){
            if ($value['0'] == 'limit'){
                $limit = $value['2'];
                unset($where[$key]);
            }
        }
        $data = Regicode::where($where)
            ->order('create_time','desc')
            ->field('id,number,create_time,use_time,status,phone,rtype')
            ->paginate($limit,false);
        $page = $data->render();
        $this->assign('dataList',$data);
        $this->assign('page',$page);
        return view();
    }

    /**
     * 生成注册码视图
     * @return \think\response\View
     */
    public function create_code_view()
    {
        $sids = School::all(function ($query){
            $query->field('id,name');
        });
        $this->assign('sdis',$sids);
        return view();
    }

    public function getClasses()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'gid|年级id'=>'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $classes = Classes::all(function ($query) use ($post){
                $query->where(['graid'=>$post['gid']])->field('id,gname');
            });
//            self::ReturnAjax(2000,'',$classes);
            $this->assign('classes',$classes);
            if ($classes){
                $html = $this->fetch('zcode:temphtml');
                self::ReturnAjax(2000,'',$html);
            }

        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }

    /**工具函数
     * @param $digits
     * @return bool|string
     */
    public function randcode($digits)
    {
        return substr(implode(NULL, array_map('ord', str_split(substr(md5(uniqid(md5(microtime(true)),true)), 7, 13), 1))), 0, $digits);
    }

    /**
     *生成注册码
     */
    public function create_code()
    {
        if (Request::isPost()){
            $post = Request::param();
//            dump($post);die;
            $digits = 8;//注册码位数
            $rule = [
                'school|学校id'=>'require',
                'grade|年级id'=>'require',
//                'classes|班级id'=>'',
                'type|注册码类型'=>'require',
                'num|注册码数量'=>'require|number',
//                'digits|注册码位数'=>'require|number',
                '__token__'=>'require|token'
            ];
            $res = self::validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            Db::startTrans();
            try {
                for ($i = 0; $i < trim($post['num']);$i ++){
                    $code['number'] = self::randcode($digits);
                    $rule2 = [
                        'number|注册码'=>'require|unique:regi_code'
                    ];
                    $result = self::validate($code,$rule2);
                    if (true !== $result){
                        self::ReturnAjax(2001,$result);
                    }
                    Regicode::create([
                        'sid'=>$post['school'],
                        'gid'=>$post['grade'],
                        'cid'=>$post['classes'],
                        'rtype'=>trim($post['type']),
                        'number'=>$code['number'],
                        'status'=>1
                    ]);

                }
                Db::commit();
            }catch (\Exception $exception){
                Db::rollback();
                self::ReturnAjax(2001,'生成注册码失败');
            }
            self::ReturnAjax(2000,'生成注册码成功');
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }

    /**
     *导出注册码记录到Excel
     */
    public function export()
    {
        $excel = new Spreadsheet();
        $letter = array('A','B','C','D','E','F');
        $tableHeader = array('序号','注册码','生成日期','使用日期','状态','绑定手机号');
        foreach ($tableHeader as $key => $value){
            $excel->getActiveSheet()->setTitle('注册码表格')->setCellValue("$letter[$key]1","$value");
        }
        /**
         * 样式定制 设置为水平居中对齐
         * @link 参见https://blog.csdn.net/gc258_2767_qq/article/details/81003656
         */
        $count = Regicode::count('id');
        $styleArray = [
            'alignment' => [
                'horizontal' => Style\Alignment::HORIZONTAL_CENTER,
            ],
        ];
        $excel->getActiveSheet()->getStyleByColumnAndRow(1, 1, 6,$count + 1 )->applyFromArray([
            'alignment' => [
                'horizontal' => Style\Alignment::HORIZONTAL_CENTER,
                'vertical' => Style\Alignment::VERTICAL_CENTER,
            ]
        ]);
        //所有单元格（行）默认高度
        $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);
        //设置行高度
        // $excel->getActiveSheet()->getRowDimension('1')->setRowHeight(30);
        $excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
        $excel->getActiveSheet()->getColumnDimension('F')->setWidth(20);

        $data = Regicode::order('create_time','desc')
            ->field('id,number,create_time,use_time,status,phone')
            ->select()->toArray();
//        dump($data);die;
        foreach ($data as $key => $value){
            $j = $key + 2;
            $i = 0;
            foreach ($value as $kkey => $vvalue){
                $excel->getActiveSheet()->setCellValue("$letter[$i]$j","$vvalue");
                $i ++;
            }
        }
        //设置是否加粗
        // $excel->getActiveSheet()->getStyle('2')->getFont()->setBold(true);
// Redirect output to a client’s web browser (Ods)
        // Redirect output to a client’s web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $time = date('Y-m-d',time());
        $filename = $time . "注册码.xlsx";
        header("Content-Disposition: attachment;filename=$filename");
        header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $writer = IOFactory::createWriter($excel, 'Xlsx');
        $writer->save('php://output');
        exit;
    }
}
