<?php
/**
 * Created by cheng. Time: 2018-05-22 17:07:50
 */

namespace app\admin\controller;

use app\td\model\User;
use think\Db;

class AccountController extends BaseController
{

    public function initialize()
    {
        parent::initialize();
        $this->model = new User();
    }

    public function index()
    {
        $where = $this->getQueryParams();
        $user = User::where($where)->paginate($this->page_count, false, ['query' => $this->paginateParams()]);
//        $user = Db::table('td_user')->select();
//        dump($list);exit;
        foreach ($user as $key => $value) {
            $id = $value['id'];
            $balance = Db::table('td_user_profile')
                ->where('uid', $id)
                ->find();
            $user[$key]['balance'] = $balance;
        }
        $page = $user->render();
        $this->assign('user', $user);
        $this->assign('page', $page);
        return view();
    }

    public function delete()
    {
        return parent::delete();
    }

}