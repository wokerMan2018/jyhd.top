<?php

namespace app\admin\controller;

use app\admin\model\Article;
use app\admin\model\TrainingClassification;
use think\Controller;
//use think\Request;
use think\Db;
use think\exception\DbException;
use think\facade\Request;
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use helper\HttpHelper;
use helper\QinNiu;
use helper\UuidHelper;

class ZarticleController extends BaseController
{
    protected $page_count = 10;
    /**
     * 培训文章列表视图
     */
    public function showTrainList()
    {
        $param = $this->getQueryParams([
            'status' => 'a.status'
        ]);
        $data = Article::where('at.push_plate',1)
            ->where($param)
            ->alias('a')
            ->join('td_article_type at', 'at.id = a.atypeid')
            ->order('a.update_time DESC')
            ->field('a.id,a.atitle,a.status,a.create_time,a.push_time')
            ->paginate($this->page_count,false);
        $page = $data->render();
        $this->assign('dataList',$data);
        $this->assign('page',$page);

        return view();
    }

    /**
     * 撤回文章
     */
    public function withdraw()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'id|文章id'=>'require',
                'status|文章状态'=>'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001, $res);
            }
            //TODO 改变文章状态为草稿
            $article = Article::get($post['id']);
            $article->status = 1;
            $article->push_time = null;
            $bool = $article->save();
            if ($bool){
                self::ReturnAjax(2000,'已撤回！');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }

    /**
     * 删除文章
     * @return \think\response\Json|void
     */
    public function delete()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|文章id' => 'require',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 删除文章
//            $bool = Article::destroy($post['id']);
            $article = Article::get($post['id']);
            $article->status = 3;
            $bool = $article->save();
            if ($bool){
                self::ReturnAjax(2000, '删除成功');
            }

        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }
    /**
     * 编辑文章视图
     */
    public function editView()
    {
        $id = Request::param('id');
        if ($id){
            $training = TrainingClassification::select();
            $this->assign('tracla', $training);
            $article = Article::where(['a.id'=>$id])
                ->alias('a')
                ->join('td_article_type at', ' at.id = a.atypeid')
                ->field('at.push_plate,at.push_person,a.atitle,a.uid,a.acontent,a.status,a.need_pay,a.paycontent,a.video, a.thumb, a.tc_id')
                ->find();
            if (!is_null($article->video)) {
//                $article->withAttr('video', function ($value, $data) {
//                    return env('QINIU_URL') . '/' . $value;
////                    return env('QINIU_URL') . '/' . 'Taylor Swift - Love Story-8xg3vE8Ie_E.mp4';
//                });
            }
            if ($article){
                $this->assign('item', $article);
            }
        }else{
            self::ReturnAjax(2001, '缺少参数');
        }
        return view();
    }
    /**
     * 编辑文章
     */
    public function edit()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|文章id' => 'require',
                'articleTitle|文章标题' => 'require',
                'type|文章发布板块' => 'require',
                'personType|发布人群' => 'require',
                'pushPerson|发布人' => 'require',
                'text|文章内容' => 'require',
                'status|文章状态' => 'require',
                'thumb|封面' => 'require|url'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 修改文章属性
            $atypeid = Db::name('article_type')
                ->where(['push_plate'=>$post['type'],'push_person'=>$post['personType']])
                ->field('id')
                ->find();
            $article = Article::get($post['id']);
            $article->atitle = $post['articleTitle'];
            $article->uid = $post['pushPerson'];
            $article->acontent = $post['text'];
            $article->status = $post['status'];
            $article->atypeid = $atypeid['id'];
            $article->thumb = $post['thumb'];
            /**
             * 发布板块为培训， 则会更新tc_id
             */
            if (1 === intval($post['type'])) {
                $article->tc_id = $post['tc_id'];
            }
            if ($post['status'] == 2){
                $article->push_time = date('Y-m-d H:i:s',time());
            }else{
                $article->push_time = null;
            }
            $bool = $article->save();
            if ($bool){
                self::ReturnAjax(2000,'修改文章成功');
            }

        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }

    }

    /**
     * 最新资讯文章列表视图
     */
    public function showInformationList()
    {
        $param = $this->getQueryParams([
            'status' => 'a.status'
        ]);
        $data = Article::where('at.push_plate',2)
            ->where($param)
            ->alias('a')
            ->join('td_article_type at', 'at.id = a.atypeid')
            ->order('a.update_time DESC')
            ->field('a.id,a.atitle,a.status,a.create_time,a.push_time')
            ->paginate($this->page_count,false);
        $page = $data->render();
        $this->assign('dataList',$data);
        $this->assign('page',$page);
        return view();
    }

    /**
     * 添加文章视图
     */
    public function addArticleView()
    {
        $trainingClassifications = TrainingClassification::select();
        $this->assign('tracla', $trainingClassifications);

        return view();
    }

    public function addArticleViewEdit()
    {
        return view();
    }
    public static $MAX_FILE_SIZE = 1024 * 1024 * 100; // 100M
    public static $ALLOW_FILE_EXT = [
         "mp4", "webm"
    ];
    /**
     * 添加文章
     */
    public function addArticle()
    {
        if (Request::isPost()){
            $post = Request::param();
//            dump($post);die;
            $rule = [
                'articleTitle|文章标题'=>'require',
                'type|发布版块'=>'require',
                'personType|发布人群'=>'require',
                'pushPerson|发布人'=>'require',
                'text|文章内容'=>'require',
                'status|发布状态'=>'require',
                'need_pay|付费类型' => 'require',
                'thumb|文章封面' => 'require|url'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $artid = Db::name('article_type')
                ->where(['push_plate'=>$post['type'],'push_person'=>$post['personType']])
                ->field('id')
                ->find();
            $add = [
                'atypeid'=>$artid['id'],
                'uid'=>$post['pushPerson'],
                'atitle'=>$post['articleTitle'],
                'acontent'=>$post['text'],
                'status'=>$post['status'],
                'need_pay' => $post['need_pay'],
                'thumb' => $post['thumb']
            ];
            /**
             * 如果是培训， 则必须有培训分类字段
             */
            if (1 === intval($post['type'])) {
                $add['tc_id'] = $post['tc_id'];
            }

            if (1 == $post['need_pay']) {
                $add['price'] = $post['price'];
                $add['paycontent'] = $post['text1'];
            }
            if ($post['status'] == 2 ){
                $add['push_time'] = date('Y-m-d H:i:s',time());
            }else{
                $add['push_time'] = null;
            }
            $result = Article::create($add);
            if (false) {
//            if ($post['video_upload_type'] === '1' and $this->request->has('uploadvideo','file')) {
                //将培训视频上传至 七牛云服务器
//                $file = Request::file('uploadvideo');
                $file = $this->request->file('uploadvideo');
                $fileName = $file->validate(['size' => self::$MAX_FILE_SIZE,'ext'=> implode(',', self::$ALLOW_FILE_EXT) ])->getInfo()['name'];
                $extension = $file->getExtension();
                $fileName = UuidHelper::generate()->string . '.' . $extension;
                $filePath = $file->getInfo()['tmp_name'];
                $qiniu = new QinNiu();
//                $token = $qiniu->get_upload_token();
                $token = $qiniu->getUploadToken($fileName);
//                $response = self::uploadVideo($token, $file, $fileName);
                // 初始化 UploadManager 对象并进行文件的上传。
                $uploadMgr = new UploadManager();
                // 调用 UploadManager 的 putFile 方法进行文件的上传。
                list($response , $err) = $uploadMgr->putFile($token, $fileName, $filePath);//数组
                //得到 response 上传是否成功   返回值
                Db::name('json')
                    ->insertGetId([
                        'json' => json_encode($response),
                    ]);
                if (isset($response)) {
                    //将上传后的访问地址保存至数据库
                    if (isset($response['key'])) {
                        $file_path = env('QINIU_URL') . '/' . $response['key'];
                    }
//                    if (true === isJson($response)) {
//                        $response = json_decode($response, true);
//                        if (isset($response['key'])) {
//                            $result->video = $response['key'];
//                            $result->save();
//                        }
//                    }
                }
            }else{
                $file_path = $post['url_video'];
            }
            $result->video = $file_path;
            $result->video_upload_type = $post['video_upload_type'];
            $result->save();
//            sleep(30);

            if (!$result->isEmpty()){
                self::ReturnAjax(2000,'新建文章成功');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
    /**
     * 添加培训分类视图
     */
    public function addTrainingClassificationView()
    {
        return view();
    }

    /**
     * 删除培训分类
     */
    public function del()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|培训分类id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            /**
             * 删除视频分类
             */
            Db::startTrans();
            try {
                $result = TrainingClassification::destroy($post['id']);
                Article::destroy(function ($query) use ($post) {
                    $query->where('tc_id', $post['id']);
                });
                Db::commit();
                if ($result) {
                    self::ReturnAjax(2000, '删除成功');
                }else{
                    self::ReturnAjax(2001, '删除失败');
                }
            } catch (DbException $e) {
                Db::rollback();
                self::ReturnAjax(2001, 'server error');
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }
    /**
     * 添加培训分类
     */
    public function addTrainingClassification()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'title|培训分类名称' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            $training = TrainingClassification::create([
                'type_name' => $post['title'],
            ]);
            $training->type = $training->id;
            $training->save();
            if ($training->isEmpty()) {
                self::ReturnAjax(2001, '添加失败');
            }else{
                self::ReturnAjax(2000, '添加分类成功');
            }
        }else{
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    /**
     * 培训分类列表视图
     * @return \think\response\View
     * @throws DbException
     */
    public function train_class_list()
    {
        $data = TrainingClassification::field('id, type_name, type, create_time')
            ->paginate($this->page_count, false);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }


    /**
     * @param $token
     * @param $file
     * @param $fileName
     * @return bool|string
     */
    public function uploadVideo($token, $file, $fileName)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => env('QINIU_UPLOAD_URL'),
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => array('token' => $token,'file'=> $file,'fileName' => $fileName,'key' => $fileName),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        return $response;
    }
}
