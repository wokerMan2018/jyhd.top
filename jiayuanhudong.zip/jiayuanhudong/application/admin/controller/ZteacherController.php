<?php

namespace app\admin\controller;

use app\admin\model\Classes;
use app\admin\model\School;
use app\admin\model\User;
use think\facade\Request;

//use think\Request;

class ZteacherController extends BaseController
{
    protected $page = 10;

    /**
     *老师列表视图
     * @throws \think\exception\DbException
     */
    public function showTeacherList()
    {
        $Schools = School::column('name', 'id');
        $this->assign('schools', $Schools);

        $param = $this->getQueryParams(
            [
                'school' => 's.id',
                'grade' => 'g.id',
                'class' => 'c.id',
                'username' => 'u.username',
                'phone' => 'u.phone'
            ]
        );

        $teachers = User::alias('u')
            ->where(['u.u_type' => 2])
            ->where($param)
            ->join('td_school s', 's.id = u.sids')
             ->join('td_grade g', 'g.id = u.graids')
//            ->join('td_class c', 'c.id = u.cids')
//            ->field('u.id,u.username,s.name,g.graname,c.gname,u.phone,u.regi_code,u.enable')
            ->field('u.id,u.username,s.name,g.graname,u.phone,u.regi_code,u.enable')
            ->paginate($this->page, false);
        $page = $teachers->render();
        $this->assign('dataList', $teachers);
        $this->assign('page', $page);
        return view();
    }


    public function cancel()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|用户id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            $user = User::get($post['id']);
            if ($user->enable === 1) {
                $user->enable = 2;
                $bool = $user->save();
                if ($bool) {
                    self::ReturnAjax(2000, '已注销');
                }
            } else {
                $user->enable = 1;
                $bool = $user->save();
                if ($bool) {
                    self::ReturnAjax(2000, '已启用');
                }
            }
        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }
}
