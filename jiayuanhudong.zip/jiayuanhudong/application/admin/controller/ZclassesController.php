<?php

namespace app\admin\controller;

use app\admin\model\Classes;
use app\admin\model\Grade;
use app\admin\model\Homework;
use app\admin\model\School;
use app\admin\model\User;
use app\admin\model\Zhomework_temp;
use think\Controller;
//use think\Request;
use think\Db;
use think\exception\DbException;
use think\facade\Request;

/**
 * Class ZclassesController
 * @package app\admin\controller
 */
class ZclassesController extends BaseController
{
    /**
     *班级列表视图
     */
    public function showClassList()
    {
        $Schools = School::column('name', 'id');
        $this->assign('schools', $Schools);
        $param = $this->getQueryParams([
            'school' => 'c.sid',
            'grade' => 'c.graid',
            'classes' => 'c.id',
            'gname' => 'c.gname',
            'gperson' => 'c.gperson'
        ]);
        $data = Classes::order('c.create_time desc')
            ->alias('c')
            ->where($param)
            ->leftJoin('td_school s', 's.id = c.sid')
            ->leftJoin('td_grade g', 'g.id = c.graid')
            ->field('c.id as id, c.gname as classname,g.graname as gradename, s.name as schoolname, c.id as personcount, c.gperson, c.gphone')
            ->paginate(10, false)
            ->each(function ($item, $key) {
                //统计家长人数
                $pcount = User::where(['cids'=>$item['personcount'],'u_type'=>3])->count();
                $item['personcount'] = empty($pcount) ? 0 : $pcount;
                return $item;
            });
//        $data = Classes::order('create_time desc')
//            ->hidden([
//                'create_time',
//                'update_time',
//                'get_grade'=>[
//                    'id',
//                    'sid',
//                    'create_time',
//                    'update_time',
//                    'get_school'=>[
//                        'id',
//                        'number',
//                        'create_time',
//                        'update_time'
//                    ]]])
//
//            ->with(['getGrade'=>function($query){
//                $query->with('getSchool')->find();
//            }])
//            ->paginate(10,false);

        $page = $data->render();

        $this->assign('dataList',$data);
        $this->assign('page',$page);
//        self::ReturnAjax(2000,'',$data);
        return view();
    }

    /**
     *添加班级视图
     */
    public function addClassView()
    {
        $sids = School::all(function ($query){
            $query->field('id,name');
        });
        $this->assign('sdis',$sids);
//        $this->ReturnAjax(200,'',$sids);
        return view();

    }

    /**
     *获取学校对应年级
     */
    public function getGrade()
    {
        if (Request::isPost()){
            $sid = input('sid');
            $graids = Grade::all(function ($query) use ($sid){
                $query->where(['sid'=>$sid])->field('id,graname');
            });
            $this->assign('graids',$graids);
//            self::ReturnAjax(200,'',$graids);
            if ($graids){
                $html = $this->fetch('zclasses:temphtml');
                self::ReturnAjax(2000,'',$html);
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
    /**
     * 通过年级id获取班级列表
     */
    public function getClasses()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'gid|年级id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 获取班级
            $classes = Classes::all(function ($query) use ($post) {
                $query->where('graid', $post['gid'])->field('id, gname as graname');
            });
            $this->assign('graids', $classes);
            if ($classes) {
                $html = $this->fetch('zclasses:temphtml');
                self::ReturnAjax(2000, '', $html);
            }


        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    /**
     *添加班级
     */
    public function addClass()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'school|所属学校'=>'require',
                'gname|班级名称'=>'require|unique:class,sid='. $post['school'] .'&graid='. $post['grade'].'&gname='. $post['gname'],
                'grade|所属年级'=>'require',
                'contact_person|联系人'=>'require',
                'contact_phone|联系方式'=>'require'
            ];
            $res = self::validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            Db::startTrans();
            try {
                $add = [
                    'sid'=>$post['school'],
                    'gname'=>$post['gname'],
                    'graid'=>$post['grade'],
                    'gperson'=>$post['contact_person'],
                    'gphone'=>$post['contact_phone']
                ];
                $result = Classes::create($add);
                if (!$result->isEmpty()) {
                    $grade_name = Grade::where('id', $post['grade'])
                        ->field('graname')
                        ->findOrEmpty();
                    if (!$grade_name->isEmpty()) {
                        $homeworrk_temps = Zhomework_temp::where('gname', $grade_name['graname'])
                            ->field('id')
                            ->select();
                        if (!$homeworrk_temps->isEmpty()) {
                            foreach ($homeworrk_temps as $ht) {
                                $addhomwork = [
                                    'sid' => $post['school'],
                                    'gid' => $post['grade'],
                                    'cid' => $result->id,
                                    'status' => 0,
                                    'htid' => $ht['id']
                                ];
                                Homework::create($addhomwork);
                            }
                        }
                    }

                }
                Db::commit();
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
            if (!$result->isEmpty()){
                self::ReturnAjax(2000,'添加班级成功');
            }else{
                self::ReturnAjax(2001,'添加班级失败');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }

    }

    /**
     * 编辑班级视图
     * @return \think\response\View
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function editClassView()
    {
        $id = Request::param('id');
        $info = Classes::where(['id'=>$id])
            ->hidden([
                'create_time',
                'update_time',
                'get_grade'=>[
                    'id',
                    'sid',
                    'create_time',
                    'update_time',
                    'get_school'=>[
                        'id',
                        'number',
                        'create_time',
                        'update_time'
                    ]]])
            ->with(['getGrade'=>function($query){
                $query->with('getSchool')->find();
            }])
            ->find();
        $schools = School::all();
        $this->assign('schools',$schools);
        $this->assign('info',$info);
        $grades = Grade::where(['sid'=>$info->sid])
            ->order('create_time desc')
            ->select();
        $this->assign('grades',$grades);

        return view();
    }

    /**
     * 编辑班级
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function editClass()
    {
        if (Request::isPost()){
            $post = Request::param();
            $gname = Classes::get($post['cid']);
            if ($post['gname'] == $gname->gname){
                $rule = [
                    'cid|班级id'=>'require'
                ];
            }else{
                $rule = [
                    'cid|班级id'=>'require',
                    'gname|班级名称'=>'require|unique:class,sid='. $post['school'] .'&graid='. $post['grade'].'&gname='. $post['gname']
                ];
            }
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $update = [
                'sid'=>$post['school'],
                'gname'=>$post['gname'],
                'graid'=>$post['grade'],
                'gperson'=>$post['contact_person'],
                'gphone'=>$post['contact_phone']
            ];
            $result = Classes::where(['id'=>$post['cid']])
                ->update($update);
            if ($result){
                self::ReturnAjax(2000,'更新成功');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
}
