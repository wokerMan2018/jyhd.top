<?php

namespace app\admin\controller;

use app\admin\model\Grade;
use app\admin\model\School;
use app\admin\model\User;
use think\Db;
use think\facade\Request;

//use think\Request;

/**
 * Class ZpersonController
 * @package app\admin\controller
 */
class ZpersonController extends BaseController
{
    /**
     *学校列表视图
     * @throws \think\exception\DbException
     */
    public function showSchoolList()
    {
        $param = $this->getQueryParams();

        $data = School::order('create_time desc')
            ->where($param)
            ->hidden(['create_time,update_time'])
            ->paginate(5,false);
        $page = $data->render();
        foreach ($data as $value){
            $tcount = User::where(['sids'=>$value->id,'u_type'=>2])->count();
            $value->tcount = empty($tcount) ? 0 : $tcount;

            $pcount = User::where(['sids'=>$value->id,'u_type'=>3])->count();
            $value->pcount = empty($pcount) ? 0 : $pcount;
        }
        $this->assign(  'dataList',$data);
        $this->assign('page',$page);
        return view();
    }

    /**
     *添加学校视图
     */
    public function addSchoolView()
    {
        return view();
    }

    /**
     *添加学校
     */
    public function addSchool()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'number|编号'=>'require|unique:school',
                'name|学校名称'=>'require',
                'address|地址'=>'require',
                'contact_person|联系人'=>'require',
                'contact_phone|联系方式'=>'require',
                'detail|所有年级'=>'require'
            ];
            $res = self::validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            Db::startTrans();
            try {
                $result = School::create([
                    'number'=>trim($post['number']),
                    'name'=>$post['name'],
                    'address'=>$post['address'],
                    'contact_person'=>$post['contact_person'],
                    'contact_phone'=>$post['contact_phone'],
                    'detail'=>$post['detail']
                ]);
                if ($result->id){
//                dump($post['detail']);die;
                    $grades = explode('/',$post['detail']);
                    foreach ($grades as $key => $value){
                        Grade::create([
                            'sid'=>$result->id,
                            'graname'=>$value
                        ]);
                    }
                    Db::commit();
                    self::ReturnAjax(2000,'添加学校成功');
                }
            } catch (\Exception $exception) {
                Db::rollback();
                self::ReturnAjax(2001,'数据失败');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }

    }

    /**
     * 编辑学校视图
     * @return \think\response\View
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function editSchoolView()
    {
        $id = Request::param('id');
        $school = School::where(['id'=>$id])->hidden(['create_time,update_time'])->find();
        $this->assign('school',$school);
        return view();
    }

    /**编辑学校
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function editSchool()
    {
        if (Request::isPost()){
//            dump(input());die;
            $post = Request::param();
            $rule = [
                'id'=>'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $update = [
                'name'=>$post['name'],
                'address'=>$post['address'],
                'contact_person'=>$post['contact_person'],
                'contact_phone'=>$post['contact_phone'],
                'detail'=>$post['detail']
            ];
            $result = School::where(['id'=>trim($post['id'])])->update($update);
            if ($result){
                self::ReturnAjax(2000,'更新成功');
            }else{
                self::ReturnAjax(2001,'没有更新或更新失败');
            }

        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }

    /**
     *停用学校
     */
    public function disableSchool()
    {
        if (Request::isPost()){
            $id = input('id');
            $bool = School::destroy($id);
            if ($bool){
                self::ReturnAjax(2000,'删除成功');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }

}
