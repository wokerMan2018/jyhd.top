<?php

namespace app\admin\controller;

use app\admin\model\Comments;
use think\Controller;
use think\Db;
//use think\Request;
use  think\facade\Request;
class ZcheckController extends BaseController
{
    protected $page_count = 10;

    /**
     * 审核培训文章的评论 列表视图
     */
    public function checkTrainList()
    {
        $param = $this->getQueryParams([
            'status' => 'c.status'
        ]);
        $data = Db::name('comments ')
            ->where('at.push_plate', 1)
            ->where($param)
            ->order('c.create_time DESC')
            ->alias('c')
            ->field('c.id,a.atitle,c.create_time,u.username,c.content,c.status')
            ->join('td_article a', 'a.id = c.aid')
            ->join('td_article_type at', 'at.id = a.atypeid')
            ->join('td_user u', 'u.id = c.uid')
            ->paginate($this->page_count, false);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }

    /**
     * 审核最新资讯文章评论  列表视图
     */
    public function checkInformationList()
    {
        $param = $this->getQueryParams([
            'status' => 'c.status'
        ]);
        $data = Db::name('comments ')
            ->where('at.push_plate',2)
            ->where($param)
            ->order('c.create_time DESC')
            ->alias('c')
            ->field('c.id,a.atitle,c.create_time,u.username,c.content,c.status')
            ->join('td_article a', 'a.id = c.aid')
            ->join('td_article_type at', 'at.id = a.atypeid')
            ->join('td_user u', 'u.id = c.uid')
            ->paginate($this->page_count, false);
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }

    /**
     * 删除评论
     */
    public function deleteComment()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|评论id' => 'require',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 删除该条评论
            $result = Comments::destroy($post['id']);
            if ($result){
                self::ReturnAjax(2000,'删除评论成功');
            }

        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }
    /**
     * 通过评论
     */
    public function pass()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|评论id' => 'require',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 通过评论
            $comment = Comments::get($post['id']);
            $comment->status = 2;
            $bool = $comment->save();
            if ($bool){
                self::ReturnAjax(2000, '已通过该评论');
            }

        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

    public function passAll()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'id|评论id集合' => 'require',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                self::ReturnAjax(2001, $res);
            }
            //TODO 批量通过评论
            $ids = explode(',', $post['id']);
            $comment = new Comments;
            if ($ids){
                foreach ($ids as $id){
                    $data[] = ['id'=>$id,'status'=>2];
                }
                $result = $comment->saveAll($data);
                if (!$result->isEmpty()){
                    self::ReturnAjax(2000,'批量通过评论成功',$result);
                }
            }


        } else {
            self::ReturnAjax(2001, '请求类型错误');
        }
    }

}
