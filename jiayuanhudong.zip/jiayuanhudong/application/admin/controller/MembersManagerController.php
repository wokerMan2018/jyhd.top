<?php

namespace app\admin\controller;

use app\admin\model\User;
use app\api\model\MembersOrder;
use think\Controller;
use think\Request;

class MembersManagerController extends BaseController
{
    protected $u_type = [
        '1' => '管理员',
        '2' => '教师',
        '3' => '家长',
        '4' => '游客',
        '5' => '学生'
    ];
    protected $members_type = [
        '1' => '月卡',
        '2' => '季卡',
        '3' => '年卡'
    ];
    protected $gender = [
        '1' => '男',
        '2' => '女'
    ];
    protected $order_status = [
        '0' => '取消',
        '10' => '待支付',
        '20' => '已付款'
    ];
    /**
     * 平台会员视图
     */
    public function members()
    {
        $param = $this->getQueryParams([
            'id' => 'u.id',
            'username' => 'u.username'
        ]);
        $data = User::order('u.id', 'asc')
            ->alias('u')
            ->where($param)
            ->whereNotNull('u.expiration_time')
            ->whereTime('u.expiration_time', '>', date('Y-m-d H:i:s', time()))
            ->field('u.id, u.u_type, u.username, u.phone, u.gender, u.id as members_type, u.expiration_time')
            ->paginate($this->page_count, false)
            ->each(function ($item, $key) {
                $item['u_type'] = $this->u_type[$item['u_type']];
                $order = MembersOrder::where('uid', $item['members_type'])
                    ->field('members_type')
                    ->selectOrFail();
                $item['members_type'] = $this->members_type[$order[count($order) - 1]['members_type']];
                $item['gender'] = $this->gender[$item['gender']];
            });
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }
    /**
     * 会员充值订单
     */
    public function rechargeOrder()
    {
        $param = $this->getQueryParams([
            'status' => 'mo.order_status'
        ]);
        $data = MembersOrder::order('mo.update_time', 'desc')
            ->alias('mo')
            ->where($param)
            ->leftJoin('td_user u', 'mo.uid = u.id')
            ->field('mo.id, mo.order_num, u.username, mo.total_price, mo.reduce_integer, mo.order_status, mo.pay_time, mo.members_type')
            ->paginate($this->page_count, false)
            ->each(function ($item, $key) {
                $item['order_status'] = $this->order_status[$item['order_status']];
                $item['members_type'] = $this->members_type[$item['members_type']];
            });
        $page = $data->render();
        $this->assign('dataList', $data);
        $this->assign('page', $page);
        return view();
    }
}
