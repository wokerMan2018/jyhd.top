<?php
namespace app\admin\controller;

use app\td\model\User;

class IndexController extends BaseController {
    public $exceptAuthActions = ['test', 'test_init', 'test_db'];

    protected function initialize()
    {
        parent::initialize();
    }

    public function index()
    {

        return view();
    }


    public function dashboard() {
        return view();
    }

    public function test() {

    }

}