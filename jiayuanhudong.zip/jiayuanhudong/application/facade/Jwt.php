<?php
/**
 * Created by PhpStorm.
 * User: drzhong2015@gmail.com
 * Date: 2019/5/4
 * Time: 23:03
 */

namespace app\facade;
use think\Facade;

class Jwt extends Facade
{
    protected static function getFacadeClass()
    {
        return 'app\plugins\jwt\JWT';
    }
}