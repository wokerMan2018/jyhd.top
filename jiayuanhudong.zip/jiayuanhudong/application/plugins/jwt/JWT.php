<?php
/**
 * Created by PhpStorm.
 * User: drzhong2015@gmail.com
 * Date: 2019/5/4
 * Time: 23:02
 */

namespace app\plugins\jwt;

use \Firebase\JWT\JWT as JWTP;
use think\Model;
//use Cache;
//use Request;
use think\facade\Cache;
use think\facade\Request;
class JWT extends JWTP
{
    /**
     * @param Model $userModel
     * @param $user 需要验证用户名字段
     * @param $password 需要验证的密码字段
     * @param bool $auto 是否自动登录
     * @param $time 登陆时间
     */
    public function login(Model $userModel,$user = '',$password = '',$auto = false,$time = 604800){
        if(!$auto){
            $users = $userModel->where('phone|name',$user)->find();
            if(empty($users)){
                throw new \Exception("用户不存在");
            }
            $autoPass = $userModel->autoPass;
            if(!password_verify($password,$users->{$autoPass})){
                throw new \Exception("用户名或密码错误");
            }
            $users->last_login_time = date("Y-m-d H:i:s",time());
        }else{
            $users = $userModel;
        }
        $jti = time();
        $api = [
            /**
             *非必须。issued at。 token创建时间，unix时间戳格式
             */
            'lat' => $_SERVER['REQUEST_TIME'],
            /**
             *非必须。expire 指定token的生命周期。unix时间戳格式
             */
            'exp' => $_SERVER['REQUEST_TIME']+$time,
            /**
             * 非必须。JWT ID。针对当前token的唯一标识
             */
            'jti' => $jti,
            /**
             * 自定义字段
             */
            'userModel' => $users,
        ];
        $token = self::encode($api,config('jwt.key'));
        if(!Cache::set($token,$jti,$time)){
            throw new \Exception("登录失败");
        };

        return $token;
    }

    /**
     * @param Model $userModel用户模型
     * @param $user 用户名
     * @param $phone 用户手机号
     * @param $password 密码
     * @param $receive_num 用户可接单次数
     * @param $release_num 用户可发单次数
     * @return string 返回
     * @throws \Exception
     */
    public function register(Model $userModel,$user,$phone,$password,$receive_num,$release_num){
        $login_user = $userModel->autoUser;
        $login_pass = $userModel->autoPass;
        $login_phone = $userModel->autoPhone;
        $login_receive = $userModel->autoRecive;
        $login_release = $userModel->autoRelease;

        $users = $userModel->create([
            $login_user => $user,
            $login_phone => $phone,
            $login_pass => $password,
            $login_receive => $receive_num,
            $login_release => $release_num
        ]);
        if(!$users->id){
            throw new \Exception("注册失败");

        }
        return $this->login($users,'','',true);
    }

    /**
     * 鉴权
     * @param $token
     * @return object
     * @throws \Exception
     */
    public function auth($token=''){
        if(empty($token)){
            $token = Request::header('token');
        }
        if(!Cache::get($token)){
            throw new \Exception("token错误或已经过期");
        }
        try{
            $userModel = self::decode($token,config('jwt.key'),config('jwt.type'));

            return $userModel->userModel;
        }catch (\Exception $e){
            throw new \Exception("请重新登录");
        }
    }


    public function logout(){
        $token = Request::header('token');
        Cache::rm($token);
        ajax_success([],'退出登录成功');
    }
}