<?php

namespace app\api\model;

use think\Model;

class Checkin extends Model
{
    protected $name = 'check_in';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'created_at';
//    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['created_at',];
//    protected $update = ['update_time'];
}
