<?php
namespace app\api\model;
use app\td\model\User as BaseUser;


class User extends BaseUser {

}