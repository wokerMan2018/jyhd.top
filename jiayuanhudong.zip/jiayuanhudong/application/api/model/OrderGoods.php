<?php

namespace app\api\model;

use think\Model;
use think\model\concern\SoftDelete;

class OrderGoods extends Model
{
    use SoftDelete;

    protected $name = 'order_goods';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time'];
    protected $update = ['update_time'];
    protected $deleteTime = 'delete_time';
}
