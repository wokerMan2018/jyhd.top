<?php

namespace app\api\model;

use think\Model;

/**
 * @property integer is_default
 * @property integer id
 * Class Address
 * @package app\api\model
 */
class Address extends Model
{
    protected $name = 'address';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
