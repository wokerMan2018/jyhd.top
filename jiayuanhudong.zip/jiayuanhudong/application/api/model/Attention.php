<?php

namespace app\api\model;

use think\Model;

class Attention extends Model
{
    protected $name = 'attention';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time'];
    protected $update = ['update_time'];
}
