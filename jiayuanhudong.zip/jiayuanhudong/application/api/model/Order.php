<?php

namespace app\api\model;

use app\admin\model\Car;
use app\admin\model\Goods;
use app\api\service\Pay;
use think\Db;
use think\exception\DbException;
use think\Model;
use app\admin\model\User;
use think\model\concern\SoftDelete;

/**
 * @property integer id
 * @property integer total_price
 * @property string order_num
 * @property integer order_status
 * @property string tracking_number 运单号
 * Class Order
 * @package app\api\model
 */
class Order extends Model
{
    use SoftDelete;
    /**
     * @var string
     */
    protected $name = 'order';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time'];
    protected $update = ['update_time'];
    protected $deleteTime = 'delete_time';

    /**
     * 创建订单
     * @param integer $address 地址id
     * @param integer $uid 下单用户id
     * @param string $wx_openid 微信openid
     * @param array $goods_list 商品列表 包含商品id 商品数量 商品单价
     * @param decimal $total_price
     * @param integer $reduceIntegral
     * @param  string $order_info 订单说明信息
     * @param integer $type 订单来源 false 为立即购买 true为购物车购买
     */
    public static function makeOrder($address,$uid,$wx_openid, $goods_list, $total_price, $reduceIntegral, $order_info,$type = false)
    {
        //生成订单号
        Db::startTrans();
        try {
            $orderNo = Pay::orderNo();
            $add = [
                'order_num' => $orderNo,
                'uid' => $uid,
                'total_price' => $total_price,
                'reduce_integral' => $reduceIntegral,
                'wx_openid' => $wx_openid,
                'order_status' => 10,
                'pay_type' => 1,
                'address_id' => $address,
                'order_info' => $order_info,
                'expiration_time' => date('Y-m-d H:i:s', strtotime('+1 day'))
            ];
            $order = Order::create($add);

            foreach ($goods_list as $key => $goods) {
                $goodsInfo = Goods::where('g.id', $goods['gid'])
                    ->alias('g')
                    ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                    ->where('gc.status', 1)
                    ->where('g.status', 1)
                    ->field('gc.cate_type, g.gimages, g.gname, g.gintro, g.gdetail')
                    ->findOrEmpty();
                if (!$goodsInfo->isEmpty()) {
                    $addOrderGoods = [
                        'oid' => $order->id,
                        'gid' => $goods['gid'],
                        'stock_id' => $goods['stock_id'],
                        'skus' => $goods['skus'],
                        'specs' => $goods['specs'],
                        'gtype' => $goodsInfo['cate_type'],
                        'gname' => $goodsInfo['gname'],
                        'gimgs' => $goodsInfo['gimages'],
                        'price' => $goods['price'],
                        'number' => $goods['goods_num']
                    ];
                    OrderGoods::create($addOrderGoods);
                }
            }
            //购物车的订单生成成功后，清除购物车对应数据
            if (true === $type) {
                foreach ($goods_list as $key => $item) {
                    Car::destroy($item['car_id']);
                }
            }
            Db::commit();
            return $order;
        } catch (\Exception $e) {
//            throw $e;
            Db::rollback();
            return false;
        }
    }
    const ORDER_STSTUS_CANCEL = 0;//已取消
    const ORDER_STSTUS_UNPAID = 10;//未支付
    const ORDER_STSTUS_PAID = 20;//已支付
    const ORDER_STSTUS_DELIVERED = 30;//已发货
    const ORDER_STSTUS_RECEIVED = 40;//已收货
    /**
     * 修改订单状态
     * @param integer $order_id 订单id
     * @param integer $order_status 订单状态值
     */
    public static function modifyOrderStatus($order_id, $order_status)
    {
        $order = Order::get($order_id);
        $order->order_status = $order_status;
        $bool = $order->save();
        if ($bool) {
            return true;
        }else{
            return false;
        }
    }
}
