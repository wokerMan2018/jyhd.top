<?php

namespace app\api\model;

use app\api\service\Pay;
use think\Db;
use think\exception\DbException;
use think\Model;
use think\model\concern\SoftDelete;

class ReadOrder extends Model
{
    use SoftDelete;
    /**
     * @var string
     */
    protected $name = 'reading_order';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time'];
    protected $update = ['update_time'];
    protected $deleteTime = 'delete_time';
    /**
     * @param integer $uid 购买人用户id
     * @param string $wx_openid 购买人微信openid
     * @param integer $article_id 购买的付费文章id
     * @param string $total_price 实际花费
     * @param string $reduceIntegral 消耗积分数
     */
    public static function makeReadOrder($uid, $wx_openid,$article_id, $total_price, $reduceIntegral )
    {
        Db::startTrans();
        try {
            $orderNo = Pay::orderNo();
            $add = [
                'order_num' => $orderNo,
                'uid' => $uid,
                'total_price' => $total_price,
                'reduce_integral' => $reduceIntegral,
                'wx_openid' => $wx_openid,
                'order_status' => 10,
                'pay_type' => 1,
                'article_id' => $article_id,
                'expiration_time' => date('Y-m-d H:i:s', strtotime('+1 day'))
            ];
            $read_order = ReadOrder::create($add);
            Db::commit();
            return $read_order;
        } catch (DbException $e) {
            throw $e;
            Db::rollback();
            return false;
        }
    }
}
