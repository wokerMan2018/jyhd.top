<?php

namespace app\api\model;

use think\Model;

/**
 * @property integer status
 * @property  string cdkey
 * @property integer uid
 * Class CDKey
 * @package app\api\model
 */
class CDKey extends Model
{
    protected $name = 'cdkey';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
}
