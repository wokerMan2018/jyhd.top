<?php

// Error应放在最后面
return [
    'CrosHeader', 'JwtMiddleware', 'Error'
    ,'AuthMiddleware'
];