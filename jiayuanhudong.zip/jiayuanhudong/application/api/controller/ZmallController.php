<?php

namespace app\api\controller;

use app\admin\model\Attention;
use app\admin\model\Car;
use app\admin\model\Goods;
use app\admin\model\Integconfig;
use app\admin\model\ProductSpec;
use app\admin\model\PsDetail;
use app\admin\model\Stock;
use app\admin\model\User;
use app\api\model\Address;
use app\api\model\CDKey;
use app\api\model\Notice;
use app\api\model\Order;
use app\api\model\OrderGoods;
use app\api\service\Pay;
use app\common\library\wechat\WxPay;
use function Complex\add;
use function foo\func;
use phpDocumentor\Reflection\Types\Integer;
use phpDocumentor\Reflection\Types\This;
use think\Controller;
use think\Db;
use think\Request;
use think\exception\DbException;

/**
 * 积分商城 菜单 接口
 * Class ZmallController
 * @package app\api\controller
 */
class ZmallController extends BaseController
{
    protected $exceptAuthActions = ['goodslist', 'goodsdetail'];
    /**
     * 商品列表 接口
     */
    public function goodsList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'type|分类名称' => 'require|integer',
                'sorting|排序的名称' => 'require|integer',
                'order|倒序或顺序' => 'require|integer',
                'page|页码' => 'require|integer'
            ];
            //type为 1时全部商品
            //type为 2时实物商品
            //type为 3时虚拟商品
            //sorting 可传 价格price为1 销量sale为2 新品create_time为3
            //order为 1时顺序
            //order为 2时倒序
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $orderMapping = [
                    '1' => 'asc',
                    '2' => 'desc'
                ];
                $type = Pay::typeMappingRelationship($post['type']);
                $sorting = Pay::sortingMappingRelationship($post['sorting']);
                //商品名称搜索
                $search = $this->request->has('search','post') ? $post['search'] : '';

                $goods = Goods::where('gc.cate_type','in',$type)
                    ->where('gc.status',1)//商品分类状态为使用中
                    ->where('g.status', 1)//商品状态为已上架
                    ->where('g.gname','like','%'.$search.'%')
                    ->alias('g')
                    ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                    ->field('g.id, g.gc_id, g.gimages, g.gname, g.gintro, g.sales_volume,g.update_time, g.id as price,g.id as isAttention')
                    ->order($sorting,$orderMapping[$post['order']])
                    ->page($post['page'], 7)
                    ->select();
                $goods->withAttr('price', function ($value, $data) {
                    $price = Stock::where('gid', $value)
                        ->field('price')
                        ->findOrEmpty();
                    if (!$price->isEmpty()) {
                        return $price['price'];
                    } else {
                        return '0';
                    }
                })->withAttr('isAttention', function ($value, $data) {
                    $res = Attention::where('gid', $value)
                        ->where('uid', $this->uid)
                        ->findOrEmpty();
                    if (!$res->isEmpty()) {
                        return true;
                    } else {
                        return false;
                    }
                })->withAttr('gimages', function ($value, $data) {
                    if (is_array(json_decode($value, true))) {
                        foreach (json_decode($value, true) as $item) {
                            $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                        }
                    }
                    return $path_goods;
                });
                if (!$goods->isEmpty()) {
                    return $this->jsonResult(true, $goods, '商品列表', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 关注商品 点击关注与取消关注
     */
    public function AttentionGoods()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'gid|商品id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $res = Pay::Attention($post['gid'], $this->uid);
                if (false !== $res) {
                    return $this->jsonResult(true, null, 'success', '2000');
                }else{
                    return $this->jsonFailed('fail', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 商品详情
     */
    public function goodsDetail()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'gid|商品id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $goods = Goods::where('g.id', $post['gid'])
                    ->alias('g')
                    ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                    ->field('g.id, g.gc_id, g.gimages, g.gname, g.gintro, g.gdetail, g.sales_volume, g.update_time, gc.cate_type as hasSkus, g.id as price, g.id as skus, g.id as attrValue')
                    ->findOrEmpty();
                $goods->withAttr('gimages', function ($value, $data) {
                    if (is_array(json_decode($value, true))) {
                        foreach (json_decode($value, true) as $item) {
                            $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                        }
                    }
                    return $path_goods;
                })->withAttr('hasSkus', function ($value, $data) {
                    if (1 === $value) {
                        return true;
                    } else {
                        return false;
                    }
                })->withAttr('price', function ($value, $data) {
                    $res = Stock::where('gid', $value)
                        ->field('price')
                        ->findOrEmpty();
                    if (!$res->isEmpty()) {
                        return $res['price'];
                    } else {
                        return '0';
                    }
                })->withAttr('skus', function ($value, $data) {
//                    if ($data['hasSkus'] === 1) {
                    //实物商品有 skus
                    $skus = Stock::where('gid', $value)
                        ->field('id as stockId,skus,stock,price,specs')
                        ->select();
                    return json_encode($skus);
//                    }else{
//                        //虚拟商品
//                        return false;
//                    }
                })->withAttr('attrValue', function ($value, $data) {
                    $attr = [];
                    $ps = ProductSpec::where('gid', $value)
                        ->field('id, ps_type, ps_name')
                        ->select();
                    if (!$ps->isEmpty()) {
                        foreach ($ps as $key => $psvalue) {
                            $ps_detail = PsDetail::where('ps_id', $psvalue['id'])
                                ->field('id, detail, sku')
                                ->select();
                            $add_obj = (object)[
                                'ps_name' => $psvalue['ps_name'],
                                'ps_value' => $ps_detail
                            ];
                            array_push($attr, $add_obj);

                        }
                    }
                    return $attr;
                });
                if (!$goods->isEmpty()) {
                    return $this->jsonResult(true, $goods, '商品详情', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 获取库存和价格
     */
    public function getStock()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'gid|商品id' => 'require|integer',
                'skus|规格组合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                // skus 以','分隔的sku字符串
                $res = Stock::where('gid', $post['gid'])
                    ->where('skus', $post['skus'])
                    ->field('id as stockId,stock,price,specs')
                    ->findOrEmpty();
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, 'stock and price', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 指定用户是否关注了该商品
     */
    public function isAttention()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'gid|商品id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $res = Pay::isAttention($post['gid'], $this->uid);
                return $this->jsonResult(true, ['isAttention' => $res], 'success', '2000');
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 由地址id得到地址详情
     */
    public function addressInfoByid()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'address_id|地址id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $info = Address::where('id', $post['address_id'])
//                    ->where('uid',$this->uid)
                    ->field('id, address, address as province, address as city, address as area, zipcode, detail_address, name, phone, is_default')
                    ->findOrEmpty();
                if ($info->isEmpty()) {
                    return $this->jsonFailed('没有数据', '2001');
                }else{
                    $info->withAttr('province', function ($value, $data) {
                        $address = explode(',', $value);
                        $province = Db::name('area')
                            ->where('id', $address['0'])
                            ->field('name')
                            ->findOrEmpty();
                        return $province['name'];

                    })->withAttr('city', function ($value, $data) {
                        $address = explode(',', $value);
                        $city = Db::name('area')
                            ->where('id', $address['1'])
                            ->field('name')
                            ->findOrEmpty();
                        return $city['name'];
                    })->withAttr('area', function ($value, $data) {
                        $address = explode(',', $value);
                        if (count($address) > 2) {
                            $area = Db::name('area')
                                ->where('id', $address['2'])
                                ->field('name')
                                ->findOrEmpty();
                            return $area['name'];
                        }else{
                            return null;
                        }

                    });
                    return $this->jsonResult(true, $info, '地址详情', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 确认订单 页面内容接口（用于数据展示）
     * 注： 页面内容由前端带到确认订单页面来
     */
    public function confirmOrderView()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'stock_ids|库存id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $goods_ids = json_decode($post['stock_ids'], true);
                if (is_array($goods_ids)) {
                    $goods_list = [];
                    foreach ($goods_ids as $goods_id) {
                        $goods = Stock::where('s.id', $goods_id)
                            ->alias('s')
                            ->where('g.status', 1)
                            //商品上架状态
                            ->where('gc.status', 1)
                            //分类为启用中
                            ->leftJoin('td_goods g', 'g.id = s.gid')
                            ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                            ->order('s.id desc')
                            ->field('s.id, g.id as gid, s.skus, s.stock, s.price, s.specs, gc.id as gc_id, gc.cate_name, g.gimages, g.gname, g.gdetail, g.sales_volume')
                            ->findOrEmpty();
                        $goods->withAttr('gimages', function ($value, $data) {
                            if (is_array(json_decode($value, true))) {
                                foreach (json_decode($value, true) as $item) {
                                    $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                                }
                            }
                            return $path_goods;
                        })->withAttr('sales_volume', function ($value, $data) {
                            if ($value == null) {
                                return 0;
                            } else {
                                return $value;
                            }
                        });
                        array_push($goods_list, $goods);
                    }
                }else{
                    return $this->jsonFailed('请传入正确的库存id数组', '2000');
                }

                if (!empty($goods_list)) {
                    return $this->jsonResult(true, $goods_list, '信息返回', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }


            } catch (DbException $e) {
                throw  $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 订单确认 - 立即购买 结算
     */
    public function buyNow()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'address_id|地址id' => 'require|integer',
                'gid|商品id' => 'require|integer',
                'goods_num|商品数量' => 'require|integer',
                'stockId|库存id' => 'require|integer',
                'reduceIntegral|消耗积分数量' => 'require',
                'totalPrice|总价' => 'require',
//                'order_info|订单说明' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                // 准备商品结算信息，对下单条件校验
                // 检查库存
                $stock = Stock::where('s.id', $post['stockId'])
                    ->alias('s')
                    ->leftJoin('td_goods g', 'g.id = s.gid')
                    ->leftJoin('td_goods_cate gc','gc.id = g.gc_id')
                    ->where('gc.status',1)
                    ->where('g.id', $post['gid'])
                    ->where('g.status',1)
                    ->field('s.skus,s.stock,s.price,s.specs')
                    ->findOrEmpty();
                if (!$stock->isEmpty()) {
                    //查询出库存
                    if ($post['goods_num'] > $stock['stock']) {
                        // 库存不足
                        return $this->jsonFailed('该商品库存不足','2001');
                    }else{
                        //准备商品结算信息
                        $equal = Integconfig::where('key', 'equal')
                            ->field('integ_num')
                            ->findOrEmpty();
                        if (!$equal->isEmpty()) {
                            $total_price = bcmul($post['goods_num'], $stock['price'], 2);// 相乘
                            $subPrice = bcdiv($post['reduceIntegral'], $equal['integ_num'], 2);//相除
                            $totalPrice = bcsub($total_price, $subPrice, 2);//相减
                            if (true) {
                                // 检查商品实际金额是否正确
                                if ($post['totalPrice'] != $totalPrice) {
                                    return $this->jsonFailed('总价提交错误','2001');
                                }
                            }
                            $goods =  [
                                'stock_id' => $post['stockId'],
                                'gid' => $post['gid'],
                                'goods_num' => $post['goods_num'],
                                'skus' => $stock['skus'],
                                'price' => $stock['price'],
                                'specs' => $stock['specs']
                            ];
                            //必须有wx_openid
                            if (is_null($this->user->wx_openid)) {
                                return $this->jsonFailed('请授权登录', '2003');
                            }
                            $res = Order::makeOrder($post['address_id'], $this->uid, $this->user->wx_openid,[$goods], $totalPrice, $post['reduceIntegral'], $post['order_info'], false);//返回订单对象
                            if (false === $res) {
                                return $this->jsonFailed('生成订单失败', '2001');
                            }else{
                                if ($post['totalPrice'] == '0') {
                                    Db::startTrans();
                                    try {
                                        /**
                                         * 检查订单状态是否为待支付
                                         */
                                        if (10 !== $res->order_status) {
                                            return $this->jsonFailed('订单状态错误', '2001');
                                        }
                                        /**
                                         *更新销量， 并写入站内信 更新库存
                                         */
                                        $res->order_status = 20;
                                        $res->pay_time = date('Y-m-d H:i:s', time());
                                        $res->save();
                                        $order_goods = OrderGoods::where('oid', $res->id)
                                            ->field('gid, gname, number, gtype, stock_id')
                                            ->select();
                                        /**
                                         * 如果本次立即购买为虚拟商品（立即购买只能购买一种商品）
                                         * 直接订单状态改为40
                                         */
                                        if (1 === count($order_goods)
                                            and intval($order_goods['0']['gtype']) === 2) {
                                            $res->order_status = 40;
                                            $res->save();
                                        }
                                        $goods_name = '';
                                        foreach ($order_goods as $goods) {
                                            $goods_name .= $goods['gname'];
                                            Goods::where('id', $goods['gid'])
                                                ->setInc('sales_volume', $goods['number']);
                                            //更新库存
                                            Stock::where('id', $goods['stock_id'])
                                                ->setDec('stock', $goods['number']);
                                        }
                                        $notice = Notice::create([
                                            'uid' => $res->uid,
                                            'nt_id' => 1,
                                            'message' => '您于' . $res->pay_time . '购买' . $goods_name .'成功！',
                                            'status' => 2
                                        ]);
                                        /**
                                         * step 3 如果是虚拟商品 将cdkey与用户绑定并记录支付时间
                                         */
                                        if (!$order_goods->isEmpty()) {
                                            foreach ($order_goods as $goods) {
                                                if ($goods['gtype'] == 2) {
                                                    //为虚拟商品
                                                    $count = CDKey::where('gid', $goods['gid'])
                                                        ->where('status', 1)
                                                        ->count();
                                                    $cd_keys = CDKey::where('gid', $goods['gid'])
                                                        ->where('status', 1)
                                                        ->select();
                                                    if ($count > $goods['number']) {
                                                        /**
                                                         * cdkey绑定用户并修改状态
                                                         */
                                                        for ($i = 0; $i < $goods['number']; $i++) {
                                                            CDKey::where('gid', $goods['gid'])
                                                                ->where('status', 1)
                                                                ->limit(1)
                                                                ->update([
                                                                    'status' => 2,
                                                                    'pay_time' => $res->pay_time,
                                                                    'uid' => $res->uid
                                                                ]);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        /**
                                         * 扣除该订单的消耗积分， 并将积分日志写入
                                         */
                                        $user = \app\api\model\User::get($this->uid);
                                        if ($post['reduceIntegral'] > $this->user->integral) {
                                            return $this->jsonFailed('积分不足', '2001');
                                        }
                                        $user->integral -= $post['reduceIntegral'];
                                        $user->save();
                                        /**
                                         * 积分变更日志写入
                                         */
                                        $addLog = [
                                            'uid' => $user->id,
                                            'operation' => '购买商品',
                                            'number' => -$post['reduceIntegral'],
                                            'create_time' => date('Y-m-d H:i:s', time()),
                                            'update_time' => date('Y-m-d H:i:s', time()),
                                        ];
                                        Db::name('integ_log')
                                            ->insertGetId($addLog);

                                        Db::commit();
                                        return $this->jsonResult(true, null, '支付成功', '2000');
                                    } catch (DbException $e) {
                                        Db::rollback();
                                        return $this->jsonFailed('server error', '2001');
                                    }
                                }
//                                return $this->jsonResult(true, ['orderId' => $res], '生成订单成功', '2000');
                                // 发起微信支付
                                $WxPay = new WxPay(config('wxconfig.wx_config.appid'));
                                $response = $WxPay->unifiedorder($res->order_num, $this->user->wx_openid, $res->total_price);
                                if ($response) {
                                    $data = [
                                        'payment' => $response
                                    ];
                                    return $this->jsonResult(true, $data, '支付信息', '2000');
                                }else{
                                    return $this->jsonFailed('错误', '2001');
                                }
                            }
                        }
                    }
                }else{
                    //没有查询出库存
                    return $this->jsonFailed('没有数据','2001');
                }
                //创建订单
            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }

    /**
     * 加入购物车
     */
    public function addCar()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'stock_id|库存表id' => 'require|integer',
                'goods_id|商品id' => 'require|integer',
                'goods_num|商品数量' => 'require|integer',
//                'goods_skus|商品sku组合' => ''
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //校验sku组合和stock_id一致性
                $skus = Stock::where('id', $post['stock_id'])
                    ->field('skus')
                    ->findOrEmpty();
                if ($this->request->has('goods_skus','param')) {
                    if (!$skus->isEmpty() && $skus['skus'] != $post['goods_skus']) {
                        return $this->jsonFailed('商品sku组合与stock_id不一致','2001');
                    }
                }else{
                    $post['goods_skus'] = null;
                }
                $shoppingCar = Car::where('uid', $this->uid)
                    ->where('stock_id', $post['stock_id'])
                    ->findOrEmpty();
                if (!$shoppingCar->isEmpty()) {
                    //之前该商品的对应的规格组合已经加入过购物车 则更新数量
                    $shoppingCar->goods_num += $post['goods_num'];
                    $res = $shoppingCar->save();
                }else{
                    $addCar = [
                        'stock_id' => $post['stock_id'],
                        'goods_id' => $post['goods_id'],
                        'goods_num' => $post['goods_num'],
                        'goods_skus' => $post['goods_skus'],
                        'uid' => $this->uid
                    ];
                    $res = Car::create($addCar);
                }

                if ($res) {
                    return $this->jsonResult(true, null, '添加购物车成功', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 购物车列表
     */
    public function shoppingCarList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $list = Car::where('c.uid', $this->uid)
                    ->where('gc.status', 1)
                    ->where('g.status', 1)
                    ->alias('c')
                    ->leftJoin('td_stock s', 's.id = c.stock_id')
                    ->leftJoin('td_goods g', 'g.id = c.goods_id')
                    ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                    ->page($post['page'], $this->page_count)
                    ->field('c.id, g.id as goods_id, g.gname as goods_name, g.gimages as goods_images, g.gintro, g.sales_volume, s.id as stock_id, s.skus as goods_skus, s.stock, s.price, s.specs, c.goods_num')
                    ->select();
                if (!$list->isEmpty()) {
                    $list->withAttr('goods_images', function ($value, $data) {
                        if (is_array(json_decode($value, true))) {
                            foreach (json_decode($value, true) as $item) {
                                $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                            }
                        }
                        return $path_goods;
                    });
                }
                if (!$list->isEmpty()) {
                    return $this->jsonResult(true, $list, '购物车列表', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     *批量删除购物车的商品数据
     */
    public function batchDeleteShoppingCarItem()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'car_ids|购物车id集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $car_ids = json_decode($post['car_ids'],true);
                if (is_array($car_ids)) {
                    foreach ($car_ids as $key => $car_id) {
                        $res = Car::destroy($car_id);
                    }
                    Db::commit();
                    return $this->jsonResult(true, null, '购物车清除成功', '2000');
                }else{
                    return $this->jsonFailed('购物车id集合类型错误', '2001');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 从购物车下单 结算
     */
    public function shoppingCartPurchase()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'address_id|地址id' => 'require|integer',
                'goods_list|购买商品信息' => 'require',
                'reduceIntegral|消耗积分数量' => 'require',
                'totalPrice|总价' => 'require',
//                'order_info|订单说明' => 'require'
            ];
            /**
             * goods_list 包含的信息 json类型
             *  car_id 商品购物车id
             * 'gid|商品id' => 'require|integer',
             * 'goods_num|商品数量' => 'require|integer',
             * 'stockId|库存id' => 'require|integer',
             */
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查商品库存  准备下单信息
                $goods_list = json_decode($post['goods_list'], true);
                $equal = Integconfig::where('key', 'equal')
                    ->field('integ_num')
                    ->findOrEmpty();
                $total_price = 0;
                $goods_order_list = [];
                if (is_array($goods_list)) {
                    foreach ($goods_list as $key => $goods) {
                        $stock = Stock::where('s.id', $goods['stockId'])
                            ->alias('s')
                            ->leftJoin('td_goods g', 'g.id = s.gid')
                            ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                            ->where('gc.status', 1)
                            ->where('g.status', 1)
                            ->field('s.id, s.skus, s.stock, s.price, s.specs')
                            ->findOrEmpty();
                        if ($stock->isEmpty()) {
                            return $this->jsonFailed('该商品已下架', '2001');
                        }else{
                            if ($goods['goods_num'] > $stock['stock']) {
                                return $this->jsonFailed('该商品库存不足', '2001');
                            }else{
                                //计算总价
                                $total_price += bcmul($stock['price'], $goods['goods_num'], 2);
                                //填充购买商品信息列表
                                $goods_order_list[] =  [
                                    'car_id' => $goods['car_id'],
                                    'stock_id' => $stock['id'],
                                    'gid' => $goods['gid'],
                                    'goods_num' => $goods['goods_num'],
                                    'skus' => $stock['skus'],
                                    'price' => $stock['price'],
                                    'specs' => $stock['specs']
                                ];
                            }
                        }
                    }
                    $subPrice = bcdiv($post['reduceIntegral'], $equal['integ_num'], 2);
                    $totalPrice = bcsub($total_price, $subPrice, 2);
                    if (true) {
                        //计算积分和消费是否正确
                        if ($post['totalPrice'] != $totalPrice) {
                            return $this->jsonFailed('总价提交错误', '2001');
                        }
                    }
                    //必须有wx_openid
                    if (is_null($this->user->wx_openid)) {
                        return $this->jsonFailed('请授权登录', '2003');
                    }
//                    self::ReturnAjax(2000, '', $goods_order_list);
                    //创建购物车订单
                    $res = Order::makeOrder($post['address_id'], $this->uid, $this->user->wx_openid,$goods_order_list, $totalPrice, $post['reduceIntegral'], $post['order_info'], true);
                    if (false === $res) {
                        return $this->jsonFailed('生成订单失败', '2001');
                    }else{
                        if ($post['totalPrice'] == '0') {
                            Db::startTrans();
                            try {
                                /**
                                 * 检查订单状态是否为待支付
                                 */
                                if (10 !== $res->order_status) {
                                    return $this->jsonFailed('订单状态错误', '2001');
                                }
                                /**
                                 *更新销量， 并写入站内信
                                 */
                                $res->order_status = 20;
                                $res->pay_time = date('Y-m-d H:i:s', time());
                                $res->save();
                                $order_goods = OrderGoods::where('oid', $res->id)
                                    ->field('gid, gname, number, gtype, stock_id')
                                    ->select();
                                $goods_name = '';
                                $length = 0;
                                foreach ($order_goods as $goods) {
                                    $goods_name .= $goods['gname'];
                                    Goods::where('id', $goods['gid'])
                                        ->setInc('sales_volume', $goods['number']);
                                    //更新库存
                                    Stock::where('id', $goods['stock_id'])
                                        ->setDec('stock', $goods['number']);
                                    if (2 === $goods['gtype']) {
                                        ++$length;
                                    }
                                }
                                /**
                                 * 如果本次购买的所有商品为虚拟商品
                                 * 直接订单状态改为40
                                 */
                                if ($length === count($order_goods)) {
                                    $res->order_status = 40;
                                    $res->save();
                                }
                                $notice = Notice::create([
                                    'uid' => $res->uid,
                                    'nt_id' => 1,
                                    'message' => '您于' . $res->pay_time . '购买' . $goods_name .'成功！',
                                    'status' => 2
                                ]);
                                /**
                                 * step 3 如果是虚拟商品 将cdkey与用户绑定并记录支付时间
                                 */
                                if (!$order_goods->isEmpty()) {
                                    foreach ($order_goods as $goods) {
                                        if ($goods['gtype'] == 2) {
                                            //为虚拟商品
                                            $count = CDKey::where('gid', $goods['gid'])
                                                ->where('status', 1)
                                                ->count();
                                            $cd_keys = CDKey::where('gid', $goods['gid'])
                                                ->where('status', 1)
                                                ->select();
                                            if ($count > $goods['number']) {
                                                /**
                                                 * cdkey绑定用户并修改状态
                                                 */
                                                for ($i = 0; $i < $goods['number']; $i++) {
                                                    CDKey::where('gid', $goods['gid'])
                                                        ->where('status', 1)
                                                        ->limit(1)
                                                        ->update([
                                                            'status' => 2,
                                                            'pay_time' => $res->pay_time,
                                                            'uid' => $res->uid
                                                        ]);
                                                }
                                            }
                                        }
                                    }
                                }
                                /**
                                 * 扣除该订单的消耗积分， 并将积分日志写入
                                 */
                                $user = \app\api\model\User::get($this->uid);
                                if ($post['reduceIntegral'] > $this->user->integral) {
                                    return $this->jsonFailed('积分不足', '2001');
                                }
                                $user->integral -= $post['reduceIntegral'];
                                $res = $user->save();
                                /**
                                 * 积分变更日志写入
                                 */
                                $addLog = [
                                    'uid' => $user->id,
                                    'operation' => '购买商品',
                                    'number' => -$post['reduceIntegral'],
                                    'create_time' => date('Y-m-d H:i:s', time()),
                                    'update_time' => date('Y-m-d H:i:s', time()),
                                ];
                                Db::name('integ_log')
                                    ->insertGetId($addLog);

                                Db::commit();
                                return $this->jsonResult(true, null, '支付成功', '2000');
                            } catch (DbException $e) {
                                Db::rollback();
                                return $this->jsonFailed('server error', '2001');
                            }
                        }
//                        return $this->jsonResult(true, ['orderId' => $res], '生成订单成功', '2000');
                        //发起微信支付
                        $wxPay = new WxPay(config('wxconfig.wx_config.appid'));
                        $response = $wxPay->unifiedorder($res->order_num, $this->user->wx_openid, $res->total_price);
                        if ($response) {
                            $data = [
                                'payment' => $response
                            ];
                            return $this->jsonResult(true, $data, '支付信息', '2000');
                        }else{
                            return $this->jsonFailed('错误', '2001');
                        }
                    }
                }
            } catch (DbException $e) {
//                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
