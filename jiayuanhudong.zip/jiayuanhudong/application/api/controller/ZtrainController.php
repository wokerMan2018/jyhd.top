<?php

namespace app\api\controller;

use app\admin\model\Article;
use app\admin\model\Comments;
use app\admin\model\TrainingClassification;
use app\api\model\Collection;
use app\api\model\ReadOrder;
use app\api\service\ArticleService;
use app\api\service\CollectionService;
use app\api\service\CommentService;
use app\api\service\WordFilter;
use app\common\library\wechat\WxPay;
use think\exception\DbException;
use think\facade\Request;
use think\response\Json;

/**
 * 培训 菜单 接口
 * Class ZtrainController
 * @package app\api\controller
 */
class ZtrainController extends BaseController
{
    const  PUSH_PLATE_TRAIN = 1;
    const  PUSH_PLATE_INFO = 2;

    /**
     * 获取培训分类数据
     * @return Json
     */
    public function trainingClassification()
    {
        if ($this->request->isPost()) {
            $all = TrainingClassification::order('tc.id', 'asc')
                ->alias('tc')
                ->field('tc.id as tc_id, tc.type_name')
                ->selectOrFail();
            if ($all->isEmpty()) {
                return $this->jsonFailed('没有数据', '2001');
            }else{
                return $this->jsonResult(true, $all, '分类信息', '2000');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 培训列表  page 培训
     */
    public function trainList()
    {
        $userType = $this->user->u_type;
        //$userType = 2;
        $pageNum = $this->request->get('page/d');
        $classification = $this->request->get('tc_id/d');
        $pageNum = $pageNum ? $pageNum : 1;
        $Article = ArticleService::articleList($userType, self::PUSH_PLATE_TRAIN, $pageNum, $classification, $this->page_count);
//        return $this->jsonSuccess($Article, 'success');
        if ($Article) {
            return $this->jsonResult(true, $Article, 'success', '2000');
        }else{
            return $this->jsonFailed('没有数据', '2001');
        }
    }

    /**
     * 培训详情  page 培训 - 详情
     */
    public function trainDetail()
    {
        $userType = intval($this->user->u_type);

        $articleId = $this->request->get('id/d');

        if (!$articleId) {
//            $this->jsonFailed('could not find articles by null Id', 4004);
            $this->jsonFailed('could not find articles by null Id', '2001');
        }
        $Article = ArticleService::articleDetail($userType, $articleId, self::PUSH_PLATE_TRAIN, $this->uid);
//        return $this->jsonSuccess($Article, 'success');
        if ($Article) {
            return $this->jsonResult(true, $Article, 'success', '2000');
        }else{
            return $this->jsonFailed('没有数据', '2001');
        }
    }

    /**
     *在某一培训详情 下 添加留言
     */
    public function addComment()
    {
        if ($this->request->isPost()) {
            $param['content'] = $this->request->post('content');
            $param['articleId'] = $this->request->post('article_id');
            $rule = [
                'articleId|培训ID' => 'require|integer',
                'content|评论内容' => 'require|length:4,80',
            ];
            $res = $this->validate($param, $rule);
            if (true !== $res) {
//                return $this->jsonFailed($res, 2001);
                return $this->jsonFailed($res, '2001');
            }
            /**
             * 检查评论内容是否合法
             */
            if (false !== WordFilter::wordCheck($param['content'])) {
                return $this->jsonFailed('评论内容包含违规内容，请重试！', '2001');
            }

            $userType = $this->user->u_type;
//            $userType = 2;
            $Article = ArticleService::articleDetail($userType,$param['articleId'],self::PUSH_PLATE_TRAIN, $this->uid);
            if (!$Article){
//                return $this->jsonFailed('没有评论指定培训的权限或培训不存在',4003);
                return $this->jsonFailed('没有评论指定培训的权限或培训不存在','2001');
            }

            $data = [
                'uid' => $this->uid,
                'aid' => $param['articleId'],
                'content' => $param['content'],
                'status' => 1
            ];

            $res = Comments::create($data);

            if (false !== $res) {
//                return $this->jsonSuccess([], 'success');
                return $this->jsonResult(true, null, '添加评论成功', '2000');
            } else {
//                return $this->jsonFailed('add comment fail', 2001);
                return $this->jsonFailed('add comment fail', '2001');
            }
        } else {
//            return $this->jsonFailed('wrong submit method', 4003);
            return $this->jsonFailed('wrong submit method', '2001');
        }
    }

    /**
     *在某条资讯  - 某条评论 下点赞 page 培训 - 详情
     */
    public function like()
    {
        if ($this->request->isPost()) {
            $param['commentId'] = $this->request->post('comment_id');
            $param['like'] = $this->request->post('like');
            $rule = [
                'commentId|评论ID' => 'require|integer',
                'like|点赞' => 'require|eq:1',
            ];
            $res = $this->validate($param, $rule);
            if (true !== $res) {
//                return $this->jsonFailed($res, 2001);
                return $this->jsonFailed($res, '2001');
            }

            $res = CommentService::like($param['commentId'], $this->uid);
            if (false === $res) {
//                return $this->jsonFailed('add comment fail', 2001);
                return $this->jsonFailed(' fail', '2001');
            }
//            return $this->jsonSuccess([], 'success');
            return $this->jsonResult(true, null, 'success', '2000');
        } else {
//            return $this->jsonFailed('wrong method', 4003);
            return $this->jsonFailed('wrong method', '2001');
        }
    }

    /**
     * 判断指定文章是否被该用户收藏
     * @return Json
     */
    public function isCollect()
    {
        $articleId = $this->request->get('article_id');
        if (!$articleId) {
//            return $this->jsonFailed('培训ID必须', 2001);
            return $this->jsonFailed('培训ID必须', '2001');
        }

        $Article = Article::get($articleId);
        if (!$Article) {
//            return $this->jsonFailed('培训未找到', 4004);
            return $this->jsonFailed('培训未找到', '2001');
        }

        $uid = $this->uid;
        //测试uid
        //$uid = 43;

        $res = CollectionService::isCollect($uid, $articleId);
//        return $this->jsonSuccess(['isCollect' => $res], 'success');
        return $this->jsonResult(true, ['isCollect' => $res], 'success', '2000');

    }

    /*
    * 在某条培训下 点击收藏与取消收藏 --page 培训 - 详情
    * @return \think\response\Json
    */
    public function addCollection()
    {
        if (Request::isPost()) {
            $articleId = $this->request->post('article_id/d');
            if (!$articleId) {
//                return $this->jsonFailed('培训ID必须', 2001);
                return $this->jsonFailed('培训ID必须', '2001');
            }

            $Article = ArticleService::articleDetail($this->user->u_type,$articleId,self::PUSH_PLATE_TRAIN, $this->uid);
            if (!$Article){
//                return $this->jsonFailed('没有评论指定培训的权限或培训不存在',4003);
                return $this->jsonFailed('没有评论指定培训的权限或培训不存在','2001');
            }

            $uid = $this->uid;
//            $res = Collection::create(['uid' => $uid, 'aid' => $articleId]);
            $res = CollectionService::collect($articleId, $uid);
            if (false !== $res) {
//                return $this->jsonSuccess([], 'success');
                return $this->jsonResult(true, null, 'success', '2000');
            }
//            return $this->jsonFailed('fail', 4004);
            return $this->jsonFailed('fail', '2001');
        }
//        return $this->jsonFailed('wrong method', 4003);
        return $this->jsonFailed('wrong method', '2001');
    }
}
