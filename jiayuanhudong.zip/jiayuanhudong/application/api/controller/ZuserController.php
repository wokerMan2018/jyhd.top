<?php

namespace app\api\controller;

use app\admin\model\Article;
use app\admin\model\Classes;
use app\admin\model\Comments;
use app\admin\model\Homework;
use app\admin\model\Integconfig;
use app\admin\model\Regicode;
use app\admin\model\Remark;
use app\admin\model\Solution;
use app\api\model\Address;
use app\api\model\Attention;
use app\api\model\CourseComments;
use think\Controller;
//use think\Request;
use think\Db;
use think\facade\Cache;
use think\facade\Request;
use app\common\library\wechat\WxUser;
use app\admin\model\User;
use think\facade\Session;
use app\facade\Jwt;
use think\exception\DbException;

/**
 * 用户相关接口 函数
 * Class ZuserController
 * @package app\api\controller
 */
class ZuserController extends BaseController
{
    const USER_HIDDEN_FIELDS = ['password', 'withdraw_pwd', 'wx_openid', 'delete_time'];
    protected $exceptAuthActions = ['test','login', 'registeraccount','getsmscode', 'changepassword'];

    public function test()
    {
        $ss = Session::get('18871497906', 'sms');
        dump($ss);
        $phone = '15812345678';
        $detail = [
            'phone'=>$phone,
            'code'=>'123456',
            'time'=>time()
        ];
        Session::set($phone,$detail,'sms');
        Session::get($phone, 'sms');
    }
    /**
     * 获取教师信息
     */
    public function getTeacherInfo()
    {
        if (Request::isPost()){
            if (2 !== $this->user->u_type) {
                return $this->jsonFailed('用户类型错误', '2001');
            }
//            self::auth();
            $userInfo = Db::name('user')
                ->alias('u')
                ->join('td_school s','s.id = u.sids')
                ->join('td_grade g','g.id = u.graids')
                ->field('s.name,g.graname,u.cids,u.gender,u.birthday,u.username')
                ->where(['u.id'=>$this->user->id])
                ->find();
            if ($userInfo){
                $ids = explode(',', $userInfo['cids']);
                if (is_array($ids)) {
                    //补充过信息
                    $userInfo['isSuppleInfo'] = true;
                    foreach ($ids as $key => $value) {
                        $classname = Db::name('class')
                            ->where('id', $value)
                            ->field('id,gname')
                            ->find();
                        $class = [
                            'name' => $classname['gname'],
                            'id' => $classname['id']
                        ];
                        $userInfo['class'][] = $class;
                    }
                }else{
                    //没有补充过个人信息
                    $userInfo['isSuppleInfo'] = false;
                    $userInfo['gender'] = null;
                    $userInfo['birthday'] = null;
                    $userInfo['username'] = null;
                }
                return $this->jsonResult(true, $userInfo, '', '2000');
            }else{
                return $this->jsonFailed('没有该用户', '2001');
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }

    }

    /**
     * 获取家长信息
     */
    public function getParentInfo()
    {
        //检查用户类型
        if (3 !== $this->user->u_type) {
            return $this->jsonFailed('用户类型错误', '2001');
        }
        if (Request::isPost()){
//            self::auth();
            $userInfo = Db::name('user')
                ->alias('u')
                ->join('td_school s','s.id = u.sids')
                ->join('td_grade g','g.id = u.graids')
                ->join('td_class c','c.id = u.cids')
                ->field('s.name,g.graname,c.gname,u.s_uid,u.username')
                ->where(['u.id'=>$this->user->id])
                ->find();
            if ($userInfo){
                if ($userInfo['s_uid'] !== null) {
                    //家长信息之前修改过，查询出之前编辑的内容
                    $userInfo['isSuppleInfo'] = true;
                    $res = Db::name('user')
                        ->where('id', $userInfo['s_uid'])
                        ->field('username,gender,birthday')
                        ->find();
                    $userInfo['student'] = $res;
                }else{
                    //家长信息之前没有修改
                    $userInfo['isSuppleInfo'] = false;
                    $userInfo['student'] = null;
                    $userInfo['username'] = null;
                }
                return $this->jsonResult(true, $userInfo, '', '2000');
            }else{
                return $this->jsonFailed('没有该用户', '2001');
            }

        }else{
//            self::ReturnAjax(2001,'请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 获取注册验证码
     */
    public function getSmsCode()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'phone|手机号'=>'require|mobile',
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
//                self::ReturnAjax(2001,$res);
                return $this->jsonFailed($res, '2001');
            }
            $code = str_pad(mt_rand(0, 999999), 6, "0", STR_PAD_BOTH);
            $phone = trim($post['phone']);
//            $result = sendMsg($phone, $code);
            if (env('sms_code') === '123456') {
                $detail = [
                    'phone'=>$phone,
                    'code'=>env('sms_code'),
                    'time'=>time()
                ];
                Session::set($phone,$detail,'sms');
//                self::ReturnAjax(2000,'短信已发送');
                return $this->jsonResult(true,null,'开发模式：短信验证码为123456', '2000');
            }else{
                if ($result = sendMsg($phone, $code) and $result['Code'] == 'OK'){
                    $detail = [
                        'phone'=>$phone,
                        'code'=>$code,
                        'time'=>time()
                    ];
                    Session::set($phone,$detail,'sms');
//                self::ReturnAjax(2000,'短信已发送');
                    return $this->jsonResult(true,null,'短信已发送', '2000');
                }else{
//                self::ReturnAjax(2001,'',$result);
                    return $this->jsonFailed('','2001',$result);
                }
            }

        }else{
//            self::ReturnAjax(2001,'请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 注册账号
     */
    public function registerAccount()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'userType'=>'require',
                'code'=>'require',
                'nickName'=>'require',
                'avatarUrl'=>'require',
                'gender'=>'require',
                'smsCode|验证码'=>'require',
                'phone|手机号'=>'require|mobile',
                'password|密码'=>'require|length:3,20|alphaNum'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
//                self::ReturnAjax(2001,$res);
                return $this->jsonFailed($res, '2001');
            }
            $app = [
                'app_id'=>config('wxconfig.wx_config.appid'),
                'app_secret'=>config('wxconfig.wx_config.secret')
            ];
            $wxUser = new WxUser($app['app_id'],$app['app_secret']);
            $session_key = $wxUser->sessionKey($post['code']);
            if (!$session_key){
                throw new \Exception(['msg'=>$wxUser->getError()]);
            }
            /**
             * 查询注册码是否有效
             */
            $regicode =  Regicode::get(function ($query) use ($post){
                $query->where(['rtype'=>($post['userType'] - 1),'number'=>$post['regi_code'],'status'=>1]);
            });
            if (!is_object($regicode)) {
                return $this->jsonFailed('注册码使用错误', '2001');
            }
            if ($regicode->number){
                $regicode->status = 2;
                $regicode->use_time = date('Y-m-d H:i:s',time());
                $regicode->phone = $post['phone'];
                $regicode->save();
            }else{
//                self::ReturnAjax(2001,'注册码无效');
                return $this->jsonFailed('注册码无效', '2001');
            }
            /**
             * 判断验证码有效性
             */
//            if (Session::has(trim($post['phone']),'sms')){
                if ($detail = Session::get(trim($post['phone']),'sms')){
                    $expire = intval(env('sms_expire')); //过期时间为 60s
                    if (time() - $detail['time'] > $expire){
//                        self::ReturnAjax(2001,'验证码超时');
                        return $this->jsonFailed('验证码超时', '2001');
                    }
                    if ($post['smsCode'] != $detail['code']){
//                        self::ReturnAjax(2001,'验证码错误');
                        return $this->jsonFailed('验证码错误', '2001');
                    }
                }
//            }else{
////                self::ReturnAjax(2001,'code failure');
//                return $this->jsonFailed('code failure', '2001');
//            }
            $bool = User::where(['wx_openid'=>$session_key['openid']])->find();
            if (!$bool){
                $user = User::create([
                    'u_type'=>$post['userType'],
                    'username'=>$post['nickName'],
                    'password'=>User::genPassword($post['password']),
                    'nickname'=>$post['nickName'],
                    'photo_url'=>$post['avatarUrl'],
                    'gender'=>$post['gender'],
                    'regi_code'=>$post['regi_code'],
                    'phone'=>$post['phone'],
                    'last_login_ip'=>ip2long(Request::ip()),
                    'last_login_time'=>date('Y-m-d H:i:s',time()),
                    'enable'=>1,
                    'wx_openid'=>$session_key['openid'],
                    'sids'=>$regicode->sid,
                    'graids'=>$regicode->gid,
                    'cids' => $regicode->cid,
                    'auth_type'=>0
                ]);
//                $token = Jwt::login($user, '','', $auto =true);
                //使用框架jwt token
                $auth_token = self::handlerUserLogin($user);

                //确定用户权限类型
                if ($post['userType'] === '2'){
                    //老师 登录未补全信息
                    $user->auth_type = 5;
                }elseif ($post['userType'] === '3'){
                    //家长 登录未补全信息
                    $user->auth_type = 3;
                }elseif ($post['userType'] === '4'){
                    // 游客 填写手机
                    $user->auth_type = 2;
                }
                $auth = $user->auth_type;
                $user->save();
            }else{
                $update_data = [
                    'last_login_ip'=>ip2long(Request::ip()),
                    'last_login_time'=>date('Y-m-d H:i:s',time()),
                    'sids'=>$regicode->sid,
                    'graids'=>$regicode->gid,
                    'cids'=>$regicode->cid
                ];
                User::where(['id'=>$bool->id])->update($update_data);
//                $token =Jwt::login($bool,'','',$auto = true);
                //使用框架jwt token
                $auth_token = self::handlerUserLogin($bool);
                //确定用户权限类型
                if ($post['userType'] === '2'){
                    //老师 登录未补全信息
                    $bool->auth_type = 5;
                }elseif ($post['userType'] === '3'){
                    //家长 登录未补全信息
                    $bool->auth_type = 3;
                }elseif ($post['userType'] === '4'){
                    // 游客 填写手机
                    $bool->auth_type = 2;
                }
                $auth = $bool->auth_type;
                $bool->save();
                $user = $bool;
            }
//            Cache::set($token,$session_key,86400*7);
//            $response = [
//                'token'=>$token,
//                'userType'=>$post['userType'],
//                'userAuthType'=>$auth
//            ];
            $user_data = $user->hidden(self::USER_HIDDEN_FIELDS)
                ->toArray();
            $response = [
                'X-AUTH-TOKEN' => $auth_token,
                'user' => $user_data
            ];
            //用户登录成功后 为用户新增相应积分
            $number = Integconfig::where('key', 'login')
                ->field('integ_num')
                ->findOrEmpty();
            $user->integral += $number['integ_num'] * 5;
            $user->save();
            $response['integer_number'] = $number['integ_num'] * 5;
            /**
             * 积分变更日志写入
             */
            $add = [
                'uid' => $user->id,
                'operation' => '登录成功',
                'number' => $number['integ_num']*5,
                'create_time' => date('Y-m-d H:i:s', time()),
                'update_time' => date('Y-m-d H:i:s', time()),
            ];
            Db::name('integ_log')
                ->insertGetId($add);
            /**
             * 如果身份为家长的用户注册成功， 则写入该家长的未提交作业数据
             */
            if (is_array($response) and count($response) > 0) {
                //家长身份注册
                if ($post['userType'] === '3') {
                    /**
                     * step 1 查询该家长所属班级已发布的作业列表
                     */
                    $hids = Homework::where('cid', $user->cids)
                        ->where('status', 1)//作业状态为已发布
                        ->field('id')
                        ->order('id', 'asc')
                        ->select();
                    /**
                     * step 2 写入该家长未提交作业列表
                     */
                    if (!$hids->isEmpty()) {
                        foreach ($hids as $hid) {
                            $addSolution = [
                                'uid' => $user->id,
                                'cid' => $user->cids,
                                'hid' => $hid['id'],
                                'status' => 0,
                                'type' => 1
                            ];
                            Solution::create($addSolution);
                        }
                    }
                }
            }
//            self::ReturnAjax(2000,'注册成功',$response);
            return $this->jsonResult(true, $response, '注册成功', '2000');

        }else{
//            self::ReturnAjax(2001,'请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     *鉴权 废弃
     */
    protected function auth()
    {
        try{
            $this->user=Jwt::auth();
        }catch (\Exception $e){
            self::ReturnAjax(2001,'请先登录');
        }
    }
    /**
     * 获取某个年级下所有班级名称和id
     */
    public function getClasses()
    {
        $gradeId = $this->user->graids;
        $classes = Classes::where('graid', $gradeId)
            ->field('id as cid,gname')
            ->select();
        if (!$classes->isEmpty()) {
            return $this->jsonResult(true, $classes, '返回数据', '2000');
        }else{
            return $this->jsonFailed('没有数据', '2001');
        }
    }

    /**
     * 修改账号信息
     */
    public function changeAccount()
    {
        if (Request::isPost()){
//            self::auth();
            $post = Request::param();
            $rule = [
                'userType|用户类型'=> 'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
//                self::ReturnAjax(2001,$res);
                return $this->jsonFailed($res, '2001');
            }
            if ($post['userType'] === '3'){
                //家长
                //todo 学生数量  更新问题
                $rule = [
                    'sgender|学生性别'=>'require|number',
                    'sbirthday|学生生日'=>'require',
                    'sname|学生姓名'=>'require',
                    'pname|家长姓名'=>'require',
                ];
                $res = $this->validate($post,$rule);
                if (true !== $res){
//                    self::ReturnAjax(2001,$res);
                    return $this->jsonFailed($res, '2001');
                }
                /**
                 * 检查名字是否使用过
                 */
                $nameCount = User::where('username', $post['sname'])
                    ->count();
                $namePName = User::where('username', $post['pname'])
                    ->count();
                if ($nameCount > 0 or $namePName > 0) {
                    return $this->jsonFailed('该姓名已经使用，请更换', '2001');
                }
                if ($this->user->s_uid){
                    //更新学生信息
                    $student = User::where(['id'=>$this->user->s_uid])->find();
                    $student->gender = $post['sgender'];
                    $student->birthday = $post['sbirthday'];
                    $student->username = $post['sname'];
                    $student->save();
                }else{
                    //新增学生信息
                    $student = User::create([
                        'gender'=>$post['sgender'],
                        'birthday'=>$post['sbirthday'],
                        'username'=>$post['sname'],
                    ]);
                    $this->user->s_uid = $student->id;
                }
                $this->user->username = $post['pname'];
                /**
                 * 家长补全信息后，更新auth_type
                 */
                $this->user->auth_type = 4;
                $bool = $this->user->save();

            }
            if ($post['userType'] === '2'){
                //教师
                $rule = [
                    'classes|所在班级'=>'require',
                    'teacherName|老师姓名'=>'require',
                    'teacherGender|老师性别'=>'require',
                    'teacherBirthday|老师生日'=>'require',
                ];
                $res = $this->validate($post,$rule);
                if (true !== $res){
//                    self::ReturnAjax(2001,$res);
                    return $this->jsonFailed($res, '2001');
                }
                /**
                 * 检查名字是否使用过
                 */
                $teacherNameCount = User::where('username', $post['teacherName'])
                    ->count();
                if ($teacherNameCount > 0) {
                    return $this->jsonFailed('该姓名已经使用，请更换', '2001');
                }
                //todo 老师添加信息
                $this->user->username = $post['teacherName'];
                $this->user->gender = $post['teacherGender'];
                $this->user->birthday = $post['teacherBirthday'];
                //classes 字段以','号隔开id的字符串
                $this->user->cids = $post['classes'];
                /**
                 * 教师补全信息后，更新auth_type
                 */
                $this->user->auth_type = 6;
                $bool = $this->user->save();
            }
            if ($post['userType'] === '4'){
                $rule = [
                    'gender|性别'=>'require',
                    'birthday|生日'=>'require',
                    'name|姓名'=>'require'
                ];
                $res = $this->validate($post,$rule);
                if (true !== $res){
//                    self::ReturnAjax(2001,$res);
                    return $this->jsonFailed($res, '2001');
                }
                /**
                 * 检查名字是否使用过
                 */
                $touristsNameCount = User::where('username', $post['name'])
                    ->count();
                if ($touristsNameCount > 0) {
                    return $this->jsonFailed('该姓名已经使用，请更换', '2001');
                }
                $this->user->username = $post['name'];
                $this->user->birthday = $post['birthday'];
                $this->user->gender = $post['gender'];
                /**
                 * 游客补全信息后，更新auth_type
                 */
                $this->user->auth_type = 2;
                $bool = $this->user->save();

            }
            if ($bool){
//                self::ReturnAjax(2000,'修改信息成功');
//                return $this->jsonFailed('修改信息成功', '2000');
                return $this->jsonResult(true, ['auth_type' => $this->user->auth_type], '修改信息成功', '2000');
            }
        }else{
//            self::ReturnAjax(2001,'请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 登录接口
     */
    public function login()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'phone|手机号' => 'require|mobile',
                'password|用户密码'=>'require|length:3,20|alphaNum'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
//                self::ReturnAjax(2001, $res);
                return $this->jsonFailed($res, '2001');
            }
            //TODO 用户登录判断
            $user = self::checkPass($post['phone'],$post['password']);
            if (empty($user)) {
//                self::ReturnAjax(2001, '手机号或密码不正确');
                return $this->jsonFailed('手机号或密码不正确', '2001');
            }else{
//                $token = Jwt::login($user,'','',$auto = true);
//                $response = [
//                    'token' => $token,
//                    'userType'=>$user->u_type,
//                    'userAuthType'=>$user->auth_type
//                ];
                $last_login_time = $user->last_login_time;
                $token = $this->handlerUserLogin($user);
                $user_data = $user->hidden(self::USER_HIDDEN_FIELDS)->toArray();
                $response = [
                    'X-AUTH-TOKEN' => $token,
                    'user' => $user_data
                ];
                if (strtotime($user->last_login_time) - strtotime($last_login_time) > 60*60*12) {
                    //用户登录成功后 为用户新增相应积分
                    $number = Integconfig::where('key', 'login')
                        ->field('integ_num')
                        ->findOrEmpty();
                    $user->integral += $number['integ_num'];
                    $user->save();
                    $response['integer_number'] = $number['integ_num'];
                    /**
                     * 积分变更日志写入
                     */
                    $add = [
                        'uid' => $user->id,
                        'operation' => '登录成功',
                        'number' => $number['integ_num'],
                        'create_time' => date('Y-m-d H:i:s', time()),
                        'update_time' => date('Y-m-d H:i:s', time()),
                    ];
                    Db::name('integ_log')
                        ->insertGetId($add);
                    return $this->jsonResult(true, $response, '登录成功， 恭喜你获得'. $number['integ_num']  . '积分', '2000');
                }else{
                    return $this->jsonResult(true, $response, '登录成功', '2000');
                }

            }
        } else {
//            self::ReturnAjax(2001, '请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 登录检查
     */
    protected function checkPass($phone, $pass)
    {
        $user = User::where(['phone'=>$phone])->findOrEmpty();
        if (!$user->isEmpty()){
            $pass_compare = $user->password;
        }else{
            return null;
        }
        $part_pass = explode('$', $pass_compare);
        $salt = $part_pass[1];
        if (!empty($salt)) {
            if (User::genPassword($pass, $salt) === $pass_compare) {
                unset($user->password);
                return $user;
            }
        }
        return null;
    }
    /**
     * 修改密码
     */
    public function changePassword()
    {
        if (Request::isPost()) {
            $post = Request::param();
            $rule = [
                'phone|手机号' => 'require|mobile',
                'smsCode|手机验证码' => 'require|length:6|number',
                'newPassword|新密码'=>'require|length:3,20|alphaNum'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            //TODO 检查短信验证码 修改密码
            /**
             * 判断验证码有效性
             */
//            if (Session::has($post['phone'],'sms')){
                if ($detail = Session::get($post['phone'],'sms')){
                    $expire = intval(env('sms_expire')); //过期时间为 60s
                    if (time() - $detail['time'] > $expire){
                        return $this->jsonFailed('验证码超时', '2001');
                    }
                    if ($post['smsCode'] != $detail['code']){
                        return $this->jsonFailed('验证码错误', '2001');
                    }
                }
//            }else{
//                return $this->jsonFailed('code failure', '2001');
//            }
            $user = User::where('phone', $post['phone'])
                ->findOrEmpty();
            if ($user->isEmpty()) {
                return $this->jsonFailed('没有该用户', '2001');
            }
            $user->password = User::genPassword($post['newPassword']);
            $bool  = $user->save();
            if ($bool){
                return $this->jsonResult(true, null, '密码修改成功', '2000');
            }

        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 退出登录
     */
    public function logout()
    {
        if (Request::isPost()) {
            $post = Request::param();
//            self::auth();
            $rule = [

            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
//                self::ReturnAjax(2001, $res);
                return $this->jsonFailed($res, '2001');
            }
            //TODO 退出登录
//            $token = Request::header('token');
//            if (!empty($token)) {
//                $bool = Cache::rm($token);
//                if ($bool) {
////                    self::ReturnAjax(2000, '退出登录成功');
//                    return $this->jsonResult(true, null, '退出登录成功', '2000');
//                }
//            }
            //修改为新的退出登录
            $bool = Db::name('user_token')
                ->where(['uid' => $this->uid])
                ->delete();
            $this->uid = null;
            $this->user = null;
            if ($bool) {
                return $this->jsonResult(true, null, '退出成功', '2000');
            }

        } else {
//            self::ReturnAjax(2001, '请求类型错误');
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 删除用户
     */
    public function delete_user()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'type|用户类型' => 'require|integer'
            ];
            /**
             * 参数说明：
             * 1为管理员，2教师， 3 家长  4游客
             */
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $uid = $this->uid;
                /**
                 * 删除用户表数据
                 */
                User::destroy($this->uid);

                /**
                 * 删除地址表数据
                 */
                Address::destroy(function ($query) use ($uid) {
                    $query->where('uid', $uid);
                });
                /**
                 * 删除收藏文章表的数据
                 */
                Article::where('uid', $uid)
                    ->delete();
                /**
                 * 删除用户曾经的评论
                 */
                Comments::where('uid', $uid)
                    ->delete();
                /**
                 * 删除用户关注的商品
                 */
                Attention::where('uid', $uid)
                    ->delete();
                /**
                 * 删除用户在课程视频中的评论
                 */
                CourseComments::where('uid', $uid)
                    ->delete();
                if ('2' === $post['type']) {
                    //教师
                    /**
                     * 删除教师布置的作业
                     */
                    Homework::where('uid', $uid)
                        ->delete();
                    /**
                     * 删除答案评价表数据
                     */
                    Remark::where('uid', $uid)
                        ->delete();
                }
                if ('3' === $post['type']) {
                    //家长
                    /**
                     * 删除家长提交的作业答案
                     */
                    Solution::where('uid', $uid)
                        ->delete();
                }
                /**
                 * 执行登出
                 */
                Db::name('user_token')
                    ->where(['uid' => $uid])
                    ->delete();
                $this->uid = null;
                $this->user = null;
                Db::commit();
                return $this->jsonResult(true, null, '注销成功', '2000');
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
