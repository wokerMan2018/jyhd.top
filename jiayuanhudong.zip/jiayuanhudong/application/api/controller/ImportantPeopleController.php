<?php

namespace app\api\controller;

use app\admin\model\Integconfig;
use app\api\model\MembersOrder;
use app\api\model\Order;
use app\api\model\User;
use app\api\service\Pay;
use app\common\library\wechat\WxPay;
use think\Controller;
use think\Db;
use think\exception\DbException;
use think\Request;

class ImportantPeopleController extends BaseController
{
    protected $exceptAuthActions = ['membersprice'];
    protected $membersTypeToTimestamp = [
        '1' => "+ 1 month",
        '2' => "+ 3 months",
        '3' => "+ 1 year"
    ];
    /**
     * 获取会员价格
     */
    public function membersPrice()
    {
        $res = Integconfig::where('id', '>', 6)
            ->where('id', '<', 10)
            ->field('id, key, integ_num')
            ->selectOrFail();
        if ($res->isEmpty()) {
            return $this->jsonFailed('没有数据', '2001');
        }else{
            return $this->jsonResult(true, $res, '价格信息', '2000');
        }
    }
    /**
     * 获取用户是否为会员的状态
     */
    public function membersStatus()
    {
        if ($this->request->isGet()) {
            /**
             * 判断是否为会员， 会员有效期
             */
            $user = User::get($this->uid);
            if (null !== $user->expiration_time
                and now() < strtotime($user->expiration_time)) {
                $order = MembersOrder::where('uid', $user->id)
                    ->order('pay_time', 'asc')
                    ->whereNotNull('pay_time')
                    ->field('pay_time')
                    ->selectOrFail();
                $start_time = new \DateTime($order['0']['pay_time']);
                $end_time = new \DateTime(date('Y-m-d H:i:s', time()));
                $expiration_time = new \DateTime($user->expiration_time);
                $days = $start_time->diff($end_time)->days;
                $arr['alreadyTime'] = $days;
                $arr['exirationTime'] = $end_time->diff($expiration_time)->days;
                $arr['status'] = true;
            }else{
                $arr['status'] = false;
            }
            return $this->jsonResult(true, $arr, '会员状态', '2000');
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 充值成为会员
     */
    public function recharge()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'type|购买会员卡类型' => 'require|integer',
                'totalPrice|实际支付金额' => 'require',
                'reduceIntegral|消耗积分数量' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                /**
                 * 判断价格与积分是否正确
                 */
                /**
                 * 会员价格（单位积分）
                 */
                $price = Integconfig::where('id', $post['type'] + 6)
                    ->field('integ_num')
                    ->findOrEmpty();
                /**
                 * 1元等于？积分
                 */
                $equal = Integconfig::where('id', 1)
                    ->field('integ_num')
                    ->findOrEmpty();
                if (bcmul($equal['integ_num'], $post['totalPrice'], 2) + $post['reduceIntegral'] != $price['integ_num']) {
                    return $this->jsonFailed('订单价格提交错误', '2001');
                }
                /**
                 * 生成订单
                 */
                $order = self::makeOrder($this->uid, $this->user->wx_openid, intval($post['type']), $post['totalPrice'], $post['reduceIntegral']);
                if (false === $order) {
                    return $this->jsonFailed('生成订单失败', '2001');
                }else{
                    /**
                     * 纯积分支付
                     */
                    if ($post['totalPrice'] == '0') {
                        /**
                         * 扣除该订单的消耗积分， 并将积分日志写入
                         */
                        $user = User::get($this->uid);
                        if ($post['reduceIntegral'] > $this->user->integral) {
                            return $this->jsonFailed('积分不足', '2001');
                        }
                        $user->integral -= $post['reduceIntegral'];
                        /**
                         * 延长会员时间
                         */
                        if (null === $user->expiration_time) {
                            //首次充值会员
                            $user->expiration_time = date('Y-m-d H:i:s',strtotime($this->membersTypeToTimestamp[$order->members_type]));
                        } elseif (now() > strtotime($user->expiration_time)) {
                            //会员过期
                            $user->expiration_time = date('Y-m-d H:i:s',strtotime($this->membersTypeToTimestamp[$order->members_type]));
                        }else{
                            //会员没有过期，续费
                            $user->expiration_time = date('Y-m-d H:i:s',
                                strtotime($user->expiration_time . '' .  $this->membersTypeToTimestamp[$order->members_type]));
                        }
                        $res = $user->save();
                        /**
                         * 积分变更日志写入
                         */
                        $addLog = [
                            'uid' => $user->id,
                            'operation' => '充值会员',
                            'number' => -$post['reduceIntegral'],
                            'create_time' => date('Y-m-d H:i:s', time()),
                            'update_time' => date('Y-m-d H:i:s', time()),
                        ];
                        Db::name('integ_log')
                            ->insertGetId($addLog);
                        $order->order_status = 20;
                        $order->pay_time = date('Y-m-d H:i:s', time());
                        $order->save();
                        Db::commit();
                        return $this->jsonResult(true, null, '支付成功', '2000');
                    }
                    // 发起微信支付
                    $WxPay = new WxPay(config('wxconfig.wx_config.appid'));
                    $response = $WxPay->membersRechargeUnifiedorder($order->order_num, $this->user->wx_openid, $order->total_price);
                    Db::commit();
                    if ($response) {
                        $data = [
                            'payment' => $response
                        ];
                        return $this->jsonResult(true, $data, '支付信息', '2000');
                    }else{
                        return $this->jsonFailed('错误', '2001');
                    }
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 创建充值订单
     */
    protected function makeOrder($uid, $wx_openid, $type, $totalPrice, $reduceIntegral)
    {
        Db::startTrans();
        $map = [
            '1' => '月卡',
            '2' => '季卡',
            '3' => '年卡'
        ];
        try {
            $add = [
                'order_num' => Pay::orderNo(),
                'uid' => $uid,
                'total_price' => $totalPrice,
                'reduce_integer' => $reduceIntegral,
                'wx_openid' => $wx_openid,
                'order_status' => 10,
                'pay_type' => 1,
                'pay_time' => null,
                'members_type' => $type,
                'transaction_id' => null,
                'order_info' => $map[$type]
            ];
            $order = MembersOrder::create($add);
            Db::commit();
            return $order;
        } catch (DbException $e) {
            throw $e;
            Db::rollback();
            return false;
        }
    }
}
