<?php

namespace app\api\controller;

use app\admin\model\Integconfig;
use app\api\model\Checkin;
use app\api\model\IntegLog;
use think\Controller;
use think\Db;
use think\Request;
use think\exception\DbException;

/**
 * 签到相关控制器
 * Class CheckinController
 * @package app\api\controller
 */
class CheckinController extends BaseController
{
    public function check_in()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [

            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                /**
                 * 一天只能签一次到
                 */
                $check_in = Db::name('check_in')->whereTime('created_at', date('Y-m-d', time()))
                    ->where('uid',$this->uid)
                    ->find();
                if (null !== $check_in) {
                    return $this->jsonFailed('今天已签到', '2001');
                }
                /**
                 * 写入签到记录
                 */
                $add = [
                    'uid' => $this->uid,
                ];
                $result = Checkin::create($add);
                /**
                 * 增加积分数量
                 */
                $integral_add = Integconfig::where('key', 'checkin')
                    ->field('integ_num')
                    ->findOrEmpty();
                $this->user->integral += $integral_add['integ_num'];
                $this->user->save();
                /**
                 * 写入积分消耗日志
                 */
                IntegLog::create([
                    'uid' => $this->uid,
                    'operation' => '签到',
                    'number' => $integral_add['integ_num']
                ]);
                Db::commit();
                if ($result) {
                    return $this->jsonResult(true, ['string' => '签到成功，获得' . $integral_add['integ_num'] . '个积分'], '签到成功', '2000');
                }else{
                    return $this->jsonFailed('签到失败', '2001');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
