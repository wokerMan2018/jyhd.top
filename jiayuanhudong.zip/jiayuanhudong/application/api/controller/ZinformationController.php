<?php

namespace app\api\controller;

use app\admin\model\Article;
use app\admin\model\Comments;
use app\api\model\Collection;
use app\api\model\Like;
use app\api\model\ReadOrder;
use app\api\model\User;
use app\api\service\ArticleService;
use app\api\service\CollectionService;
use app\api\service\CommentService;
use app\api\service\WordFilter;
use app\common\library\wechat\WxPay;
use think\Db;
use think\exception\DbException;
use think\facade\Request;
use think\response\Json;
use helper\filter\Filter;


/**
 * 最新资讯 菜单 接口
 * Class ZinformationController
 * @package app\api\controller
 */
class ZinformationController extends BaseController
{
    protected $exceptAuthActions = ['infolist','infodetail', 'commentsbyinfoid'];
    const  PUSH_PLATE_TRAIN = 1;
    const  PUSH_PLATE_INFO = 2;
    use Filter;

    /**
     * 资讯列表  page 最新资讯
     */
    public function infoList()
    {
        if ($this->user) {
            //登录情况
            $userType = $this->user->u_type;
        }else{
            //未登录情况 按照游客处理，只能看推送人群为全部的分类 资讯
            $userType = 4;
        }
        //$userType = 2;
        $pageNum = $this->request->get('page/d');
        $pageNum = $pageNum ? $pageNum : 1;
        $Article = ArticleService::articleList($userType, self::PUSH_PLATE_INFO, $pageNum, null, $this->page_count);
//        return $this->jsonSuccess($Article, 'success');
        if ($Article) {
            return $this->jsonResult(true, $Article, 'success', '2000');
        }else{
            return $this->jsonFailed('没有数据', '2001');
        }
    }

    /**
     * 资讯详情  page 最新资讯 - 详情
     */
    public function infoDetail()
    {

        if ($this->user) {
            $userType = intval($this->user->u_type);
        }else{
            $userType = 4;
        }

        $articleId = $this->request->get('id/d');

        if (!$articleId) {
//            $this->jsonFailed('could not find articles by null Id', 4004);
            $this->jsonFailed('could not find articles by null Id', '2001');
        }

        $Article = ArticleService::articleDetail($userType, $articleId, self::PUSH_PLATE_INFO, $this->uid);
        if ($Article === null) {
            return $this->jsonFailed('没有数据', '2001');
        }
//        return $this->jsonSuccess($Article, 'success');
        return $this->jsonResult(true, $Article, 'success', '2000');
    }


    /**
     * 获取某个资讯下的所有评论  page 最新资讯 - 详情
     */
    public function commentsByInfoId()
    {
        $articleId = $this->request->get('id');
        if (!$articleId) {
//            $this->jsonFailed('could not find articles by null Id', 4004);
            $this->jsonFailed('could not find articles by null Id', '2001');
        }
        $uid = $this->uid;
        //测试用户ID $uid = 43;
        $pageNum = $this->request->get('page');
        try {
            $Comments = Comments::field('c.id,c.content,c.update_time,u.id as uid,u.username,u.photo_url,c.id as isLike,c.id as likeNumber')
                ->alias('c')
                ->where('status',2)
                ->where('aid', $articleId)
                ->whereNotNull('u.id')
                ->leftJoin('td_user u','u.id = c.uid')
                ->page($pageNum, $this->page_count)
                ->order('c.update_time', 'desc')
                ->select();
            $Comments
//                ->withAttr('content', function ($value, $data) {
//                return WordFilter::wordFilter($value);
//            })
                ->withAttr('isLike', function ($value, $data) {
                $res = Like::where('cid', $value)
                    ->where('uid', $this->uid)
                    ->findOrEmpty();
                if (!$res->isEmpty()) {
                    return true;
                }else{
                    return false;
                }
            })->withAttr('likeNumber', function ($value, $data) {
                $number = Like::where('cid', $value)
                    ->count('id');
                return $number;
            });
//            return $this->jsonSuccess($Comments, 'success');
            if (!$Comments->isEmpty()) {
                return $this->jsonResult(true, $Comments, 'success', '2000');
            }else{
                return $this->jsonFailed('暂无评论', '2004');
            }
        } catch (DbException $e) {
//            return $this->jsonFailed('server error', 5000);
            return $this->jsonFailed('server error', '2001');
        }
    }

    /**
     * 在某条资讯下添加留言  page 最新资讯 - 详情
     */
    public function addComment()
    {
        if ($this->request->isPost()) {
            $param['content'] = $this->request->post('content');
            $param['articleId'] = $this->request->post('article_id');
            $rule = [
                'articleId|资讯ID' => 'require|integer',
                'content|评论内容' => 'require|length:4,80',
            ];
            $res = $this->validate($param, $rule);
            if (true !== $res) {
//                return $this->jsonFailed($res, 2001);
                return $this->jsonFailed($res, '2001');
            }
            /**
             * 检查评论内容是否合法
             */
            if (false !== WordFilter::wordCheck($param['content'])) {
                return $this->jsonFailed('评论内容包含违规内容，请重试！', '2001');
            }

            $userType = $this->user->u_type;
            //$userType = 1;
            $Article = ArticleService::articleDetail($userType,$param['articleId'],self::PUSH_PLATE_INFO, $this->uid);
            if (!$Article){
//                return $this->jsonFailed('没有评论指定资讯的权限或资讯不存在',4003);
                return $this->jsonFailed('没有评论指定资讯的权限或资讯不存在','2001');
            }

            $data = [
                'uid' => $this->uid,
                'aid' => $param['articleId'],
                'content' => $param['content'],
                'status' => 1
            ];

            $res = Comments::create($data);
            if (false !== $res) {
//                return $this->jsonSuccess([], 'success');
                return $this->jsonResult(true, null, '添加评论成功', '2000');
            } else {
//                return $this->jsonFailed('add comment fail', 2001);
                return $this->jsonFailed('add comment fail', '2001');
            }
        } else {
//            return $this->jsonFailed('wrong submit method', 4003);
            return $this->jsonFailed('wrong submit method', '2001');
        }
    }

    /**
     * 在某条资讯 - 某条评论 下 点赞  page 最新资讯 - 详情
     */
    public function like()
    {
        if ($this->request->isPost()) {
            $param['commentId'] = $this->request->post('comment_id');
            $param['like'] = $this->request->post('like');
            $rule = [
                'commentId|评论ID' => 'require|integer',
                'like|点赞' => 'require|eq:1',
            ];
            $res = $this->validate($param, $rule);
            if (true !== $res) {
//                return $this->jsonFailed($res, 2001);
                return $this->jsonFailed($res, '2001');
            }

            $res = CommentService::like($param['commentId'], $this->uid);
            if (false === $res) {
//                return $this->jsonFailed('add comment fail', 2001);
                return $this->jsonFailed(' change like fail', '2001');
            }
//            return $this->jsonSuccess([], 'success');
            return $this->jsonResult(true, null, 'success', '2000');
        } else {
//            return $this->jsonFailed('wrong method', 4003);
            return $this->jsonFailed('wrong method', '2001');
        }
    }

    /*
     * 在某条资讯下 点击取消收藏与收藏 --page 最新资讯 - 详情
     * @return \think\response\Json
     */
    public function addCollection()
    {
        if (Request::isPost()) {
            $articleId = $this->request->post('article_id/d');
            if (!$articleId) {
//                return $this->jsonFailed('资讯ID必须', 2001);
                return $this->jsonFailed('资讯ID必须', '2001');
            }

            $Article = ArticleService::articleDetail($this->user->u_type,$articleId,self::PUSH_PLATE_INFO, $this->uid);
            if (!$Article){
//                return $this->jsonFailed('没有评论指定资讯的权限或资讯不存在',4003);
                return $this->jsonFailed('没有评论指定资讯的权限或资讯不存在','2001');
            }

            $uid = $this->uid;
//            $res = Collection::create(['uid' => $uid, 'aid' => $articleId]);
            $res = CollectionService::collect($articleId, $uid);
            if (false !== $res) {
//                return $this->jsonSuccess([], 'success');
                return $this->jsonResult(true, null, 'success', '2000');
            }
//            return $this->jsonFailed('fail', 4004);
            return $this->jsonFailed('fail', '2001');
        }
//        return $this->jsonFailed('wrong method', 4003);
        return $this->jsonFailed('wrong method', '2001');
    }


    /**
     * 判断指定文章是否被该用户收藏
     * @return Json
     */
    public function isCollect()
    {
        $articleId = $this->request->get('article_id');
        if (!$articleId) {
//            return $this->jsonFailed('资讯ID必须', 2001);
            return $this->jsonFailed('资讯ID必须', '2001');
        }

        $Article = Article::get($articleId);
        if (!$Article) {
//            return $this->jsonFailed('资讯未找到', 4004);
            return $this->jsonFailed('资讯未找到', '2001');
        }

        $uid = $this->uid;
        //测试uid
        //$uid = 43;

        $res = CollectionService::isCollect($uid, $articleId);
//        return $this->jsonSuccess(['isCollect' => $res], 'success');
        return $this->jsonResult(true, ['isCollect' => $res], 'success', '2000');

    }
    /**
     * 购买付费资讯文章 或 培训文章
     */
    public function buy()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'reduceIntegral|消耗积分数量' => 'require',
                'totalPrice|总价' => 'require',
                'article_id|付费文章id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                /**
                 * 判断文章类型是否为付费
                 */
                $article = Article::where('id', $post['article_id'])
                    ->findOrEmpty();

                if (!$article->isEmpty() and 1 !== $article->need_pay) {
                    return $this->jsonFailed('付费文章才需要购买', '2001');
                }
                $read_order = ReadOrder::makeReadOrder($this->uid, $this->user->wx_openid, $post['article_id'], $post['totalPrice'], $post['reduceIntegral']);
                if (false === $read_order) {
                    $this->jsonFailed('生成订单失败', '2001');
                }else{
                    if ($post['totalPrice'] == '0') {
                        /**
                         * 扣除该订单的消耗积分， 并将积分日志写入
                         */
                        $user = User::get($this->uid);
                        if ($post['reduceIntegral'] > $this->user->integral) {
                            return $this->jsonFailed('积分不足', '2001');
                        }
                        $user->integral -= $post['reduceIntegral'];
                        $res = $user->save();
                        /**
                         * 积分变更日志写入
                         */
                        $addLog = [
                            'uid' => $user->id,
                            'operation' => '购买商品',
                            'number' => -$post['reduceIntegral'],
                            'create_time' => date('Y-m-d H:i:s', time()),
                            'update_time' => date('Y-m-d H:i:s', time()),
                        ];
                        Db::name('integ_log')
                            ->insertGetId($addLog);
                        $read_order->order_status = 20;
                        $read_order->save();
                        Db::commit();
                        return $this->jsonResult(true, null, '支付成功', '2000');
                    }
                    // 发起微信支付
                    $WxPay = new WxPay(config('wxconfig.wx_config.appid'));
                    $response = $WxPay->readunifiedorder($read_order->order_num, $this->user->wx_openid, $read_order->total_price);
                    Db::commit();
                    if ($response) {
                        $data = [
                            'payment' => $response
                        ];
                        return $this->jsonResult(true, $data, '支付信息', '2000');
                    }else{
                        return $this->jsonFailed('错误', '2001');
                    }
                }
//                Db::commit();
            } catch (DbException $e) {
                log_error($e->getMessage());
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 查询培训和资讯文章是否付费过
     */
    public function isPaid()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'article_id|文章id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $read_order = ReadOrder::where('article_id', $post['article_id'])
                    ->where('order_status', 20)
                    ->where('uid',$this->uid)
                    ->whereNotNull('pay_time')
                    ->findOrEmpty();
                if (!$read_order->isEmpty()) {
                    $isPaid = true;
                }else{
                    $isPaid = false;
                }
                return $this->jsonResult(true, ['isPaid' => $isPaid], '文章是否付费结果', '2000');
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
