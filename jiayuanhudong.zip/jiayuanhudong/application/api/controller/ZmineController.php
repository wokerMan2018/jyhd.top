<?php

namespace app\api\controller;

use app\admin\model\Integconfig;
use app\api\model\Address;
use app\api\model\Area;
use app\api\model\Attention;
use app\api\model\CDKey;
use app\api\model\IntegLog;
use app\api\model\Notice;
use app\api\model\Order;
use app\api\model\OrderGoods;
use app\api\service\CollectionService;
use app\api\service\Pay;
use app\common\library\wechat\WxPay;
use function Complex\add;
use think\Controller;
use think\Db;
use think\Request;
use think\exception\DbException;

/**
 * 我的 菜单 接口
 * Class ZmineController
 * @package app\api\controller
 */
class ZmineController extends BaseController
{
    protected $exceptAuthActions = ['getinteg'];
    /**
     * 获取用户积分
     */
    public function getInteg()
    {
        $equal = Integconfig::where('key', 'equal')
            ->field('integ_num')
            ->findOrEmpty();
        if (empty($this->request->header('X-AUTH-TOKEN'))) {
            $response = [
                'equal' => $equal['integ_num'],
                'integral' => 0
            ];
        }else{
            $response = [
                'equal' => $equal['integ_num'],
                'integral' => $this->user->integral
            ];
        }
        return $this->jsonResult(true, $response, '我的积分数量', '2000');
    }
    /**
     * 积分明细接口  我的 - 我的积分
     */
    public function integRecord()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $res =  IntegLog::where('uid', $this->uid)
                    ->order('create_time desc')
                    ->page($post['page'], $this->page_count)
                    ->field('id,operation,number,create_time')
                    ->select();
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, '积分日志', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }

    /**
     * 我的收藏文章  我的 - 我的收藏
     */
    public function collectionRecord()
    {
        $pageNum = $this->request->get('page/d');
        $searchKey = $this->request->get('search');
        $pageNum = $pageNum ? $pageNum : 1;
        $uid = $this->uid;
        $record = CollectionService::collectionArticleList($uid, $pageNum, $searchKey);
//        return $this->jsonSuccess($record, 'success');
        return $this->jsonResult(true, $record, '我的收藏', '2000');
    }

    /**
     * 我的订单  我的 - 我的订单
     */
    public function orderRecord()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            // 订单状态 订单状态,0:取消,10:待付款, 20:已付款, 30:已发货 40:已收货(完成)
            //前端可传值为 10待付款 20为已付款待发货 30待收货 所有订单传空
            $rule = [
                'page|页码' => 'require|integer',
                'status|订单状态' => 'integer',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $map = [];
                if (!empty($post['status'])) {
                    $map['order_status'] = trim($post['status']);
                }
                $map['uid'] = $this->uid;
                $order_list = [];
                $res = Order::where($map)
                    ->alias('o')
                    ->order('o.update_time', 'desc')
                    ->hidden(['delete_time','transaction_id','wx_openid','create_time'])
//                    ->leftJoin('td_order_goods og', 'o.id = og.oid')
                    ->page($post['page'],$this->page_count)
                    ->select();
                if (!$res->isEmpty()) {
                    foreach ($res  as $key => $re) {
                        $goods_list = OrderGoods::where('oid', $re['id'])
                            ->field('gid, stock_id, skus, specs, gtype, gname, gimgs, price, number, update_time')
                            ->select();
                        $all_number = OrderGoods::where('oid', $re['id'])
                            ->sum('number');
                        $goods_list->withAttr('gimgs', function ($value, $data) {
                            if (is_array(json_decode($value, true))) {
                                foreach (json_decode($value, true) as $item) {
                                    $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                                }
                            }
                            return $path_goods;
                        });
                        $res[$key]['goods_list'] = $goods_list;
                        $res[$key]['all_number'] = $all_number;
                    }

                }else{
                    return $this->jsonFailed('没有订单', '2001');
                }

                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, '订单记录', '2000');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 取消订单
     */
    public function cancelOrder()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'oid|订单id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();//开启mysql事务
            try {
                //禁止重复取消订单
                $bool = Order::withTrashed()
                    ->where('id', $post['oid'])
                    ->where('order_status', 0)
// or                   ->where('delete_time','not null')
                        ->whereNotNull('delete_time')
                    ->findOrEmpty();
                if (!$bool->isEmpty()) {
                    return $this->jsonFailed('请勿重复取消订单', '2001');
                }
                // 修改该订单的状态为取消: 0
                $res = Order::get($post['oid']);
                $res->delete_time = date('Y-m-d H:i:s', time());
                $res->order_status = 0;
                $res = $res->save();
                if ($res) {
                    OrderGoods::destroy(function ($query) use ($post) {
                        $query->where('oid',$post['oid']);
                    });
                }
                Db::commit();
                return $this->jsonResult(true, null, '取消订单成功', '2000');
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     *用户主动付款
     */
    public function activePay()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'oid|订单id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $order = Order::get(intval($post['oid']));
                if ($order->total_price === 0) {
                    Db::startTrans();
                    try {
                        /**
                         * 扣除该订单的消耗积分， 并将积分日志写入
                         */
                        $user = \app\api\model\User::get($this->uid);
                        if ($order->reduce_integral > $this->user->integral) {
                            return $this->jsonFailed('积分不足', '2001');
                        }
                        $user->integral -= $order->reduce_integral;
                        $user->save();
                        /**
                         * 积分变更日志写入
                         */
                        $addLog = [
                            'uid' => $user->id,
                            'operation' => '购买商品',
                            'number' => -$order->reduce_integral,
                            'create_time' => date('Y-m-d H:i:s', time()),
                            'update_time' => date('Y-m-d H:i:s', time()),
                        ];
                        Db::name('integ_log')
                            ->insertGetId($addLog);
                        /**
                         * 检查订单状态是否为待支付
                         */
                        if (10 !== $order->order_status) {
                            return $this->jsonFailed('订单状态错误', '2001');
                        }
                        $order->order_status = 20;
                        $order->save();
                        Db::commit();
                        return $this->jsonResult(true, null, '支付成功', '2000');
                    } catch (DbException $e) {
                        Db::rollback();
                        return $this->jsonFailed('server error', '2001');
                    }
                }
                //发起微信支付

                /**
                 * 更新订单号，不然微信官方会报201 商户订单号重复
                 */
                $order->order_num = Pay::orderNo();
                $order->save();
                $wxPay = new WxPay(config('wxconfig.wx_config.appid'));
                $response = $wxPay->unifiedorder($order->order_num, $this->user->wx_openid, $order->total_price);
                if ($response) {
                    $data = [
                        'payment' => $response
                    ];
                    return $this->jsonResult(true, $data, '支付信息', '2000');
                }else{
                    return $this->jsonFailed('错误', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 确认收货
     */
    public function confirmReceipt()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'oid|订单id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 检查订单拥有者是否正确
                 */
                $order = Order::where('id', $post['oid'])
                    ->findOrEmpty();
                if ($order->isEmpty()) {
                    return $this->jsonFailed('订单不存在', '2001');
                }else{
                    if ($this->uid !== $order->uid) {
                        return $this->jsonFailed('订单拥有者错误', '2001');
                    }
                }
                $bool = Order::modifyOrderStatus($post['oid'], Order::ORDER_STSTUS_RECEIVED);
                if ($bool) {
                    return $this->jsonResult(true, null, '已确认收货', '2000');
                }else{
                    return $this->jsonFailed('确认收货失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 查看物流运单号
     */
    public function checkLogistics()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'oid|订单id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $order = Order::where('id', $post['oid'])
                    ->where('uid', $this->uid)
                    ->where('order_status', 'in', [Order::ORDER_STSTUS_DELIVERED, Order::ORDER_STSTUS_RECEIVED])
                    ->whereNotNull('pay_time')
                    ->field('tracking_number')
                    ->findOrEmpty();
                if ($order->isEmpty()) {
                    return $this->jsonFailed('该订单未支付或没有数据', '2001');
                }else{
                    return $this->jsonResult(true, ['tracking_number' => $order['tracking_number']], '运单号', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 获取虚拟商品的兑换码
     */
    public function getCDkey()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'gid|商品id' => 'require|integer',
                'pay_time|支付时间' => 'require|date'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $CDkey = CDKey::where('gid', $post['gid'])
                    ->where('uid', $this->uid)
                    ->where('status',2)
                    ->where('pay_time',$post['pay_time'])
                    ->field('id, cdkey')
                    ->select();
                if (!$CDkey->isEmpty()) {
                    return $this->jsonResult(true, $CDkey, '兑换码', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 我的关注商品  我的 - 关注的商品
     */
    public function attentionGoodsRecord()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer',
                'type|商品类型' => 'require|integer'
            ];
            //type为 1时全部商品
            //type为 2时实物商品
            //type为 3时虚拟商品
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //商品按类型筛选
                $type = Pay::typeMappingRelationship($post['type']);
                //商品名称搜索
                $search = $this->request->has('search','post') ? $post['search'] : '';
                $res = Attention::where('a.uid', $this->uid)
                    ->alias('a')
                    ->leftJoin('td_goods g', 'g.id = a.gid')
//                    ->leftJoin('td_stock s','g.id = s.gid')
                    //取消关联库存stock表，会导致关注一个商品时关注了所有属性商品（重复关注）
                    //价格以排序价格展示 g.price
                    ->leftJoin('td_goods_cate gc', 'gc.id = g.gc_id')
                    ->where('gc.cate_type','in', $type)
                    ->where('g.gname','like','%'. $search .'%')
                    ->order('a.create_time desc')
                    ->field('g.id,g.gimages,g.gname,g.price')
                    ->page($post['page'], $this->page_count)
                    ->select();
                $res->withAttr('gimages', function ($value, $data) {
                    if (is_array(json_decode($value, true))) {
                        foreach (json_decode($value, true) as $item) {
                            $path_goods[] = $this->request->scheme() . '://' . $this->request->host() . $item;
                        }
                    }
                    return $path_goods;
                });
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, '关注商品', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }

    /**
     * 废弃 我的购物车  我的 - 我的购物车 废弃   接口在Zmall - shoppingCarList
     */
    public function shoppingCart()
    {

    }

    /**
     * 我的地址列表  我的 - 我的地址
     */
    public function addressRecord()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $res = Address::where('uid', $this->uid)
                    ->page($post['page'], $this->page_count)
                    ->order('create_time desc')
                    ->field('id, address, address as province,address as city,address as area,zipcode,detail_address,name,phone,is_default')
                    ->select();
                $res->withAttr('province', function ($value, $data) {
                    $address = explode(',', $value);
                    if (is_array($address)) {
                        $province = Db::name('area')
                            ->field('name')
                            ->where('id', $address['0'])
                            ->find();
                        return $province['name'];
                    }
                })->withAttr('city', function ($value, $data) {
                    $address = explode(',', $value);
                    if (is_array($address)) {
                        $city = Db::name('area')
                            ->field('name')
                            ->where('id', $address['1'])
                            ->find();
                        return $city['name'];
                    }
                })->withAttr('area', function ($value, $data) {
                    $address = explode(',', $value);
                    if (is_array($address)) {
                        $area = Db::name('area')
                            ->field('name')
                            ->where('id', $address['1'])
                            ->find();
                        return $area['name'];
                    }
                });
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, '我的地址', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 地址三级联动
     */
    /**
     * 获取省
     */
    public function getProvince()
    {
        $res = Area::where('pid', 0)
            ->hidden(['pid'])
            ->select();
        if (!$res->isEmpty()) {
            return $this->jsonResult(true, $res, '', '2000');
        }
    }
    /**
     * step 1 从省获取市 测试 610000
     */
    public function getCity()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'code|地区码' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $res = Area::where('pid', trim($post['code']))
                    ->hidden(['pid'])
                    ->select();
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, $res, 'success', '2000');
                }else{
                    return $this->jsonFailed('没有下级地址', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * step 2 从市获取区 测试  610800
     */
    public function getArea()
    {
        return self::getCity();
    }
    /**
     * 新增收货地址
     */
    public function addAddress()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'codes|省市区地区码' => 'require',
                'name|收货人' => 'require',
                'phone|手机号' => 'require',
                'detail|详细地址' => 'require',
                'is_default|是否默认' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $add = [
                    'address' => trim($post['codes']),
                    'uid' => $this->uid,
                    'name' => $post['name'],
                    'phone' => $post['phone'],
                    'detail_address' => $post['detail'],
                    'is_default' => intval($post['is_default'])
                ];
                $res = Address::create($add);
                // 如果本次编辑的地址为默认地址则更新至user表中
                if (1 === $res->is_default) {
                    /**
                     * 判断该用户之前是否有默认地址，保证该用户只有一个默认地址
                     */
                    if (null !== $this->user->addr_id and $this->user->addr_id > 0) {
                        //有默认地址
                        Address::where('id', $this->user->addr_id)
                            ->update([
                                'is_default' => 0
                            ]);
                    }
                    $this->user->addr_id = $res->id;
                    $this->user->save();
                }
                Db::commit();
                if (!$res->isEmpty()) {
                    return $this->jsonResult(true, null, '添加地址成功', '2000');
                }else{
                    return $this->jsonFailed('添加失败', '2001');
                }

            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 更新地址
     */
    public function editAddress()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|地址id' => 'require',
                'codes|省市区地区码' => 'require',
                'name|收货人' => 'require',
                'phone|手机号' => 'require',
                'detail|详细地址' => 'require',
                'is_default|是否默认' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $address = Address::get(trim($post['id']));
                if (!$address) {
                    return $this->jsonFailed('没有数据', '2001');
                }
                $address->address = trim($post['codes']);
                $address->uid = $this->uid;
                $address->name = $post['name'];
                $address->phone = $post['phone'];
                $address->detail_address = $post['detail'];
                $address->is_default = intval($post['is_default']);
                $res = $address->save();
                // 如果本次编辑的地址为默认地址则更新至user表中
                if (1 === $address->is_default) {
                    /**
                     * 判断该用户之前是否有默认地址，保证该用户只有一个默认地址
                     */
                    if (null !== $this->user->addr_id and $this->user->addr_id > 0) {
                        //有默认地址
                        Address::where('id', $this->user->addr_id)
                            ->update([
                                'is_default' => 0
                            ]);
                    }
                    $this->user->addr_id = $address->id;
                    $this->user->save();
                }
                Db::commit();
                if ($res) {
                    return $this->jsonResult(true, $res, '修改地址成功', '2000');
                }else{
                    return $this->jsonFailed('修改失败', '2001');
                }

            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 删除地址
     */
    public function deleteAddress()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|地址id' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $address = Address::where('id', intval($post['id']))
                    ->findOrEmpty();
                if ($address->isEmpty()) {
                    return $this->jsonFailed('没有该地址', '2001');
                }
                if ($address->is_default === 1) {
                    $this->user->addr_id = null;
                    $this->user->save();
                }
                $res = Address::destroy(trim($post['id']));
                Db::commit();
                if ($res) {
                    return $this->jsonResult(true, null, '删除地址成功', '2000');
                }else{
                    return $this->jsonFailed('删除失败', '2001');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 设置为默认地址
     */
    public function setDefaultAddress()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|地址id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                $address = Address::where('id', intval($post['id']))
                    ->findOrEmpty();
                if ($address->isEmpty()) {
                    return $this->jsonFailed('没有该地址', '2001');
                }
                if (1 !== $address->is_default) {
                    /**
                     * 判断该用户之前是否有默认地址，保证该用户只有一个默认地址
                     */
                    if (null !== $this->user->addr_id and $this->user->addr_id > 0) {
                        //有默认地址,则取消原来的默认地址
                        Address::where('id', $this->user->addr_id)
                            ->update([
                                'is_default' => 0
                            ]);
                    }
                    $address->is_default = 1;
                    $address->save();
                    $this->user->addr_id = $address->id;
                    $this->user->save();
                    Db::commit();
                    return $this->jsonResult(true, null, '设置成功', '2000');
                }else{
                    return $this->jsonFailed('该地址已为默认地址', '2001');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 消息通知列表 我的 - 消息通知
     */
    public function messageRecord()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页面' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $notices = Notice::where('uid', $this->uid)
                    ->alias('n')
                    ->order('n.update_time DESC')
                    ->leftJoin('td_notice_type nt', 'nt.id = n.nt_id')
                    ->page($post['page'], $this->page_count)
                    ->field('n.id, nt.typename, n.message, n.update_time')
                    ->select();
                if (!$notices->isEmpty()) {
                    return $this->jsonResult(true, $notices, '消息通知', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
}
