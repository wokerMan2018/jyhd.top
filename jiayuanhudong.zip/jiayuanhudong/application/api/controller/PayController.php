<?php

namespace app\api\controller;

use app\admin\model\Goods;
use app\admin\model\Stock;
use app\api\model\CDKey;
use app\api\model\MembersOrder;
use app\api\model\Notice;
use app\api\model\Order;
use app\api\model\OrderGoods;
use app\api\model\ReadOrder;
use app\api\model\User;
use think\Controller;
use think\Db;
use think\exception\DbException;
use think\Request;

class PayController extends Controller
{
    protected $membersTypeToTimestamp = [
        '1' => "+ 1 month",
        '2' => "+ 3 months",
        '3' => "+ 1 year"
    ];
    public function membersrechargenotify()
    {
        $data = file_get_contents('php://input');
        $arr = $this->xmlToArray($data);
        $sign = $this->getSign($arr);
        if ($sign == $arr['sign']) {
            if ($arr['return_code'] == 'SUCCESS' || $arr['result_code'] == 'SUCCESS') {
                Db::startTrans();
                try {
                    $order = MembersOrder::where('order_num', $arr['out_trade_no'])
                        ->findOrEmpty();
                    if (!$order->isEmpty() and 10 === $order->order_status) {
                        $order->order_status = 20;//已支付
                        $order->pay_time = date('Y-m-d H:i:s', time());
                        $order->transaction_id = $arr['transaction_id'];
                        $bool = $order->save();
                    }
                    /**
                     * 记录积分扣除和消费日志
                     */
                    if ($bool) {
                        /**
                         * 延长会员时间
                         */
                        $user = \app\api\model\User::get($order['uid']);
                        if (null === $user->expiration_time) {
                            //首次充值会员
                            $user->expiration_time = date('Y-m-d H:i:s',strtotime($this->membersTypeToTimestamp[$order->members_type]));
                        } elseif (now() > strtotime($user->expiration_time)) {
                            //会员过期
                            $user->expiration_time = date('Y-m-d H:i:s',strtotime($this->membersTypeToTimestamp[$order->members_type]));
                        }else{
                            //会员没有过期，续费
                            $user->expiration_time = date('Y-m-d H:i:s',
                                strtotime($user->expiration_time . '' .  $this->membersTypeToTimestamp[$order->members_type]));
                        }
                        $user->save();
                        if ($order['reduce_integer'] > 0) {
                            /**
                             * 扣除该订单的消耗积分， 并将积分日志写入
                             */

                            $user->integral -= $order['reduce_integer'];
                            $res = $user->save();
                            /**
                             * 积分变更日志写入
                             */
                            $addLog = [
                                'uid' => $user->id,
                                'operation' => '充值会员',
                                'number' => -$order['reduce_integer'],
                                'create_time' => date('Y-m-d H:i:s', time()),
                                'update_time' => date('Y-m-d H:i:s', time()),
                            ];
                            Db::name('integ_log')
                                ->insertGetId($addLog);
                        }
                    }
                    Db::commit();
                } catch (DbException $e) {
                    Db::rollback();
                }
                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA]></return_msg></xml>';//给微信正常相应（如果没有正常相应微信会根据自己的机制多次请求）
            }
        }
    }
    public function notify()
    {
        $data = file_get_contents('php://input');
        $arr = $this->xmlToArray($data);
        $sign = $this->getSign($arr);
        if ($sign == $arr['sign']) {
            //判断返回状态
            if ($arr['return_code'] == 'SUCCESS' || $arr['result_code'] == 'SUCCESS') {
                /**
                 * 订单确认成功后的业务操作
                 */
                Db::startTrans();
                try {
                    /**
                     * step 1 修改该订单状态为已支付 记录订单支付时间
                     */
                    $order = Order::where('order_num', $arr['out_trade_no'])
                        ->findOrEmpty();
                    if (!$order->isEmpty() and 10 === $order->order_status) {
                        $order->order_status = 20;//已支付
                        $order->pay_time = date('Y-m-d H:i:s', time());
                        $order->transaction_id = $arr['transaction_id'];
                        $bool = $order->save();
                    }
                    /**
                     * step 2 写入购买成功的站内消息 消息类型 1 并更新更新销量
                     */
                    if ($bool) {
                        $order_goods = OrderGoods::where('oid', $order->id)
                            ->field('gid, gname, number, gtype, stock_id')
                            ->select();
                        /**
                         * step 2 -1 更新销量
                         */
//                        foreach ($order_goods as $item) {
//                            Goods::where('id', $item['gid'])
//                                ->setInc('sales_volume');
//                        }
                        /**
                         * step 2 -2 写入站内消息 消息类型1  更新销量
                         */
                        $goods_name = '';
                        $length = 0;
                        foreach ($order_goods as $goods) {
                            $goods_name .= $goods['gname'];
                            Goods::where('id', $goods['gid'])
                                ->setInc('sales_volume', $goods['number']);
                            //更新库存
                            Stock::where('id', $goods['stock_id'])
                                ->setDec('stock', $goods['number']);
                            if (2 === $goods['gtype']) {
                                ++$length;
                            }
                        }
                        /**
                         * 如果本次购买的所有商品为虚拟商品
                         * 直接订单状态改为40
                         */
                        if ($length === count($order_goods)) {
                            $order->order_status = 40;
                            $order->save();
                        }
                        $notice = Notice::create([
                            'uid' => $order->uid,
                            'nt_id' => 1,
                            'message' => '您于' . $order->pay_time . '购买' . $goods_name .'成功！',
                            'status' => 2
                        ]);
                    }
                    /**
                     * step 3 如果是虚拟商品 将cdkey与用户绑定并记录支付时间
                     */
                    if ($bool) {
                        $order_goods = OrderGoods::where('oid', $order->id)
                            ->field('gid, gtype, number')
                            ->select();
                        if (!$order_goods->isEmpty()) {
                            foreach ($order_goods as $goods) {
                                if ($goods['gtype'] == 2) {
                                    //为虚拟商品
                                    $count = CDKey::where('gid', $goods['gid'])
                                        ->where('status', 1)
                                        ->count();
                                    $cd_keys = CDKey::where('gid', $goods['gid'])
                                        ->where('status', 1)
                                        ->select();
                                    if ($count > $goods['number']) {
                                        /**
                                         * cdkey绑定用户并修改状态
                                         */
                                        for ($i = 0; $i < $goods['number']; $i++) {
                                            CDKey::where('gid', $goods['gid'])
                                                ->where('status', 1)
                                                ->limit(1)
                                                ->update([
                                                    'status' => 2,
                                                    'pay_time' => $order->pay_time,
                                                    'uid' => $order->uid
                                                ]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    /**
                     * 扣除积分， 并写入积分日志中
                     */
                    if ($bool) {
                        if ($order['reduce_integral'] > 0) {
                            /**
                             * 扣除该订单的消耗积分， 并将积分日志写入
                             */
                            $user = \app\api\model\User::get($order['uid']);
                            $user->integral -= $order['reduce_integral'];
                            $res = $user->save();
                            /**
                             * 积分变更日志写入
                             */
                            $addLog = [
                                'uid' => $user->id,
                                'operation' => '购买商品',
                                'number' => -$order['reduce_integral'],
                                'create_time' => date('Y-m-d H:i:s', time()),
                                'update_time' => date('Y-m-d H:i:s', time()),
                            ];
                            Db::name('integ_log')
                                ->insertGetId($addLog);
                        }
                    }
                    Db::commit();
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', '2001');
                }

                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA]></return_msg></xml>';//给微信正常相应（如果没有正常相应微信会根据自己的机制多次请求）

            }
        }
    }
    public function readnotify()
    {
        Db::name('json')
            ->insert(['json' => '付费支付测试1']);
        $data = file_get_contents('php://input');
        $arr = $this->xmlToArray($data);
        $sign = $this->getSign($arr);
        if ($sign == $arr['sign']) {
            Db::name('json')
                ->insert(['json' => '付费支付测试2']);
            //判断返回状态
            if ($arr['return_code'] == 'SUCCESS' || $arr['result_code'] == 'SUCCESS') {
                Db::name('json')
                    ->insert(['json' => '付费支付测试3']);
                /**
                 * 付费阅读订单确认成功后的业务操作
                 */
                Db::startTrans();
                try {
                    Db::name('json')
                        ->insert(['json' => '付费支付测试4']);
                    /**
                     * step 1 修改该订单状态为已支付 记录订单支付时间
                     */
                    $order = ReadOrder::where('order_num', $arr['out_trade_no'])
                        ->findOrEmpty();
                    if (!$order->isEmpty() and 10 === $order->order_status) {
                        $order->order_status = 20;//已支付
                        $order->pay_time = date('Y-m-d H:i:s', time());
                        $order->transaction_id = $arr['transaction_id'];
                        $bool = $order->save();
                    }
                    /**
                     * step 2
                     */
                    /**
                     * 扣除该订单的消耗积分， 并将积分日志写入
                     */
                    $user = User::get($order->uid);
                    $user->integral -= $order->reduce_integral;
                    $res = $user->save();
                    /**
                     * 积分变更日志写入
                     */
                    $addLog = [
                        'uid' => $user->id,
                        'operation' => '购买商品',
                        'number' => -$order->reduce_integral,
                        'create_time' => date('Y-m-d H:i:s', time()),
                        'update_time' => date('Y-m-d H:i:s', time()),
                    ];
                    Db::name('integ_log')
                        ->insertGetId($addLog);
                    Db::commit();
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', '2001');
                }

                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA]></return_msg></xml>';//给微信正常相应（如果没有正常相应微信会根据自己的机制多次请求）

            }
        }
    }
    function getSign($param){
        if(isset($param['sign'])){
            unset($param['sign']);
        }
        ksort($param);
        $str = urldecode(http_build_query($param));
        $str .= '&key='.config('wxconfig.wx_config.key');
        return strtoupper(md5($str));
    }

    public function xmlToArray($xml) {
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        $val = json_decode(json_encode($xmlstring), true);
        return $val;
    }
    private function makeSign($values)
    {
        //签名步骤一：按字典序排序参数
        ksort($values);
        $string = $this->toUrlParams($values);
        //签名步骤二：在string后加入KEY
//        $string = $string . '&key=' . $this->config['apikey'];
        $string = $string . '&key=' . config('wxpay.wx_config.key');
        //签名步骤三：MD5加密
        $string = md5($string);
        //签名步骤四：所有字符转为大写
        $result = strtoupper($string);
        return $result;
    }
}
