<?php

namespace app\api\controller;

use app\admin\model\CourseClassification;
use app\admin\model\Video;
use app\api\model\CourseComments;
use app\api\model\CourseLike as CourseLikeModel;
use app\api\service\CourseLike;
use app\api\service\WordFilter;
use think\Controller;
use think\Db;
use think\exception\DbException;
use think\Request;

class CourseController extends BaseController
{
    protected $exceptAuthActions = ['courseclassification', 'videolist', 'videodetail', 'commentslist'];
    /**
     * 获取课程视频分类
     */
    public function CourseClassification()
    {
        if ($this->request->isPost()) {
            $all = CourseClassification::order('cc.id', 'asc')
                ->alias('cc')
                ->join('td_video v', 'cc.id = v.cc_id')
                ->distinct(true)
                ->field('cc.id as cc_id, cc.type_name')
                ->selectOrFail();
            if (!$all->isEmpty()) {
                return $this->jsonResult(true, $all, '分类信息', '2000');
            }else{
                return $this->jsonFailed('没有分类信息', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 课程视频列表接口
     */
    public function videoList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer',
                'limit|单页数据量' => 'require|integer',
                'cc_id|分类' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $data = Video::order('create_time DESC')
                    ->alias('v')
                    ->join('td_course_classification cc', 'v.cc_id = cc.id')
                    ->where('cc.id', intval($post['cc_id']))
                    ->page($post['page'], $post['limit'])
                    ->field('v.id, v.title, v.upload_type, v.video_url, v.watch_num, v.like_num, v.comment_num, v.video_introduction, v.create_time, v.thumb, cc.type_name')
                    ->select();
                if (!$data->isEmpty()) {
                    return $this->jsonResult(true, $data, '课程分页数据', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 课程详情接口
     */
    public function videoDetail()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                Video::where('id', $post['id'])
                    ->setInc('watch_num');
                $video = Video::where('id', $post['id'])
                    ->field('id, title, upload_type, video_url, watch_num, like_num, comment_num, video_introduction, create_time, thumb')
                    ->findOrEmpty();
                if (!$video->isEmpty()) {
                    return $this->jsonResult(true, $video, '课程详情', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 给视频点赞
     */
    public function like()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $result = CourseLike::courseLike($post['id'], $this->uid);
                if (false !== $result) {
                    return $this->jsonResult(true, null, 'success', '2000');
                }else{
                    return $this->jsonFailed('失败', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('server error', '2001');
            }
        }else{
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     * 检查用户是否点赞该视频
     */
    public function isLiked()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $bool = CourseLike::isLike($post['id'], $this->uid);
                return $this->jsonResult(true, ['isLike' => $bool], '状态', '2000');
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 在视频下评论
     */
    public function addComment()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer',
                'content|评论内容' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                /**
                 * 检查评论内容是否合法
                 */
                if (false !== WordFilter::wordCheck($post['content'])) {
                    return $this->jsonFailed('评论内容包含违规内容，请重试！', '2001');
                }
                $bool = CourseLike::addComment($post['id'], $this->uid, $post['content']);
                if (false !== $bool) {
                    return $this->jsonResult(true, null, '添加评论成功', '2000');
                }else{
                    return $this->jsonFailed('添加评论失败', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 视频评论列表接口
     */
    public function commentsList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'id|视频id' => 'require|integer',
                'limit|单页数据量' => 'require|integer',
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $data = CourseComments::order('cc.create_time DESC')
                    ->alias('cc')
                    ->where('cc.status', 2)
                    ->where('cc.video_id', $post['id'])
                    ->leftJoin('td_user u', 'cc.uid = u.id')
                    ->field('u.id as uid, u.username, u.photo_url, cc.id as comment_id, cc.content, cc.create_time')
                    ->page($post['page'], $post['limit'])
                    ->select();
                if (!$data->isEmpty()) {
                    return $this->jsonResult(true, $data, '评论集分页数据', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
}
