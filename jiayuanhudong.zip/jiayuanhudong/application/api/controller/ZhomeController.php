<?php

namespace app\api\controller;

use app\admin\model\Classes;
use app\admin\model\Homework;
use app\admin\model\Integconfig;
use app\admin\model\Remark;
use app\admin\model\Solution;
use app\admin\model\User;
use app\admin\model\Zhomework_temp;
use app\api\model\Notice;
use app\api\service\Multimedia;
use helper\QinNiu;
use Qiniu\Auth;
use think\Controller;
use think\Db;
use think\Log;
use think\Request;
use think\exception\DbException;

/**
 * 家园互动 菜单  接口
 * Class ZhomeController
 * @package app\api\controller
 */
class ZhomeController extends BaseController
{
    protected $exceptAuthActions = ['callback'];
    //##############家园互动 老师接口 START#############
    /**
     * 从老师获取带的班级 (已发布作业)
     */
    public function user2ClassesLeft()
    {
        if (2 === $this->user->u_type) {
            $cids = explode(',',$this->user->cids);
            if (!$cids) {
                return $this->jsonFailed('该教师没有关联班级', '2001');
            }
            if (is_array($cids)) {
                foreach ($cids as $key => $cid) {
                    $res = Classes::where('id', $cid)
                        ->field('id,gname,id as count')
                        ->find();
                    //type为1 可以修改 表明还没有被点评
                    $count = Solution::where('s.type',1)
                        ->where('h.cid',$cid)
                        ->alias('s')
                        ->leftJoin('td_homework h', 'h.id = s.hid')
                        ->count();
                    $res->withAttr('count', function ($value, $data) use ($count) {
                        return $count;
                    });
                    $data[] = $res;
                }
                //数字为 所在班级未点评作业的数量
                if ($res) {
                    return $this->jsonResult(true, $data, '所有班级', '2000');
                }
            }
        }else{
            return $this->jsonFailed('用户类型错误', '2001');
        }

    }
    /**
     *从老师获取带的班级 (作业作业列表)
     */
    public function user2ClassesRight()
    {
        if (2 === $this->user->u_type) {
            $cids = explode(',', $this->user->cids);
            if (!$cids) {
                return $this->jsonFailed('该教师没有关联班级', '2001');
            }
            if (is_array($cids)) {
                foreach ($cids as $key => $cid) {
                    $res = Classes::where('id', $cid)
                        ->field('id,gname,id as count')
                        ->find();
                    //数字为 所在班级未发布作业的数量
                    $count = Homework::where('status', 0)
                        ->where('cid', $cid)
                        ->count();
                    $res->withAttr('count', function ($value, $data) use ($count) {
                        return $count;
                    });
                    $data[] = $res;
                }
                if ($data) {
                    return $this->jsonResult(true, $data, '所有班级', '2000');
                }
            }
        }else{
            return $this->jsonFailed('用户类型错误', '2001');
        }
    }

    /**
     * 已发布作业列表 （包含指定班级已经发布的作业）
     */
    public function PublishedList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'cid|班级id' => 'require|integer',
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查用户类型
                if (2 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                $cids_h = explode(',', $this->user->cids);
                $list = Homework::order('s.update_time desc')
                    ->where('h.cid',  $post['cid'])
                    ->field('h.id,h.sid,h.gid,h.cid,h.status,h.htid,h.uid,ht.title,ht.gname,ht.content,h.update_time as push_time,h.id as all_parents,h.id as submited,h.id as unremark, s.update_time as solutionTime')
                    ->alias('h')
                    ->where('h.status', 1)
                    ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
                    ->leftJoin('td_solution s', 'h.id = s.hid')
                    ->page($post['page'], $this->page_count)
                    ->select();
                $list->withAttr('all', function ($value, $data) use ($post) {
                    //该班级家长人数
                    $all = User::where('u_type', 3)
                        ->where('cids', $post['cid'])
                        ->count();
                    return $all;
                })->withAttr('submited', function ($value, $data) use ($post) {
                    //该班级家长已提交作业数量（包含为点评和点评的）
                    $submit = Solution::where('hid', $value)
                        ->where('cid', $post['cid'])
                        ->count();
                    return $submit;
                })->withAttr('unremark', function ($value, $data) use ($post) {
                    //该班级待点评的答案数量
                    $unremark = Solution::where('hid', $value)
                        ->where('cid', $post['cid'])
                        ->where('type', 1)
                        ->count();
                    return $unremark;
                });
                if (!$list->isEmpty()) {
                    return $this->jsonResult(true, $list, '已发布作业列表数据', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 作业列表 （包含指定班级未发布和已发布的作业）
     */
    public function homeworkList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'cid|班级id' => 'require|integer',
                'page|页面' =>'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查用户类型
                if (2 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                $cids_h = explode(',', $this->user->cids);
                $list = Homework::where('h.cid', $post['cid'] )
                    ->alias('h')
                    ->field('h.id,h.sid,h.gid,h.cid,h.status,h.htid,h.uid,ht.title,ht.gname,ht.content,h.update_time as push_time')
                    ->order('h.create_time desc')
                    ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
                    ->page($post['page'], $this->page_count)
                    ->select();
                if (!$list->isEmpty()) {
                    return $this->jsonResult(true, $list, '作业列表', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 转发操作 - 即 修改作业状态为已发布状态
     */
    public function forwarding()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require|integer',
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                //检查用户类型
                if (2 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                // 变更作业为发布状态
                $homework = Homework::get(trim($post['hid']));
                if (0 !== $homework->status) {
                    return $this->jsonFailed('已经发布过该作业，请勿重复发布');
                }
                $homework->status = 1;
                $homework->uid = $this->uid;
                $bool = $homework->save();
                if ($bool) {
                    // 发布作业后 预先在solution表新增未提交答案数据
                    $parents = User::where('u_type', 3)
                        ->where('cids', $homework->cid)
                        ->field('id')
                        ->select();
                    if (!$parents->isEmpty()) {
                        foreach ($parents as $key => $parent) {
                            $solu = Solution::create([
                                'uid' => $parent['id'],
                                'cid' => $homework->cid,
                                'hid' => $post['hid'],
                                'status' => 0,
                                'type' => 1
                            ]);
                        }
                        Db::commit();
                    }
                    // 发布作业后 增加相应积分
                    $number = Integconfig::where('key', 'publishHomework')
                        ->field('integ_num')
                        ->findOrEmpty();
                    if (!$number->isEmpty()) {
                        $this->user->integral += $number['integ_num'];
                        $this->user->save();
                        /**
                         * 积分变更日志写入
                         */
                        $add = [
                            'uid' => $this->user->id,
                            'operation' => '发布作业',
                            'number' => $number['integ_num'],
                            'create_time' => date('Y-m-d H:i:s', time()),
                            'update_time' => date('Y-m-d H:i:s', time()),
                        ];
                        Db::name('integ_log')
                            ->insertGetId($add);
                        Db::commit();
                    }
                    return $this->jsonResult(true, null, '修改该作业状态为已发布', '2000');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 作业详情
     */
    public function homeworkByHomeworkId()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $homework = Homework::where('h.id', trim($post['hid']))
                    ->alias('h')
                    ->field('h.id,h.sid,h.gid,h.cid,h.status,h.htid,h.uid,u.username,ht.title,ht.gname,ht.content,h.update_time as push_time')
                    ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
                    ->leftJoin('td_user u','u.id = h.uid')
                    ->findOrEmpty();
                if (!$homework->isEmpty()) {
                    return $this->jsonResult(true, $homework, '作业详情', '2000');
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 提交与待点评 统计
     */
    public function statistical()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'cid|班级id' => 'require|integer',
                'hid|作业id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
//                if (2 === $this->user->u_type) {
                    //该班级家长人数
                    $all = User::where('u_type', 3)
                        ->where('cids', $post['cid'])
                        ->count();
                    //该班级家长已提交作业数量（包含为点评和未点评的）
                    $submit = Solution::where('hid', $post['hid'])
                        ->where('cid', $post['cid'])
                        ->where('status', 1)
                        ->count();
                    //该班级待点评的答案数量 已提交 - 已点评
                    $remark = Solution::where('hid', $post['hid'])
                        ->where('cid', $post['cid'])
                        ->where('type', 2)//答案不能修改，为已点评
                        ->count();
                    $unremark = ($submit - $remark) < 0 ? 0 : $submit - $remark;
                    $gradeAndClassName = Classes::where('c.id', $post['cid'])
                        ->alias('c')
                        ->leftJoin('td_grade g', 'g.id = c.graid')
                        ->field('g.graname,c.gname,c.id as name')
                        ->find();
                    $gradeAndClassName->withAttr('name', function ($value, $data) use ($gradeAndClassName) {
                        return $gradeAndClassName['graname'] . $gradeAndClassName['gname'];
                    });
                    $response = [
                        'all' => $all,
                        'submited' => $submit,
                        'unremark' => $unremark,
                        'gradeAndClass' => $gradeAndClassName['name']
                    ];
                    if (is_array($response)) {
                        return $this->jsonResult(true, $response, '统计数据返回', '2000');
                    }
//                }else{
//                    return $this->jsonFailed('用户类型错误', '2001');
//                }
            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }

    /**
     *通过作业id获取所有作业提交
     */
    public function solutionsByHomewordId()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require|integer',
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $solu = Solution::where('s.hid', $post['hid'])
                    ->where('s.status', 1)
                    ->order('s.update_time desc')
                    ->whereNotNull('u.id')//没有该用户时排除记录
                    ->alias('s')
                    ->leftJoin('td_user u','u.id = s.uid')
                    ->leftJoin('td_remark r','s.id = r.sid')
                    ->field('s.id,u.id as suid, u.id as isMine, u.username,u.photo_url,s.hid,s.content as solutioncontent,s.video,s.update_time,r.id as rid,r.rate,r.uid as ruid,r.uid as rphoto_url, r.uid as rusername,r.content as remarkcontent')
                    ->page($post['page'],$this->page_count)
                    ->select();
                $solu->withAttr('rphoto_url', function ($value, $data) {
                    if ($value) {
                        $rphoto_url = User::where('id', $value)
                            ->field('photo_url')
                            ->findOrEmpty();
                        return $rphoto_url['photo_url'];
                    } else {
                        return null;
                    }
                })->withAttr('rusername', function ($value, $data) {
                    if ($value) {
                        $rusername = User::where('id', $value)
                            ->field('username')
                            ->findOrEmpty();
                        return $rusername['username'];
                    } else {
                        return null;
                    }
                })->withAttr('video', function ($value, $data) {
                    $path_goods = [];
                    if (is_array(json_decode($value, true))) {
                        foreach (json_decode($value, true) as $item) {
                            $path_goods[] = env('QINIU_URL') . '/' . $item;
                        }
                    }
                    return $path_goods;
                })->withAttr('isMine', function ($value, $data) {
                    return $value === $this->uid ? true : false;
                });
                if (!$solu->isEmpty()) {
                    return $this->jsonResult(true, $solu, '所有提交', '2000');
                }else{
                    return $this->jsonFailed('没有内容', '2001');
                }

            } catch (DbException $e) {
                throw $e;
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
        

    }
    /**
     * 给家长作业打分点评  评级 1为很棒 2为优秀 3为超赞
     */
    public function remarkOnSolutionId()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require|integer',
                'sid|作业提交id' => 'require|integer',
                'rate|等级' => 'require|integer',
                'content|评价内容' =>'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                // 检查用户类型
                if (2 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误', '2001');
                }
                $remark = Remark::where('uid', $this->uid)
                    ->where('hid', $post['hid'])
                    ->where('sid', $post['sid'])
                    ->findOrEmpty();
                if (!$remark->isEmpty()) {
                    $update = [
                        'rate' => $post['rate'],
                        'content' => $post['content']
                    ];
                    $remark = $remark->save();
                }else{
                    $add = [
                        'uid' => $this->uid,
                        'hid' => $post['hid'],
                        'sid' => $post['sid'],
                        'rate' => $post['rate'],
                        'content' => $post['content']
                    ];
                    $remark = Remark::create($add);
                }
                if ($remark) {
                    // 已评价的作业答案不能够被修改 修改该作业答案的状态
                    $solu = Solution::get($post['sid']);
                    $solu->type = 2;
                    $bool = $solu->save();
                    //点评答案后， 为教师新增相应积分
                    $number = Integconfig::where('key', 'reviewHomework')
                        ->field('integ_num')
                        ->findOrEmpty();
                    $this->user->integral += $number['integ_num'];
                    $bool = $this->user->save();
                    /**
                     * 积分变更日志写入
                     */
                    $addLog = [
                        'uid' => $this->user->id,
                        'operation' => '点评作业',
                        'number' => $number['integ_num'],
                        'create_time' => date('Y-m-d H:i:s', time()),
                        'update_time' => date('Y-m-d H:i:s', time()),
                    ];
                    Db::name('integ_log')
                        ->insertGetId($addLog);
                    // 记录作业被点评后的通知
//                 例如   张老师给的作业留言了！
                    $praent_id = Solution::where('id', $post['sid'])
                        ->field('uid')
                        ->findOrEmpty();
                    $notice = Notice::create([
                        'uid' => $praent_id['uid'],
                        'nt_id' => 3,
                        'message' => $this->user->username . '给你的作业留言了！',
                        'status' => 2
                    ]);
                    Db::commit();
                    if ($bool) {
                        return $this->jsonResult(true, null, '点评成功', '2000');
                    }
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    //#################家园互动 老师接口 END################################
    //#################家园互动 家长接口 START##############################
    /**
     * 未提交作业列表
     */
    public function uncommittedHomeworkList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                if (3 === $this->user->u_type) {
                    // 该家长用户未提交作业列表
                    $homeworkList = Solution::where('s.uid', $this->uid)
                        ->where('s.status', 0)  //答案未提交状态
                        ->where('s.cid', $this->user->cids)  //所属班级
                        ->where('ht.status',2) // 作业模板为已发布
                        ->where('h.status',1) // 作业状态为已发布
                        ->alias('s')
                        ->leftJoin('td_homework h', 'h.id = s.hid')
                        ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
                        ->order('h.update_time desc')
                        ->field('h.id, h.htid, ht.title, ht.gname,ht.content,h.update_time as push_time')
                        ->page($post['page'],$this->page_count)
                        ->select();

                    if (!$homeworkList->isEmpty()) {
                        return $this->jsonResult(true, $homeworkList, '未提交列表', '2000');
                    }else{
                        return $this->jsonFailed('没有内容', '2001');
                    }
                }else{
                    return $this->jsonFailed('用户类型错误', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 七牛云异步通知 测试
     */
    public function callback()
    {
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $auth = new Auth($accessKey, $secretKey);

        //获取回调的body信息
        $callbackBody = file_get_contents('php://input');

        //回调的contentType
        $contentType = 'application/json';
        \think\facade\Log::info('qiniu', [$callbackBody]);
        $id =  Db::name('json')
            ->insertGetId([
                'json' => $callbackBody
            ]);

        //回调的签名信息，可以验证该回调是否来自七牛
        $authorization = $_SERVER['HTTP_AUTHORIZATION'];
        $host = $this->request->host();
        $url = 'http://'.$host.'/api/Zhome/callback';

        //七牛回调的url，具体可以参考：http://developer.qiniu.com/docs/v6/api/reference/security/put-policy.html
//        $url = 'http://172.30.251.210/upload_verify_callback.php';

        $isQiniuCallback = $auth->verifyCallback($contentType, $authorization, $url, $callbackBody);

        if ($isQiniuCallback) {
            $resp = array('ret' => 'success');
        } else {
            $resp = array('ret' => 'failed');
        }

//        echo json_encode($resp);
        \think\facade\Log::info('qiniu-result', $resp);
        if ($id) {
            Db::name('json')
                ->where('id', $id)
                ->update([
                    'result' => json_encode($resp)
                ]);
        }

    }
    /**
     * 提交作业时 上传多媒体资源
     */
    public function upload()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require',
                'key|文件名称' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $tokenn = Multimedia::getUploadToken($post['hid'],$this->uid);
                $response = [
                    'token' => $tokenn,
                    'QINIU_URL' => 'https://upload-z2.qiniup.com',
                    'QINIU_SHOW_URL' => env('QINIU_URL')
                ];
                return $this->jsonResult(true, $response, '返回上传所需信息', '2000');
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 提交作业答案
     */
    public function submitSolution()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require',
                'keys|文件名称集合' => 'require',
                'content|提交文字内容' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            Db::startTrans();
            try {
                //检查用户类型
                if (3 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                //cid 为冗余字段，为了方便统计班级未点评答案数量
                $homework = Homework::get($post['hid']);
                //如果前面有提交答案时，更新答案
                $solu = Solution::where('uid', $this->uid)
                    ->where('hid', $post['hid'])
                    ->findOrEmpty();
                if (!$solu->isEmpty()) {
                    $solu->type = 1;
                    $solu->status = 1;//答案状态修改为已提交状态
                    $solu->video = $post['keys'];
                    $solu->cid = $homework->cid;
                    $solu->content = $post['content'];
                    $solu->save();
                }

                if (!$solu->isEmpty()) {
                    // 有新的作业提交后， 站内信通知该教师 留言通知 类型 4
                    // 例如： 小张 （家长） 提交了作业，请点评！
                    $teacher_id = $homework->uid;//布置该作业的教师， 即通知对象
                    $res = Notice::create([
                        'uid' => $teacher_id,
                        'nt_id' => 4,
                        'message' => $this->user->username . '提交了作业，请点评！',
                        'status' => 2
                    ]);
                    // 家长提交作业答案后， 为家长新增相应积分
                    $number = Integconfig::where('key', 'submitAnswer')
                        ->field('integ_num')
                        ->findOrEmpty();
                    $this->user->integral += $number['integ_num'];
                    $this->user->save();
                    /**
                     * 积分变更日志写入
                     */
                    $addLog = [
                        'uid' => $this->user->id,
                        'operation' => '提交作业',
                        'number' => $number['integ_num'],
                        'create_time' => date('Y-m-d H:i:s', time()),
                        'update_time' => date('Y-m-d H:i:s', time()),
                    ];
                    Db::name('integ_log')
                        ->insertGetId($addLog);
                    Db::commit();
                    return $this->jsonResult(true, null, '提交答案成功', '2000');

                }else{
                    return $this->jsonFailed('提交失败', '2001');
                }
            } catch (DbException $e) {
                Db::rollback();
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }

    }
    /**
     * 已提交作业列表
     */
    public function submittedHomeworkList()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'page|页码' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                if (3 === $this->user->u_type) {
                    try {
                        // TODO 修复
                        $homeworkList = Solution::where('s.uid', $this->uid)
                            ->where('s.status', 1)  //答案已提交状态
                            ->where('s.cid', $this->user->cids)  //所属班级
                            ->where('ht.status',2) // 作业模板为已发布
                            ->where('h.status',1) // 作业状态为已发布
                            ->alias('s')
                            ->leftJoin('td_homework h', 'h.id = s.hid')
                            ->leftJoin('td_homework_temp ht', 'ht.id = h.htid')
                            ->leftJoin('td_remark r','h.id = r.hid and s.id = r.sid')
//                            ->leftJoin('td_remark r','s.id = r.sid')
                            ->order('h.update_time desc')
                            ->field('h.id, h.htid, ht.title, ht.gname,ht.content,h.update_time as push_time, r.id as rid, r.rate, r.content as remarkContent')
                            ->page($post['page'],$this->page_count)
                            ->select();
                        if (!$homeworkList->isEmpty()) {
                            return $this->jsonResult(true, $homeworkList, '已提交列表', '2000');
                        }else{
                            return $this->jsonFailed('没有数据', '2001');
                        }
                    } catch (\Exception $e) {
                        echo $e->getMessage();
                        return $this->jsonFailed('server error', '2001');
                    }
                }else{
                    return $this->jsonFailed('用户类型错误', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * step 1 获取作业详情
     * step 2 获取所有作业提交
     */


    /**
     * 通过作业id查看点评结果
     */
    public function remarkByHomeworkId()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'hid|作业id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查用户类型
                if (3 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                $remark = Remark::alias('r')
//                    ->hidden(['r.score','r.create_time','r.update_time','s.content','s.video','s.type','s.hid','s.uid','s.id','s.create_time','s.update_time'])
                        ->field('r.id,r.rate,r.content')
                    ->where('s.uid', $this->uid)
                    ->where('s.hid', $post['hid'])
                    ->leftJoin('td_solution s', 's.id = r.sid')
                    ->findOrEmpty();
                if (!$remark->isEmpty()) {
                    return $this->jsonResult(true, $remark, '', '2000');
                }else{
                    return $this->jsonFailed('没有点评', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     *通过作业id获取家长提交的作业答案列表
     */
    public function solutionsByHomeworkId()
    {

    }
    /**
     * 家长修改作业答案时 答案展示数据
     */
    public function solutionByHomeworkId()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'sid|答案id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                if (3 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误', '2001');
                }
                $solu = Solution::where('id', $post['sid'])
                    ->hidden(['create_time','update_time'])
                    ->findOrEmpty();
                if (!$solu->isEmpty()) {
                    return $this->jsonResult(true, $solu, '答案详细信息返回', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 家长修改已提交的作业
     */
    public function editSolution()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'sid|答案id' => 'require|integer',
                'content|答案内容' => 'require',
                'keys|多媒体资源文件名称集合' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查用户类型
                if (3 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
                $solution = Solution::get($post['sid']);
                if ($solution) {
                    if (1 == $solution->type) {
                        $solution->content = $post['content'];
                        $solution->video = $post['keys'];
                        $bool = $solution->save();
                        if ($bool) {
                            return $this->jsonResult(true, null, '修改作业答案成功', '2000');
                        }
                    }else{
                        return $this->jsonFailed('该答案不能被修改', '2001');
                    }
                }else{
                    return $this->jsonFailed('没有数据', '2001');
                }

            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 家长删除已提交的作业
     */
    public function deleteSolution()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'sid|答案id' => 'require|integer'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                //检查用户类型
                if (3 !== $this->user->u_type) {
                    return $this->jsonFailed('用户类型错误','2001');
                }
//                $solu = Solution::where('id', $post['sid'])
//                    ->delete();
                /**
                 * 家长删除已提交作业时更新为作业为提交
                 */
                $solution = Solution::where('id', $post['sid'])
                    ->findOrEmpty();
                if (!$solution->isEmpty() and $solution->type === 1) {
                    $solu = Solution::where('id', $post['sid'])
                        ->update([
                            'status' => 0,
                            'type' => 1,
                            'video' => '',
                            'content' => ''
                        ]);
                }else{
                    return $this->jsonFailed('该答案不能被删除', '2001');
                }
                if ($solu > 0) {
                    return $this->jsonResult(true, null, '删除成功', '2000');
                }else{
                    return $this->jsonFailed('没有删除或没有该条记录', '2001');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    /**
     * 删除七牛云文件
     * @return \think\response\Json
     */
    public function del()
    {
        if ($this->request->isPost()) {
            $post = $this->request->param();
            $rule = [
                'fileName|文件名' => 'require'
            ];
            $res = $this->validate($post, $rule);
            if (true !== $res) {
                return $this->jsonFailed($res, '2001');
            }
            try {
                $qiniu = new QinNiu();
                $arr = [
                    $post['fileName']
                ];
                $res = $qiniu->hou_del($arr);
                if ($res) {
                    return $this->jsonResult(true, $res, '', '2000');
                }
            } catch (DbException $e) {
                return $this->jsonFailed('服务器错误', '2001');
            }
        } else {
            return $this->jsonFailed('请求类型错误', '2001');
        }
    }
    //#################家园互动 家长接口 END##############################


}
