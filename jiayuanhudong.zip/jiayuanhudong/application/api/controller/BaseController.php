<?php

namespace app\api\controller;

//use app\facade\Jwt;
use app\td\TdController;
use app\td\model\User;
use app\test\model\Auth;
use helper\UuidHelper;
use Firebase\JWT\JWT;
use phpDocumentor\Reflection\Types\This;
use think\exception\HttpException;
use think\exception\HttpResponseException;
use think\facade\Cache;
use think\model\concern\SoftDelete;

class BaseController extends TdController
{

    protected $jwt_payload = [];

    /**
     * 免登录认证的方法
     * @var array
     */
    protected $exceptAuthActions = ['test'];

    protected function initialize()
    {
        parent::initialize();
        $this->initUser();
        $this->requireLogin();
//        $this->dataCache();
//        $this->functionAuth();
    }
    /**
     * 24 小时订单未支付自动失效 废弃的方案
     */
    public function automaticAvoidance()
    {
        
    }
    /**
     * 权限表缓存
     */
    public function dataCache()
    {
        $data = Cache::get('auth');
        if (false === $data) {
            $auth_data = Auth::all();
            Cache::set('auth', $auth_data, 60 * 60 * 24 * 30);
        }
    }
    /**
     * 确定函数访问权限
     */
    public function functionAuth()
    {
        //当前访问url
        $str = $this->request->module() .DIRECTORY_SEPARATOR . $this->request->controller() . DIRECTORY_SEPARATOR . $this->request->action();
        if (true !== $this->check()) {
            $res = $this->jsonFailed('auth failed','2001');
            throw new HttpResponseException($res);
        }
    }
    /**
     * 确定是否能访问
     */
    public function check()
    {
        $str = $this->request->module() .DIRECTORY_SEPARATOR . $this->request->controller() . DIRECTORY_SEPARATOR . $this->request->action();
        $data = Cache::get('auth');
        if (false === $data ) {
            //没有缓存时
            $res = Auth::where('auth_type', $this->user->auth_type)
                ->where('module',$this->request->module())
                ->where('controller',$this->request->controller())
                ->where('action',$this->request->action())
                ->findOrEmpty();
            if (!$res->isEmpty()) {
                if (1 === $res['auth']) {
                    return true;
                }
            }else{
                //表中没有记录，可以访问
                return true;
            }
        }else{
            $status = false;
            $array = null;
            foreach ($data as $key => $value) {
                if (strtolower($value['module']) == $this->request->module() and
                    strtolower($value['controller']) == $this->request->controller() and
                    strtolower($value['action']) == $this->request->action()) {
                    $status = true;
                    $array = $value;
                }
            }
            if (false === $status) {
                //访问路由没有加入td_auth表中， 可以访问
                return true;
            }
            if (true === $status) {
                if ($array['auth_type'] == $this->user->auth_type and $array['auth'] === 1) {
                    return true;
                }
            }
        }
    }

    /**
     * api验证登录
     */
    protected function requireLogin()
    {
        if ($this->exceptAuthActions == ['*']) {
            return;
        }
        if (in_array($this->request->action(), $this->exceptAuthActions)) {
            return;
        }

        if (empty($this->uid)) {
            $res = [
                'success' => false,
                'data' => null,
                'message' => '需要登录',
                'error_code' => 'REQUIRE_LOGIN'
            ];
            header('Content-Type:application/json; charset=utf-8');
            echo json_encode($res);
            die();
        }
    }

    protected function initUser()
    {
        if (!empty($this->request->param('jwt_payload'))) {
            $uid = $this->request->jwt_payload['uid'];
            $this->user = User::get($uid);
            $this->uid = $uid;
            $this->auth_type = $this->user->auth_type;
        } else {
            $this->uid = 0;
            $this->user = null;
        }
    }

    /**
     *
     * api 处理用户登录信息
     * @param $user \app\td\model\User
     */
    protected function handlerUserLogin($user)
    {

        /**
         *  sub: 该JWT所面向的用户
         * iss: 该JWT的签发者
         * iat(issued at): 在什么时候签发的token
         * exp(expires): token什么时候过期
         * jti：JWT ID为web token提供唯一标识
         */

        $exp = $this->request->time() + 3600 * 24 * 30;


        // $token = db()->query('select uuid() as token;')[0]['token'];
        $token = UuidHelper::generate()->string;
        $jwt = [
            "jti" => $token,
            "iss" => "domain",
            "iat" => $this->request->time(),
            "exp" => $exp,
            "uid" => $user->id,
        ];


        db('user_token')->insert([
            'uid' => $user->id,
            'token' => $token,
            'create_time' => date('Y-m-d H:i:s', time()),
            'expire_time' => date('Y-m-d H:i:s', $exp),
        ]);

        $this->request->jwt_payload = $jwt;
        $user->last_login_time = now();
        $user->save();
        /**
         * 返回token
         */
        $token = JWT::encode($jwt, env('JWT_KEY'));
        return $token;
    }

    /**
     *鉴权
     */
    protected function auth()
    {
        try {
            $this->user = Jwt::auth();
        } catch (\Exception $e) {
            self::ReturnAjax(2001, '请先登录');
        }
    }

}