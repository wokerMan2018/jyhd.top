<?php

namespace app\api\controller;

use think\Controller;
use think\Request;

/**订单相关
 * Class OrderController
 * @package app\api\controller
 */
class OrderController extends Controller
{
    public function index()
    {
        
    }


}
