<?php

namespace app\api\controller;

use app\api\model\Balance;
use app\api\model\UserLevel;
use app\td\model\User;
use Firebase\JWT\JWT;
use think\Facade\Cache;
use think\Validate;
use think\Db;
use helper\Sendjuhe;

class AuthController extends BaseController {

    protected $exceptAuthActions = ['login', 'register', 'send_sms'];
    //protected $exceptAuthActions = ['*'];

    const USER_HIDDEN_FIELDS = ['password', 'withdraw_pwd', 'wx_openid', 'delete_time'];

    public function login() {
        if(empty($this->user) || empty($this->uid)) {
            $username = $this->request->param('tel');
            $pwd = $this->request->param('password');
            $user = User::checkPassword($username, $pwd);
            if (empty($user)) {
                return $this->jsonFailed('手机号或密码不正确');
            } elseif (!$user->enable) {
                return $this->jsonFailed('用户已禁用');
            }

            $auth_token = $this->handlerUserLogin($user);
        }
        else {
            $user = $this->user;
            $auth_token = JWT::encode($this->request->jwt_payload, env('JWT_KEY'));
        }
        $user_data = $user->hidden(self::USER_HIDDEN_FIELDS)->toArray();
        return $this->jsonSuccess([
            'user' => $user_data,
            'x_auth_token' => $auth_token
        ]);

    }

    //注册
    public function register(){
        $user_data = [
            'username' => input('tel'),
            'nickname' => input('nickname'),
            'password' => input('password'),
            'withdraw_pwd' => input('withdraw_pwd'),
            'tel' => input('tel'),
            'tel_country_code' => input('tel_country_code', '86'),
        ];

        //短信验证码 TODO
        $sms_code = input('sms_code');

        $send_code = cache(input('tel') . 'sms_code');

        if(!env('DEVELOP_MODE') && (empty($sms_code) || $sms_code != $send_code)) {
            return $this->jsonFailed('短信验证码错误');
        }

        if(env('IP_LIMIT')) {
            if(!$ip_limit_cache_key) {
                return $this->jsonFailed('注册ip限制，请5分钟后再试');
            }
        }

        $validate = new \app\api\validate\Register();
        if(!$validate->check($user_data)) {
            return $this->jsonFailed($validate->getError());
        }
        if(User::isUserExists($user_data['username'])) {
            return $this->jsonFailed('手机号已被注册');
        }
        if(User::isNicknameExists($user_data['nickname'])) {
            return $this->jsonFailed('昵称已存在');
        }

        $user = $this->addUser($user_data);
        if(empty($user)) {
            return $this->jsonFailed('注册失败');
        }

        // 注册成功后自动登陆
        $auth_token = $this->handlerUserLogin($user);
        $user_data = $user->append(['profile' => ['balance']])->hidden(self::USER_HIDDEN_FIELDS)->toArray();

        return $this->jsonSuccess([
            'user' => $user_data,
            'x_auth_token' => $auth_token
        ]);
    }

    public function send_sms() {
        return $this->jsonSuccess(null, '发送成功');
    }


    private function addUser($data) {
        try {
            $data['password'] = User::genPassword($data['password']);
            $data['withdraw_pwd'] = User::genPassword($data['withdraw_pwd']);
            Db::startTrans();

            $user = User::create($data);
            $last_user = User::where('id', '<>', $user['id'])->where('is_staff','<>',1)->order('id desc')->find();
            $user->save();
            Db::name('user_profile')->insert(['uid' => $user['id']]);
//            db('user_profile', [], false)->insert(['uid' => $user['id']]);
            DB::commit();
        }
        catch (\Exception $e) {
            Db::rollback();
            log_error($e);
            return null;
        }

        return User::get($user['id']);
    }

    //密码找回
    public function lost_pwd($tel,$code,$password){
        $this->rateLimit(5, 300);

        $send_code = cache($tel . 'sms_code');
        if(empty($code) || empty($send_code) || $code != $send_code) {
            return $this->jsonFailed('验证码错误');
        }
        $result = db('user')->where('username',$tel)->find();
        if(!$result){
            return $this->jsonFailed('账号错误');
        }
        $result = User::changePassword($tel, $password);
        $message = $result ? '修改成功' : '修改失败';
        return $this->jsonResult($result, null, $message);
    }

    //短信验证
    public function send($tel){

        return $this->jsonSuccess(null,'发送成功');
    }

    public function test() {

    }
    public function test1() {
        //$this->rateLimit(20, 1);

        $this->rateLimit(5, 2);
    }
}