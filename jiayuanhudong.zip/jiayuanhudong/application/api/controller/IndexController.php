<?php
/**
 * Created by cheng. Time: 2018-05-21 11:53:55
 */

namespace app\api\controller;
use app\td\model\Music;
use app\td\model\User;
//use helper\TbkClientHelper;
use think\Db;
use think\facade\Cache;
use think\facade\Log;
use think\Request;
use Think\Model;
//use Exception;
use app\td\model\Video;
use think\Validate;


class IndexController extends BaseController {

    public function index() {
        return $this->jsonSuccess();
    }

}