<?php


namespace app\api\service;


use app\admin\model\Article;
use app\api\model\Collection;
use Exception;
use PDOStatement;
use think\exception\DbException;

class CollectionService
{
    /**
     * 收藏与取消收藏
     */
    public static function collect($articleId, $uid)
    {
        $map = [
            'aid' => $articleId,
            'uid' => $uid
        ];
        $res = Collection::get($map);
        if ($res) {
            $result = Collection::destroy($map);
            return $result;
        }else{
            $result = Collection::create($map);
            return $result;
        }
    }
    /**
     * @param int $uid 用户ID
     * @param int $aid 资讯ID
     * @return bool
     */
    public static function isCollect($uid, $aid)
    {
        try {
            $res = Collection::where(['uid' => $uid, 'aid' => $aid])->findOrEmpty();
            return $res->isEmpty() ? false : true;
        } catch (DbException $e) {
            return false;
        }
    }

    /**
     * 获取指定用户收藏ID列表
     * @param int $uid
     * @return array
     */
    public static function collectionsByUid($uid)
    {
        return Collection::where('uid', $uid)->column('aid');
    }

    /**
     * 获取指定用户收藏的文章基本信息列表
     * @param int $uid
     * @param int $pageNum 页码
     * @param int $pageCount 每页总条数
     * @param int $status
     * @return array|PDOStatement|string|\think\Collection|null
     */
    public static function collectionArticleList($uid,$pageNum, $searchKey,$pageCount = 20,$status = 2)
    {
        $ids = self::collectionsByUid($uid);
        if (!$ids) {
            return null;
        }
        try {
            $Articles = Article::where('a.id', 'in', $ids)
                ->alias('a')
                ->where('a.atitle', 'like', '%' . $searchKey . '%')
                ->field('a.id,a.atitle,a.acontent,a.push_time, at.push_plate, a.thumb')
                ->order('a.push_time', 'desc')
                ->leftJoin('td_article_type at', 'a.atypeid =  at.id')
                ->page($pageNum,$pageCount)
                ->where('a.status', $status)
                ->select();
            return $Articles;
        } catch (Exception $e) {
            throw $e;
            return null;
        }
    }
}