<?php


namespace app\api\service;


use app\admin\model\Comments;
use app\api\model\Like;

class CommentService
{
    /**
     * @param int $commentId
     * @param int $uid
     * @return Like|bool
     */
    public static function like($commentId, $uid)
    {
        //验证commentId是否存在
//        $Comment = Comments::get($commentId);
        $Comment = Comments::get(function ($query) use ($commentId) {
            $query->where(['id' => $commentId, 'status' => 2]);
        });
        if (!$Comment) {
            return false;
        }
        //测试uid
        //$uid = 43;
        if ($uid <= 0) {
            return false;
        }
        $map = ['uid' => $uid, 'cid' => $commentId];

        //验证多次点赞
        $Like = Like::get($map);
        if ($Like) {
//            return false;
            //修改第二次点击为取消点赞
            $res = Like::destroy($map);
            return $res;
        } else {
            $res = Like::create($map);
            return $res;
        }
    }

}