<?php


namespace app\api\service;


use app\admin\model\Article;
use app\admin\model\Comments;
use app\api\model\ReadOrder;
use Exception;
use PDOStatement;
use think\Collection;
use think\exception\DbException;
use think\Model;

class ArticleService
{
    /**
     * 获取指定文章详情
     * @param int $userType 用户类型
     * @param int $articleId 文章ID
     * @param int $pushPlate 推送平台
     * @param int $status 状态
     * @return array|PDOStatement|string|Model|null
     */
    public static function articleDetail($userType, $articleId, $pushPlate, $uid,  $status = 2)
    {
        try {
            $res = Article::where('id', $articleId)
                ->setInc('pv');
            $Article = Article::where('a.status', $status)
                ->field('a.id,a.uid,a.atitle,a.acontent,a.push_time,a.pv,a.need_pay,a.price,a.paycontent,a.id as numberOfComments, a.video,a.video_upload_type, a.thumb')
                ->alias('a')
                ->leftJoin('article_type at', 'a.atypeid=at.id')
                ->where('a.id', $articleId)
                ->where('at.push_plate', $pushPlate)
                ->where('at.push_person', 'in', [3, $userType -1])
                ->find();
            $Article->withAttr('numberOfComments', function ($value, $data) {
                $number = Comments::where('c.aid', $value)
                    ->alias('c')
                    ->leftJoin('td_user u', 'u.id = c.uid')
                    ->whereNotNull('u.id')
                    ->where('c.status', 2)
                    ->count('c.id');
                return $number;
            });
            //todo 是否付费检测
//            $PayResult = false;
            $PayResult = ReadOrder::where('article_id', $articleId)
                ->where('order_status', 20)
                ->where('uid',$uid)
                ->findOrEmpty();
            if ($PayResult->isEmpty()) {
                $Article->hidden(['paycontent']);
            }
            return $Article;
        } catch (DbException $e) {
            return null;
        }
    }

    /**
     * @param int $userType 用户类型
     * @param int $pushPlate 推广平台
     * @param int $pageNum 页码
     * @param int $pageCount 每页总条目
     * @param int $status 状态
     * @return array|PDOStatement|string|Collection|null
     */
    public static function articleList($userType, $pushPlate, $pageNum, $classification = null, $pageCount = 8, $status = 2)
    {
        try {
            $Article = Article::field('a.id,a.uid,a.atitle,a.acontent,a.pv,a.push_time,a.need_pay,a.price, a.video,a.video_upload_type, a.thumb')
                ->alias('a')
                ->leftJoin('article_type at', 'a.atypeid=at.id')
                ->where('a.status', $status)
                ->where('at.push_plate', $pushPlate)
                ->where('at.push_person', 'in', [3, $userType -1])
                ->page($pageNum, $pageCount)
                ->leftJoin('td_training_classification tc', 'a.tc_id = tc.id')
                ->where('tc.id', $classification)
                ->order('push_time', 'desc')
                ->select();
            return $Article;
        } catch (Exception $e) {
            return null;
        }
    }
}