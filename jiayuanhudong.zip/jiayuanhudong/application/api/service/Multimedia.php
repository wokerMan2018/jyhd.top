<?php


namespace app\api\service;
use helper\QinNiu;
use Qiniu\Auth;


class Multimedia
{
    /**
     * 对象存储 请求上传文件
     */
    public static function getUploadToken($hid,$uid)
    {
        $qiuniu = new QinNiu();
//        $token =$qiuniu->getCallbackUploadToken($hid,$uid);
        $token = $qiuniu->get_upload_token();
        return $token;
    }

    public static function delFile($fileNmae)
    {
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
//        $key = 'tmp_10d6fb48b2a208e242e754efb119335520663ade3b758ba6.mp4';
        $key = $fileNmae;
        $days = 10;
        $auth = new Auth($accessKey, $secretKey);
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($auth, $config);
        $err = $bucketManager->delete($bucket, $key);
        return $err;
    }
}