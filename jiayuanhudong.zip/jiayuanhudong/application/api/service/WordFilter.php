<?php


namespace app\api\service;


use DfaFilter\SensitiveHelper;
use helper\filter\Filter;

/**
 * Class WordFilter
 * @package app\api\service
 */
class WordFilter
{
    use Filter;
    protected static $path = './../vendor/lustre/php-dfa-sensitive/tests/data/words.txt';
    /**
     * 敏感词过滤
     */
    public static function wordFilter($content)
    {
//        $path = './../vendor/lustre/php-dfa-sensitive/tests/data/words.txt';
        $wordFilePath = self::$path;
        // get one helper
        $handle = SensitiveHelper::init()->setTreeByFile($wordFilePath);
        // 敏感词替换为*为例（会替换为相同字符长度的*）
        $filterContent = $handle->replace($content, '*', true);
        //标记敏感词
//        $markedContent = $handle->mark($content, '<mark>', '</mark>');
        return $filterContent;
    }

    /**
     * 检查内容是否合法
     * @param $content
     * @return bool
     * @throws \DfaFilter\Exceptions\PdsBusinessException
     * @throws \DfaFilter\Exceptions\PdsSystemException
     */
    public static function wordCheck($content)
    {
        $handle = SensitiveHelper::init()->setTreeByFile(self::$path);
        $bool = $handle->islegal($content);
        return $bool;
    }

}