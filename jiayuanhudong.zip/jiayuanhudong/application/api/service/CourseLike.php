<?php


namespace app\api\service;


use app\admin\model\Video;
use app\api\model\CourseComments;
use app\api\model\CourseLike as CourseLikeModel;
use think\Db;
use think\exception\DbException;

class CourseLike
{
    /**
     * 视频课程点赞与取消点赞
     */
    public static function courseLike($video_id, $uid)
    {
        Db::startTrans();
        try {
            /**
             * 检查是否有该视频
             */
            $video = Video::where('id', $video_id)
                ->findOrEmpty();
            if ($video->isEmpty()) {
                return false;
            }
            /**
             * 检查用户id
             */
            if ($uid <= 0) {
                return false;
            }
            $map = [
                'video_id' => $video->id,
                'uid' => $uid
            ];
            /**
             * 检查是否多次点赞
             */
            $like = CourseLikeModel::get($map);
            if ($like) {
                $res = CourseLikeModel::destroy($map);
                $video->like_num -= 1;
                $video->save();
            } else {
                try {
                    $res = CourseLikeModel::create([
                        'video_id' => $video->id,
                        'uid' => $uid
                    ]);
                    /**
                     * 增加视频点赞数
                     */
                    $video->like_num += 1;
                    $video->save();
                } catch (DbException $e) {
                    throw $e;
                }
            }
            Db::commit();
            return $res;
        } catch (DbException $e) {
            Db::rollback();
            return false;
        }
    }

    /**
     * 是否点赞视频
     * @param $video_id
     * @param $uid
     */
    public static function isLike($video_id, $uid)
    {
        /**
         * 检查是否有该视频
         */
        $video = Video::get($video_id);
        if (null === $video) {
            return false;
        }
        try {
            $video_like = CourseLikeModel::where('video_id', $video->id)
                ->where('uid', $uid)
                ->findOrEmpty();
            return $video_like->isEmpty() ? false : true;
        } catch (DbException $e) {
            return false;
        }
    }

    /**
     * 添加评论
     */
    public static function addComment($video_id, $uid, $content)
    {
        Db::startTrans();
        try {
            /**
             * 检查视频是否存在
             */
            $video = Video::where('id', $video_id)
                ->findOrEmpty();
            if ($video->isEmpty()) {
                return false;
            }
            $add = [
                'video_id' => $video->id,
                'uid' => $uid,
                'content' => $content,
                'status' => 1
            ];
            $course_comment = CourseComments::create($add);
            $video->comment_num += 1;
            $video->save();
            Db::commit();
            return $course_comment->isEmpty() ? false : true;
        } catch (DbException $e) {
            Db::rollback();
            return false;
        }
    }
}