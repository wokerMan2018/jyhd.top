<?php


namespace app\api\service;


use app\admin\model\Attention;
use app\admin\model\Goods;
use app\admin\model\Stock;
use app\api\model\Order;
use app\api\model\OrderGoods;
use phpDocumentor\Reflection\Types\Integer;
use think\Db;
use think\exception\DbException;

class Pay
{
    /**
     * 商品列表 映射关系
     */
    public static function typeMappingRelationship($type = null)
    {
        if (!is_null($type)) {
            switch ($type) {
                case 1:
                    return [1,2];
                    break;
                case 2:
                    return 1;
                    break;
                case 3:
                    return 2;
                    break;
                    default:
                        break;
            }
        }
    }

    public static function sortingMappingRelationship($sorting = null)
    {
        if (!is_null($sorting)) {
            switch ($sorting) {
                case 1:
                    return 'g.price';
                    break;
                case 2:
                    return 'g.sales_volume';
                    break;
                case 3:
                    return 'g.update_time';
                    break;
                default:
                    break;
            }
        }
    }
    /**
     * 关注与取消关注
     */
    public static function Attention($goodsId,$uid)
    {
        $map = [
            'gid' => $goodsId,
            'uid' => $uid
        ];
        $res = Attention::get($map);
        if ($res) {
            //之前关注过该商品 则取消关注
            $result = Attention::destroy($map);
            return $result;
        }else{
            $result = Attention::create($map);
            return $result;
        }
    }
    /**
     * 判断用户是否关注指定商品
     */
    public static function isAttention($gid, $uid)
    {
        $res = Attention::where('gid', $gid)
            ->where('uid', $uid)
            ->findOrEmpty();
        return $res->isEmpty() ? false : true;
    }
    /**
     * 准备商品结算信息 废弃
     * @param integer $uid 用户id
     * @param integer $gid 商品id
     * @param integer $stockId 库存表id
     */
    public static function buyNow($uid, $gid, $goods_num, $stockId)
    {
        // 检查库存
        $stock = Stock::where('s.id', $stockId)
            ->alias('s')
            ->leftJoin('td_goods g', 'g.id = s.gid')
            ->leftJoin('td_goods_cate gc','gc.id = g.gc_id')
            ->where('gc.status',1)
            ->where('g.id', $gid)
            ->where('g.status',1)
            ->field('stock')
            ->findOrEmpty();
        if (!$stock->isEmpty()) {
            //查询出库存
            if ($goods_num > $stock['stock']) {
                // 库存不足
            }
        }else{
            //没有查询出库存
            return null;
        }


    }

    /**
     * 生成订单号
     */
    public static function orderNo()
    {
        return date('Ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

    /**支付异步通知
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function notify()
    {
        $data = file_get_contents('php://input');
        $arr = $this->xmlToArray($data);
        $sign = $this->getSign($arr);
        if ($sign == $arr['sign']) {
            //判断返回状态
            if ($arr['return_code'] == 'SUCCESS' || $arr['result_code'] == 'SUCCESS') {
                $order_status = Db::name('order')->where(['order_num'=>$arr['out_trade_no']])->field('order_status')->find()['order_status'];
                if ($order_status == 0){
                    Db::name('order')->where(['order_num'=>$arr['out_trade_no']])->update([
                        'order_status'=>20,
                        'transaction_id'=>$arr['transaction_id'],
                        'pay_time'=>date('Y-m-d H:i:s',time()),
                        'update_time'=>date('Y-m-d H:i:s',time())
                    ]);
                    $effective_time = Db::name('website')->where(['id'=>1])->field('effective_time')->find()['effective_time'];
                    $time = date('Y-m-d H:i:s', strtotime("+".$effective_time." year"));
                    Db::name('user')->where(['wx_openid'=>$arr['openid']])->update([
                        'isvip'=>1,
                        'expiry_time'=>$time,
                    ]);
                }

                echo '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA]></return_msg></xml>';//给微信正常相应（如果没有正常相应微信会根据自己的机制多次请求）

            }
        }
    }

    /**
     * 获取签名
     * @param $param
     * @return string
     */
    function getSign($param){
        if(isset($param['sign'])){
            unset($param['sign']);
        }
        ksort($param);
        $str = urldecode(http_build_query($param));
        $str .= '&key='.config('wxpay.wx_config.key');
        return strtoupper(md5($str));
    }
    /**
     * 生成签名
     * @param $values
     * @return string
     */
    private function makeSign($values)
    {
        //签名步骤一：按字典序排序参数
        ksort($values);
        $string = $this->toUrlParams($values);
        //签名步骤二：在string后加入KEY
//        $string = $string . '&key=' . $this->config['apikey'];
        $string = $string . '&key=' . config('wxpay.wx_config.key');
        //签名步骤三：MD5加密
        $string = md5($string);
        //签名步骤四：所有字符转为大写
        $result = strtoupper($string);
        return $result;
    }
    /**
     * xml 转 数组
     * @param $xml
     * @return mixed
     */
    public function xmlToArray($xml) {
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        $val = json_decode(json_encode($xmlstring), true);
        return $val;
    }



}