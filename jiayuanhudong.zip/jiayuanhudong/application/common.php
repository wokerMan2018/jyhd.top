<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
use think\facade\Request;

/**
 * base64编码和解码
 * @param $input
 * @return string
 */
function base64_url_encode($input) {
    return strtr(base64_encode($input), '+/=', '._-');
}

function base64_url_decode($input) {
    return base64_decode(strtr($input, '._-', '+/='));
}

/**
 * 生成随机字符串
 * @param int $length 长度
 * @param string $char 字符列表
 * @return string
 */
function random_str($length = 4, $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
{
    if (!is_int($length) || $length < 0) {
        return '';
    }

    $string = '';
    for ($i = $length; $i > 0; $i--) {
        $string .= $char[mt_rand(0, strlen($char) - 1)];
    }

    return $string;
}


/**
 * 记录错误日志
 * @param $message string|Exception  信息
 * @param string $error_code 错误代码
 * @return string 返回错误代码
 */
function log_error($message, $error_code='') {
    if(empty($error_code)) {
        $error_code = uniqid('E-');
    }
    trace("#{$error_code}#\n$message", 'error');
    return $error_code;
}

/**
 * 获取请求的域名，包含http/https
 */
function get_base_url() {
    if (isset($_SERVER['HTTPS']) &&
        ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
        isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
        $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
        $protocol = 'https://';
    }
    else {
        $protocol = 'http://';
    }
    $result = $protocol . $_SERVER['SERVER_NAME'];
    $port = $_SERVER["SERVER_PORT"];
    if($port != '80') {
        $result .= ':'.$_SERVER["SERVER_PORT"];
    }
    return $result;
}

/**
 * 获取ipv4地址
 * @param bool $get_int
 * @return int|string
 */
function get_client_ip($get_int=false) {
    $ip_address = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ip_address = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ip_address = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ip_address = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ip_address = $_SERVER['REMOTE_ADDR'];
    return $get_int ? (int)ip2long($ip_address) : $ip_address;
}

/**
 * 拼接url和文件路径
 * @return string
 */
function join_paths()
{
    $args = func_get_args();
    $cnt = count($args);
    if (!$cnt) {
        return '';
    }
    $paths = [];
    $start_with_slash = '';
    for ($i = 0; $i < $cnt; $i++) {
        if ($i == 0) {
            if (!empty($args[$i]) && substr($args[$i], 0, 1) == '/') {
                $start_with_slash = '/';
            }

        }
        $paths[] = trim($args[$i], '/');
    }

    $paths = array_filter($paths);
    return $start_with_slash . join('/', $paths);
}


/**
 * 换行符替换
 * @param $text
 * @return string
 */
function br2nl($text) {
    return preg_replace('/<br\\s*?\/??>/i', "\n", $text);
}

function now() {
    return date('Y-m-d H:i:s');
}

/**
 *  计算两个日期相隔时间：年、月、日、时、分、秒 总计天数
 * @author TekinTian <tekintian#gmail.com>
 * @param string $start_time 开始时间 必须 [格式如：2011-11-5 10:01:01]
 * @param string $end_time 结束时间 选填，不提供默认未当前时间 [格式如：2012-12-01 10:01:01]
 * @return array Array ( [y] => 年 [m] => 月 [d] => 日 [h] => 时 [i] => 分 [s] => 秒 [a] => 合计天数 )
 */
function get_date_diff($start_time,$end_time=''){
    $end_time = ($end_time=='')?date("Y-m-d H:i:s"):$end_time;
    $datetime1 = new \DateTime($start_time);
    $datetime2 = new \DateTime($end_time);
    $interval = $datetime1->diff($datetime2);
    $time['y'] = $interval->format('%y');
    $time['m'] = $interval->format('%m');
    $time['d'] = $interval->format('%d');
    $time['h'] = $interval->format('%H');
    $time['i'] = $interval->format('%i');
    $time['s'] = $interval->format('%s');
    $time['a'] = $interval->format('%a');    // 两个时间相差总天数
    return $time;
}
/**
 * 计算过去某个时间戳到现在的时间形式
 * @param  int $time $[name] [<description>]
 * @return  string [<description>]
 */
function mdate($time = NULL) {
    $text = '';
    $time = $time === NULL || $time > time() ? time() : intval($time);
    $t = time() - $time; //时间差 （秒）
    $y = date('Y', time()) - date('Y', $time);//是否跨年
    switch($t){
     case $t == 0:
       $text = '刚刚';
       break;
     case $t < 60:
      $text = $t . '秒前'; // 一分钟内
      break;
     case $t < (60 * 60):
      $text = floor($t / 60) . '分钟前'; //一小时内
      break;
     case $t < (60 * 60 * 24):
      $text = floor($t / (60 * 60)) . '小时前'; // 一天内
      break;
     case $t < (60 * 60 * 24 * 3):
      $text = floor($t/(60*60*24)) == 1 ? '昨天 ' : '前天 '; //昨天和前天
      $text = $text." ".date("H:i",$time);
      break;
     case $t < (60 * 60 * 24 * 30):
      $text = date('j', $t) . '天前'; //多少天以前
      break;
     case $t < (60 * 60 * 24 * 365) && $y == 0:
      $text = date('n', $t) . '月前'; //几个月以前
      break;
     case $t > (60 * 60 * 24 * 365) && $y > 0:
      $text = $y . '年前'; //一年以前
      break;
    }
    return $text;
}

/**
 * 删除目录及目录下的文件
 * @param $dir_path
 */
function deleteDir($dir_path) {
    if (substr($dir_path, strlen($dir_path) - 1, 1) != '/') {
        $dir_path .= '/';
    }
    $files = glob($dir_path . '*', GLOB_MARK);
    foreach ($files as $k => $file) {
        is_dir($file) ? deleteDir($file) : unlink($file);
    }
    if(is_dir($dir_path)) {
        rmdir($dir_path);
    }
}
/**
 * curl请求指定url
 * @param $url
 * @param array $data
 * @return mixed
 */
function curl($url, $data = [])
{
    // 处理get数据
    if (!empty($data)) {
        $url = $url . '?' . http_build_query($data);
    }
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);//这个是重点。
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
//短信发送
//首先在函数顶部引入阿里云短信的命名空间，无需修改，官方sdk自带的命名空间
use Aliyun\Core\Config;
use Aliyun\Core\Profile\DefaultProfile;
use Aliyun\Core\DefaultAcsClient;
use Aliyun\Api\Sms\Request\V20170525\SendSmsRequest;

//阿里短信函数，$mobile为手机号码，$code为自定义随机数
function sendMsg($mobile,$code){

    //这里的路径EXTEND_PATH就是指tp5根目录下的extend目录，系统自带常量。alisms为我们复制api_sdk过来后更改的目录名称
//    require_once EXTEND_PATH.'alisms/vendor/autoload.php';
    require_once EXTEND_PATH.'/alisms/vendor/autoload.php';
    Config::load();             //加载区域结点配置

//    $accessKeyId = 'LTAIGC37voorOjMv';  //阿里云短信获取的accessKeyId
    $accessKeyId = 'LTAI4M9vTkl6iHgL';  //阿里云短信获取的accessKeyId

//    $accessKeySecret = 'C2zkwQ3aP7zOqIvWmpCVJ6UYaZSHHo';    //阿里云短信获取的accessKeySecret
    $accessKeySecret = 'qVuCZ5e1wEhmOt5U56jnrcWD0eVGL2';    //阿里云短信获取的accessKeySecret

    //这个个是审核过的模板内容中的变量赋值，记住数组中字符串code要和模板内容中的保持一致
    //比如我们模板中的内容为：你的验证码为：${code}，该验证码5分钟内有效，请勿泄漏！
    $templateParam = array("code"=>$code);           //模板变量替换

//    $signName = '高顿教育'; //这个是短信签名，要审核通过
    $signName = '西卡弟弟'; //这个是短信签名，要审核通过

//    $templateCode = 'SMS_113465077';   //短信模板ID，记得要审核通过的
    $templateCode = 'SMS_172075257';   //短信模板ID，记得要审核通过的
    //短信API产品名（短信产品名固定，无需修改）
    $product = "Dysmsapi";
    //短信API产品域名（接口地址固定，无需修改）
    $domain = "dysmsapi.aliyuncs.com";
    //暂时不支持多Region（目前仅支持cn-hangzhou请勿修改）
    $region = "cn-hangzhou";
    // 初始化用户Profile实例
    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    // 增加服务结点
    DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", $product, $domain);
    // 初始化AcsClient用于发起请求
    $acsClient= new DefaultAcsClient($profile);
    $request = new SendSmsRequest();
    $request->setPhoneNumbers($mobile);
    $request->setSignName($signName);
    $request->setTemplateCode($templateCode);
    if($templateParam) {
        $request->setTemplateParam(json_encode($templateParam));
    }
    $acsResponse = $acsClient->getAcsResponse($request);
    $result = json_decode(json_encode($acsResponse),true);
    return $result;
}

// 模版方法
function yes_no($val, $yes, $no){
    return $val ? $yes : $no;
}
//获取当前域名的https 路径
function https_base_url()
{
//    $request = Request::instance();
    $subDir = str_replace('\\', '/', dirname(Request::server('PHP_SELF')));
    return 'http' . '://' . Request::host() . $subDir . ($subDir === '/' ? '' : '/');
}
/**
 * 获取当前域名及根路径
 * @return string
 */
function base_url()
{
//    $request = Request::instance();
    $subDir = str_replace('\\', '/', dirname(Request::server('PHP_SELF')));
    return Request::scheme() . '://' . Request::host() . $subDir . ($subDir === '/' ? '' : '/');
}
function ReturnAjax($code, $msg, &$array=null)
{
    if(empty($code)) {
        $return_array= ['code' => 200,'data' => $array, 'msg' => '获取数据成功','time' => time()];
    }else{
        $return_array = ['code' => $code,'data' => $array,'msg' =>$msg,'time' => time()];
    }
    header('Content-type:text/json');
    header("Access-Control-Allow-Origin: *");
    echo json_encode($return_array,JSON_UNESCAPED_UNICODE);die;
}

/**
 * base64多图片上传
 * @param $tag
 * @return false|string
 */
function upload_photofix($tag)
{
    $path = new \stdClass();

    $files = Request::param($tag);
//    dump($files);die;
    $files = json_decode($files,true);

    foreach ($files as $k => $file){
        $imgSrc = base64_img($file);
        $path->$k = $imgSrc;
    }

    return json_encode($path);

}
function base64_img($image){
    $time_date = date("Ymd",time());
    $imageName = "img_".date("YmdHis",time())."_".rand(1111,9999).'.png';
    if (strstr($image,",")){
        $image = explode(',',$image);
        $image = $image[1];
    }
    $root_path = Env::get('root_path');
    $second_path = DIRECTORY_SEPARATOR .'uploads'.DIRECTORY_SEPARATOR. $time_date. "/";

//    $path = get_img_path().$time_date."/";
    $path = $root_path . 'public' . $second_path;
    if (!is_dir($path)){ //判断目录是否存在 不存在就创建
        mkdir($path,0777,true);
    }
    $imageSrc= $path. $imageName; //图片名字
    $r = file_put_contents($imageSrc, base64_decode($image));//返回的是字节数
    if (!$r){
        return '图片错误';
    }else{
//        return $second_path .$imageName;
        return ''. str_replace('\\','/',$second_path.$imageName,$i);
    }
}
//获取图片路径
function get_img_path(){
    $img_path = Env::get('root_path').'public'.DIRECTORY_SEPARATOR .'uploads'.DIRECTORY_SEPARATOR ;
    return $img_path;
}
/*********************************************************************
函数名称:encrypt
函数作用:加密解密字符串
使用方法:
加密     :encrypt('str','E','nowamagic');
解密     :encrypt('被加密过的字符串','D','nowamagic');
参数说明:
$string   :需要加密解密的字符串
$operation:判断是加密还是解密:E:加密   D:解密
$key      :加密的钥匙(密匙);
 *********************************************************************/
function encrypt($string,$operation,$key='')
{
    $key=md5($key);
    $key_length=strlen($key);
    $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
    $string_length=strlen($string);
    $rndkey=$box=array();
    $result='';
    for($i=0;$i<=255;$i++)
        {
            $rndkey[$i]=ord($key[$i%$key_length]);
            $box[$i]=$i;
        }
        for($j=$i=0;$i<256;$i++)
        {
            $j=($j+$box[$i]+$rndkey[$i])%256;
            $tmp=$box[$i];
            $box[$i]=$box[$j];
            $box[$j]=$tmp;
        }
        for($a=$j=$i=0;$i<$string_length;$i++)
        {
            $a=($a+1)%256;
            $j=($j+$box[$a])%256;
            $tmp=$box[$a];
            $box[$a]=$box[$j];
            $box[$j]=$tmp;
            $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
        }
        if($operation=='D')
        {
            if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8))
            {
                return substr($result,8);
            }
            else
            {
                return'';
            }
        }
        else
        {
            return str_replace('=','',base64_encode($result));
        }
    }

/**
 * 判断是否为json字符串
 * @param $string
 * @return bool
 */
function isJson($string) {
    json_decode($string);
    return (json_last_error() == JSON_ERROR_NONE);
}
