<?php
/**
 * Created by cheng. Time: 2018-06-20 11:21:31
 */

namespace app\portal\controller;

use app\td\TdController;

class BaseController extends TdController{


}