<?php
/**
 * Created by cheng. Time: 2018-09-08 14:21:26
 */

namespace app\portal\controller;


class IndexController extends BaseController {

    public function index() {

        //首页的列表
        return 'index pages';
    }

}