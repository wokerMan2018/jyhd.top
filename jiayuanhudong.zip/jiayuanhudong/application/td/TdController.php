<?php

namespace app\td;

use app\admin\model\Classes;
use app\admin\model\Grade;
use app\admin\model\School;
use think\Controller;
use app\td\model\User;
use helper\framework\JsonResult;
use helper\framework\ModelHelper;
use think\facade\Request;

class TdController extends Controller
{
    use JsonResult;
    use ModelHelper;

    /**
     * @var int 默认分页每页显示数量
     */
    protected $page_count = 8;

    /**
     * @var int 当前用户id
     */
    protected $uid = 0;

    /**
     * 当前用户
     * @var \app\td\model\User
     */
    protected $user = null;

    /**
     * 查询构造
     */
    const QUERY_EXP_MAP = [
        'eq' => '=',
        'neq' => '<>',
        'in' => 'in',
        'nin' => 'not in',
        'gt' => '>',
        'egt' => '>=',
        'lt' => '<',
        'elt' => '<=',
        'like' => 'like',
        'start' => 'like',  // like .'%'
        'end' => 'like'
    ];

    protected function initialize()
    {
//        $this->initUser();
        $this->page_count = input('page_count', $this->page_count);

        $this->initXDebug();
    }

    protected function isPost() {
        return $this->request->isPost();
    }

    protected function isGet() {
        return $this->request->isGet();
    }

    /**
     * 访问频率限制
     * @param $count
     * @param $seconds
     * @param string $by
     */
    protected function rateLimit($count, $seconds=300, $by='ip') {
        if(env('DEVELOP_MODE')) {
            return;
        }
        if($by == 'ip') {
            $cache_key = md5($this->request->url() . get_client_ip());
        }
        else {
            exception('未实现');
        }

        list($request_cnt, $cache_time) = cache($cache_key) ?: [0, time()];

        if($request_cnt > $count) {
            $res = [
                'code' => 405,
                'success' => false,
                'data' => new \stdClass(),
                'message' => '访问次数太多，请稍后再试',
                'error_code' => 'RATE_LIMIT'
            ];
            header('Content-Type:application/json; charset=utf-8');
            echo json_encode($res);
            die();
        }
        $request_cnt++;
        $passed_seconds = time() - $cache_time;
        if($passed_seconds < $seconds) {
            cache($cache_key, [$request_cnt, $cache_time], $seconds - $passed_seconds);
        }

    }

    /**
     * 初始化用户信息
     * @throws \think\Exception\DbException
     */
    protected function initUser() {
        $this->uid = session('uid');
        $this->user = empty($this->uid) ? null : User::get($this->uid);
        $this->assign('current_user', $this->user);
    }

    /**
     * 处理用户登录信息
     * @param $user \app\td\model\User
     */
    protected function handlerUserLogin($user) {
        session('uid', $user->id);

        $user->last_login_time = now();
        $user->save();
    }


    /**
     * 根据请求参数生成model查询条件
     * @param array $params_map 字段映射
     * @param array $date_field 日期字段
     * @param array $exclude 排除的字段
     * @param bool $filter_empty_field 是否过滤空值
     * @return array
     */
    public function getQueryParams($params_map=[], $date_field = [], $exclude = ['page', 'page_count'],
                                   $filter_empty_field=true)
    {

        $TABLE_SPLIT = '*';
        $where = [];
        $exclude = array_merge($exclude, self::$EXCEPT_PARAMS);

        $exclude[] = 'is_advance_query';
        $param_arr = $this->request->except($exclude);

        if (empty($param_arr)) {
            return $where;
        }

        foreach ($exclude as $val) {
            unset($param_arr[$val]);
        }


        if(!empty($params_map)) {
            // 字段key=>val替换
            foreach ($params_map as $old_p => $filed_map) {
                if (array_key_exists($old_p, $param_arr)) {
                    if (is_array($filed_map)) {
                        $new_p = $filed_map[0];
                        $new_val = count($filed_map) > 1 ? $filed_map[1] : $param_arr[$old_p];
                    } else {
                        $new_p = $filed_map;
                        $new_val = $param_arr[$old_p];
                    }
                    if ($new_p != $old_p) {
                        unset($param_arr[$old_p]);
                    }
                    $param_arr[$new_p] = $new_val;
                }
                // else {
                //     $param_arr[$old_p] = $filed_map;
                // }
            }
        }


        foreach ($param_arr as $param => $val) {
            if($filter_empty_field && $val === '') {
                continue;
            }
            $p_part = explode('__', $param);

            if($p_part[0] == '_keyword') {
                // 处理keyword查询
                if(!empty($val)) {
                    $_filed = str_replace($TABLE_SPLIT, '.', $p_part[1]);
                    $where[] = [$_filed, 'like', "%{$val}%"];
                }

                $this->request->TD_PAGE = array_replace($this->request->TD_PAGE, ['keyword_query' => $val]);
                continue;
            }

            if (count($p_part) == 1) {
                $p_part[] = 'eq';   // 默认条件是eq
            }
            list($_filed, $_exp) = $p_part;
            $_filed = str_replace($TABLE_SPLIT, '.', $_filed);


            if(!array_key_exists($_exp, self::QUERY_EXP_MAP)) {
                continue;
            }

            if(!in_array($_filed, $date_field)) {
                switch ($_exp) {
                    case 'like':
                        $_condition = [$_filed, 'like', '%' . $val . '%'];
                        break;
                    case 'start':
                        $_condition = [$_filed, 'like', $val . '%'];
                        break;
                    case 'end':
                        $_condition = [$_filed, 'like', '%' . $val];
                        break;
                    default:
                        $_condition = [$_filed, self::QUERY_EXP_MAP[$_exp], $val];
                }
            }
            else if (!empty($date_field) && in_array($_filed, $date_field)) {
                // 日期查询处理
                $_date_min = $val . ' 00:00:00';
                $_date_max = $val . ' 23:59:59';

                if ($_exp == 'eq') {
                    $where[] = [$_filed, '>=', $_date_min];
                    $where[] = [$_filed, '<=', $_date_max];
                }
                elseif($_exp == 'gt' || $_exp == 'egt') {
                    $_condition = [$_filed, self::QUERY_EXP_MAP[$_exp], $_date_min];
                }
                elseif ($_exp == 'lt' || $_exp == 'elt') {
                    $_condition = [$_filed, self::QUERY_EXP_MAP[$_exp], $_date_max];
                }
            }
            if(isset($_condition)) {
                $where[] = $_condition;
            }

        }
        return $where;
    }


    /**
     * xdebug 显示array深度设置
     */
    private function initXDebug()
    {
        if (env('DEVELOP_MODE')) {
            ini_set('xdebug.var_display_max_depth', 6);
            ini_set('xdebug.var_display_max_children', 256);
            ini_set('xdebug.var_display_max_data', 4096);
        }
    }
    /**
     * 获取所有学校
     */
    public function getSchool()
    {
        if (Request::isGet()){
            $sids = School::all(function ($query){
                $query->field('id,name');
            });
            if ($sids){
                self::ReturnAjax(2000,'',$sids);
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
    /**
     *获取学校对应年级
     */
    public function getGrade()
    {
        if (Request::isPost()){
            $sid = input('sid');
            $graids = Grade::all(function ($query) use ($sid){
                $query->where(['sid'=>$sid])->field('id,graname');
            });
            if ($graids){
                self::ReturnAjax(2000,'',$graids);
            }
        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }
    /**
     * 获取年级下的班级
     */
    public function getClasses()
    {
        if (Request::isPost()){
            $post = Request::param();
            $rule = [
                'gid|年级id'=>'require'
            ];
            $res = $this->validate($post,$rule);
            if (true !== $res){
                self::ReturnAjax(2001,$res);
            }
            $classes = Classes::all(function ($query) use ($post){
                $query->where(['graid'=>$post['gid']])->field('id,gname');
            });
            if ($classes){
                self::ReturnAjax(2000,'',$classes);
            }

        }else{
            self::ReturnAjax(2001,'请求类型错误');
        }
    }



}