<?php
namespace app\td\model;
use app\td\TdModel;

class UserRole extends TdModel {


    protected $table = 'td_user_role';

    /**
     * 获取用户角色id，带缓存
     * @param $uid
     * @param bool $clear_cache 是否清除缓存
     * @return array|mixed
     */
    public static function getUserRoleIds($uid, $clear_cache=false) {
        $key = 'user_role_' . $uid;
        if($clear_cache) {
            self::clearCache($key);
            $result = false;
        }
        else {
            $result = UserRole::getTCache($key);
        }

        if($result === false) {
            $result = self::where('uid', $uid)->column('role_id');
            UserRole::setTCache($key, $result);
        }
        return $result;
    }

    public static function addUserRole($uid, $role_id) {
        $key = 'user_role_' . $uid;
        self::clearCache($key);
        return self::create([
            'uid' => $uid,
            'role_id' => $role_id
        ]);
    }

    public static function removeUserRole($uid, $role_id) {
        $key = 'user_role_' . $uid;
        self::where('uid', $uid)->where('role_id', $role_id)->delete();
        self::clearCache($key);
    }

    /**
     *
     * @return int
     */
    public static function getAdminRoleId() {
        $result = UserRole::getTCache('admin_role_id');
        if($result === false) {
            $result = db('role')->where('code', 'admin')->value('id');
            UserRole::setTCache('admin_role_id', $result, 3600 * 24 * 30);
        }

        return $result;
    }
}