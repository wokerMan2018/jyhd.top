<?php
namespace app\td\model;

use app\td\TdModel;

class Role extends TdModel {

    protected $name = 'role';

    public static function deleteRole($id) {
        db()->transaction(function() use ($id) {
            self::where('id', $id)->delete();
            db('user_role')->where('role_id', $id)->delete();
        });
    }
}