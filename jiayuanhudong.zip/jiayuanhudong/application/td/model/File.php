<?php

namespace app\td\model;
use app\td\TdModel;

use think\model\concern\SoftDelete;

class File extends TdModel
{
    use SoftDelete;
    protected $autoWriteTimestamp = 'datetime';
    protected $table = 'td_file';

    /**
     * 根据文件id获取url
     * @param $fid int  文件id
     * @param string $default 默认返回
     * @return string
     */
    static public function getFileUrl($fid, $default = '')
    {
        $file = self::where('id', $fid)->cache(true)->find();
        if(empty($file)) {
            return $default;
        }

        return get_base_url() . $file->file_path;
    }

}
