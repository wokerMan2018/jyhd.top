<?php

namespace app\td\model;

use app\td\TdModel;
/**
 * 角色分配菜单表
 * Class RoleMenu
 * @package app\td\model
 */
class RoleMenu extends TdModel
{
    protected $name = 'role_menu';

}