<?php
namespace app\td\model;

use think\Db;
use think\model\concern\SoftDelete;
use app\td\TdModel;
use app\td\model\UserRole;

class Menu extends TdModel {

    protected $table = 'td_menu';
    protected $autoWriteTimestamp = 'datetime';

    use SoftDelete;

    public static function getMenuTree($grouping, $uid=null) {
        $q = self::where('enable', 1);
        if($grouping){
            $q = $q->where('grouping', $grouping);
        }

        if($uid === null || User::isAdmin($uid)) {
            $menuList = $q->order('grouping,sorting')->select();
        }
        else {
            $menu_id_by_role = Db::name('role_menu')->where('role_id', 'in', UserRole::getUserRoleIds($uid))->column('menu_id');
            $menuList = $q->where('id', 'in', $menu_id_by_role)
                ->order('grouping,sorting')->select();
        }

        return self::buildMenuTree($menuList);
    }

    public static function buildMenuTree($sourceItems, $pid=null) {
        $result = [];
        if(empty($sourceItems)) {
            return null;
        }
        foreach ($sourceItems as $key => $item) {
            if($item->pid == $pid) {

                $item['children'] = self::buildMenuTree($sourceItems, $item->id);
                $result[] = $item->toArray();
            }
        }

        return $result;
    }

    /**
     * 获取菜单的url
     * @param $value
     * @param $data
     * @return mixed|string
     */
    public function getExtUrlAttr($value,$data) {
        if($data['type'] == 'action') {
            if(!$data['is_leaf']) {
                return '';
            }
            return url( $data['module'] . '/' . $data['controller'] . '/' . $data['action']);
        }
        elseif ($data['type'] == 'page') {
            return '';
        }
        elseif ($data['type'] == 'ext_url') {
            return $data['ext_url'];
        }
        return '';
    }

}