<?php
namespace app\td\model;

use think\model\concern\SoftDelete;
use app\td\TdModel;

class Page extends TdModel {
    use SoftDelete;
    protected $autoWriteTimestamp = 'datetime';

}