<?php

namespace app\td\model;

use think\model\concern\SoftDelete;
use think\Db;
use app\td\TdModel;

/**
 * @property mixed id
 * @property mixed u_type
 * @property mixed auth_type
 * @property string cids
 * @property integer integral
 * @property integer graids
 * @property string wx_openid
 * @property integer addr_id
 * @property string username
 */
class User extends TdModel
{
    use SoftDelete;

    protected $table = 'td_user';

    protected $autoWriteTimestamp = 'datetime';

    const HASH_TIMES = 4;
    const HASH_ALGO = 'sha256';

    protected static function init()
    {
        self::beforeDelete(function ($user) {
            if($user->username == 'admin') {
                return false;
            }
        });

        self::afterDelete(function ($user) {
            Db::table('td_user_profile')->where('uid', $user->id)
                ->useSoftDelete('delete_time', date('Y-m-d H:i:s'))
                ->delete();
        });
    }

    public static function getDefaultPhotoUrl() {
        return get_base_url() . '/static/admin/image/default_avatar.png';
    }


    public function profile()
    {
        return $this->hasOne('UserProfile', 'uid');
    }

    public function getPhotoUrlAttr($value, $data) {
        if(empty($data['photo_fid'])) {
            return self::getDefaultPhotoUrl();
        }
        return File::getFileUrl($data['photo_fid']);
    }

    public function getLastLoginIpAttr($value, $data) {
        if($value == 0) {
            return '';
        }
        else {
            return long2ip($value);
        }
    }

    /**
     * 判断用户名和密码是否正确

     * @param $username string 用户名
     * @param $raw_pwd string 密码
     * @param $type Integer 类型（1-检测密码，2-检测提现密码）
     * @return User | null
     */
    public static function checkPassword($username, $raw_pwd, $type =1)
    {

        $user = User::where(['username' => $username])->find();

        if (empty($user)) {
            return null;
        }
        if($type == 1) {
            $hash_pwd = $user->password;
        }else if($type == 2) {
            $hash_pwd = $user->withdraw_pwd;
        }

        if (empty($hash_pwd)) {
            return null;
        }
        $pwd_parts = explode('$', $hash_pwd);
        $salt = $pwd_parts[1];
        if (!empty($salt)) {
            if (self::genPassword($raw_pwd, $salt) === $hash_pwd) {
                unset($user->password);
                return $user;
            }
        }
        return null;
    }

    /**
     * @param $tel
     * @param $raw_pwd
     * @param int $type
     * @return array|null|\PDOStatement|string|\think\Model
     * 判断手机号码和密码是否正确
     */
    public static function checkMobliePassword($tel,$raw_pwd,$type=1){
        $user = User::where(['tel' => $tel])->find();

        if (empty($user)) {
            return null;
        }
        if($type == 1) {
            $hash_pwd = $user->password;
        }else if($type == 2) {
            $hash_pwd = $user->withdraw_pwd;
        }

        if (empty($hash_pwd)) {
            return null;
        }
        $pwd_parts = explode('$', $hash_pwd);
        $salt = $pwd_parts[1];
        if (!empty($salt)) {
            if (self::genPassword($raw_pwd, $salt) === $hash_pwd) {
                unset($user->password);
                return $user;
            }
        }
        return null;
    }

    public static function changePassword($username, $newPassword)
    {
        $hash_password = self::genPassword($newPassword);
        return self::where(['username' => $username])->setField('password', $hash_password);
    }

    /**
     * 生成密码
     * @param $password string 原密码
     * @param $salt string 盐
     * @return string 加密后的密码
     */
    public static function genPassword($password, $salt = '')
    {
        if (empty($salt)) {
            $salt = random_str();
        }
        $hashPassword = hash_pbkdf2(self::HASH_ALGO, $password, $salt, self::HASH_TIMES);
        return self::HASH_ALGO . '$' . $salt . '$' . $hashPassword;
    }

    /**
     * 判断用户是否有管理员权限
     * @param $uid
     * @return bool
     */
    public static function isAdmin($uid) {
        $roles = UserRole::getUserRoleIds($uid);
        $admin_role_id = UserRole::getAdminRoleId();
        if(empty($roles)) {
            return false;
        }
        return in_array($admin_role_id, $roles);
    }

    /**
     * 新增后台用户
     * @param array $data 用户信息
     * @param array $roles 角色id数组
     */
    public static function addStaff($data, $roles) {
        Db::transaction(function() use($data, $roles) {
            $user = self::create([
                'username' => $data['username'],
                'nickname' => $data['nickname'],
                'password' => self::genPassword($data['password']),
                'is_staff' => 1,    // 后台用户标记
            ]);
            if(!$user) {
                exception('新增用户错误');
            }
            if(!empty($roles)) {
                $roles_to_add = [];
                foreach ($roles as $k => $role) {
                    $roles_to_add[] = [
                        'uid' => $user->id,
                        'role_id' => $role
                    ];
                }
                $userRole = new UserRole();
                $res = $userRole->saveAll($roles_to_add);
                if (empty($res)) {
                    exception('新增用户角色错误');
                }
            }
        });
    }

    /**
     * 判断用户是否存在
     * @param $username
     * @return bool
     */
    public static function isUserExists($username)
    {
        $data = self::where(['username' => $username])->find();
        return !empty($data);
    }

    /**
     * @param $tel
     * @return bool
     * 判断手机是否存在
     */
    public static function isTelExists($tel){
        $data = self::where(['tel' => $tel])->find();
        return !empty($data);
    }

}