<?php
namespace app\td\model;

use think\model\concern\SoftDelete;
use app\td\TdModel;

class UserProfile extends TdModel
{
    use SoftDelete;

    protected $table = 'td_user_profile';
    protected $readonly = ['uid'];
    protected $autoWriteTimestamp = 'datetime';

}