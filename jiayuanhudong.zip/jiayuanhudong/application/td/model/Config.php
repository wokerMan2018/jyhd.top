<?php
namespace app\td\model;
use app\td\TdModel;

use think\model\concern\SoftDelete;

class Config extends TdModel {

    protected $table = 'td_config';
    protected $readonly = ['key'];
    protected $autoWriteTimestamp = 'datetime';

    public static function getConfigList($grouping=''){
        $where = [];
        if(!empty($grouping)) {
            $where['grouping'] = $grouping;
        }
        return self::where($where)->order(['grouping' => 'desc', 'sorting' => 'desc'])->select();
    }
    /**
     * 获取指定的val
     * @param $key
     * @param null $default 默认值
     * @return mixed
     */
    public static function getConfigVal($key, $default=null) {
        $all_config = Config::getTCache('all');
        if(!$all_config) {
            $all_config = self::column('val', 'key');
            Config::setTCache('all', $all_config);
        }
        return $all_config[$key] ?: $default;
    }

    public static function getVal($key) {

    }
}