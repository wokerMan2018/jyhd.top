<?php

namespace app\td\model;

use think\Db;
use app\td\TdModel;

/**
 * 用户帐号金额表
 * Class Balance
 * @package app\td\model
 */
class Balance extends TdModel {
    protected $table = 'td_user_profile';

    const CHANGE_TYPE_DEPOSIT = 10; // 充值
    const CHANGE_TYPE_WITHDRAW = 20;    // 提现


    /**
     * 用户金额变动
     * @param $uid int 用户id
     * @param $amount number 变动金额，增加为正数，减少为负数
     * @param int $change_type 变动类型
     * @param null $change_id 关联id
     * @return bool
     */
    public static function change($uid, $amount, $change_type, $change_id=null)
    {
        Db::startTrans();

        $profile = self::where('uid', $uid)->find();
        if(empty($profile)) {
            return false;
        }
        $balance_after = $profile->balance + $amount;
        if($balance_after < 0) {
            exception('金额不能小于0', 3001);
        }
        $profile->balance = $balance_after;
        $profile->save();

        Db::table('td_balance_log')->insert([
            'uid' => $uid,
            'amount' => $amount,
            'change_type' => $change_type,
            'balance' => $balance_after,
            'change_id' => $change_id,
        ]);
        Db::commit();

        return true;
    }
}