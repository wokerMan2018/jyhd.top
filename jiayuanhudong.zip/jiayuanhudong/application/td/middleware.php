<?php

// Error应放在最后面
return [
    'TemplateVars', 'Error',
    'CrosHeader'
];