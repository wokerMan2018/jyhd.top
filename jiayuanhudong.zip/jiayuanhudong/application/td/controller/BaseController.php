<?php
namespace app\td\controller;

use app\admin\controller\BaseController as AdminBaseController;

class BaseController extends AdminBaseController {
    
}