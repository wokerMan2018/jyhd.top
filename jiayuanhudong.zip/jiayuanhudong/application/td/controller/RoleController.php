<?php
namespace app\td\controller;

use think\Db;
use app\td\model\Menu;
use app\td\model\Role;
use app\td\model\UserRole;
use app\td\model\RoleMenu;

class RoleController extends BaseController {

    public function index()
    {
        $where = $this->getQueryParams();
        $list = Role::where($where)->paginate($this->page_count, false, ['query' => $this->paginateParams()]);
        $page = $list->render();
        $roleList = Role::where('code', '<>', 'admin')->select();

        $menuTreeAll = Menu::getMenuTree(null);
        $this->assign('dataList', $list);
        $this->assign('roleList', $roleList);
        $this->assign('menuTreeAll', $menuTreeAll);
        $this->assign('page', $page);

        return view();
    }


    /**
     * 新增角色
     */
    public function add() {
        if($this->isGet()) {
            return view();
        }
        $name = input('name', '');
        $code = input('code', '');
        if(empty($name) || empty($code)) {
            return $this->jsonFailed('角色名称和代码不能为空');
        }
        $check_code = Role::where('code', $code)->find();
        if($check_code) {
            return $this->jsonFailed('角色代码已经存在');
        }

        Role::create([
            'name' => $name,
            'code' => $code,
            'is_sys' => 0,
        ]);

        RoleMenu::clearCache();
        return $this->jsonSuccess(null, '新增成功', url('index'));
    }

    /**
     * 根据角色id获取菜单
     * @return \think\response\Json
     */
    public function get_menu_by_role() {
        $role_id = input('role_id', '');
        if(empty($role_id)) {
            return $this->jsonFailed('');
        }
        $menu_list = RoleMenu::where('role_id', $role_id)->column('menu_id');

        return $this->jsonSuccess(['menus' => $menu_list]);
    }

    /**
     * 保存角色菜单信息
     */
    public function save_role_menu() {
        $role_id = input('role_id', '');
        $menus = input('menus', []);
        if(empty($role_id)) {
            return $this->jsonFailed('请选择角色');
        }
        Db::transaction(function () use($menus, $role_id){
            RoleMenu::where('role_id', $role_id)->delete();
            if(!empty($menus)) {
                $data_to_add = [];
                foreach ($menus as $k => $menu_id) {
                    $data_to_add[] = [
                        'role_id' => $role_id,
                        'menu_id' => $menu_id
                    ];
                }
                RoleMenu::insertAll($data_to_add);
            }
            // 清除菜单缓存
            Menu::clearCache();
            RoleMenu::clearCache();
        });
        return $this->jsonSuccess('更新成功');
    }

    public function delete() {
        $id = input('id');
        $idList = explode(',', $id);
        if(empty($idList)) {
            return $this->jsonFailed('删除失败, id参数错误');
        }
        $admin_role = UserRole::getAdminRoleId();
        if(in_array($admin_role, $idList)) {
            return $this->jsonFailed('管理员角色不能删除');
        }

        $result = Role::where('id','in', $idList)->delete();
        if(!$result) {
            return $this->jsonFailed('删除失败');
        }
        RoleMenu::clearCache();
        return $this->jsonSuccess('删除成功');
    }
}