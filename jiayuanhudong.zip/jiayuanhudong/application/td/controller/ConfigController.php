<?php
namespace app\td\controller;

use app\td\model\Menu;
use app\td\model\Role;
use app\td\model\UserRole;
use app\td\model\RoleMenu;
use think\Db;
class ConfigController extends BaseController {

    public function index()
    {
        if($this->request->isPost()){
            $post = $this->request->post();
            $updateDate = [
                'name'=>$post['name'],
                'desc'=>$post['desc'],
                'price'=>$post['price'],
                'effective_time'=>$post['effective_time']
            ];
            $res = Db::name('website')->where('id',1)->update($updateDate);
            if($res){
                return $this->jsonSuccess(null,'更新成功');
            }else{
                return $this->jsonFailed('修改失败');
            }
        }
        $website = Db::name('website')->where('id',1)->find();
        $this->assign('website',$website);
        return view();
    }

}