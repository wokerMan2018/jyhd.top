<?php

namespace app\td\controller;

use app\td\model\User;
use helper\db\MysqlImport;
use helper\db\MysqlDump;

class DbController extends BaseController {

    public static $backupDir = BASE_PATH . '/public/backup';


    public function initialize()
    {
        parent::initialize();
        set_time_limit(360);
        ini_set('memory_limit','500M');
    }

    public function backup(){

        $db = new \mysqli(env('DB_HOST'), env('DB_USER'), env('DB_PASSWORD'), env('DB_NAME'), env('DB_PORT', 3306));
        $dump = new MysqlDump($db);
        $dir = self::$backupDir . '/' . date('Ymd') . '/';
        if(!is_dir($dir)) {
            mkdir($dir, 0755);
        }
        $filename = $dir . date('Ymd_His') . '_' . env('DB_NAME') . '.sql.gz';
        $dump->save($filename);
        return $this->jsonSuccess();
    }

    public function index() {
        $files = glob(self::$backupDir . '/*/*.sql.gz', GLOB_MARK);
        $fileList = [];
        foreach ($files as $k => $file) {

            $fileTime = filemtime($file);
            $fileSize = filesize($file) / 1024;
            //获取文件大小
            $fileSize = $fileSize < 1024 ? number_format($fileSize, 2) . ' KB' : number_format($fileSize / 1024, 2) . ' MB';
            //构建列表数组 按创建时间组装 排序
            $fileList[$fileTime] = [
                'path' => base64_url_encode($file),
                'name' => basename($file),
                'time' => $fileTime,
                'size' => $fileSize
            ];
        }
        krsort($fileList);

        $this->assign('fileList', $fileList);
        return view();
    }

    public function recover() {
        $file = input('file');
        $file = base64_url_decode($file);
        if(empty($file)) {
            return $this->jsonFailed('文件参数错误');
        }
        if(!is_file($file)) {
            return $this->jsonFailed('文件不存在');
        }

        $db = new \mysqli(env('DB_HOST'), env('DB_USER'), env('DB_PASSWORD'), env('DB_NAME'), env('DB_PORT', 3306));
        $import = new MysqlImport($db);

        $import->load($file);

        return $this->jsonSuccess();
    }

    public function download_backup() {
        $file = input('file');
        if(empty($file)) {
            echo 'empty file';
            exit;
        }
        $file_path = base64_url_decode($file);
        $file = fopen($file_path, "r");

        header('Content-Encoding: none');
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: " . filesize($file_path));
        header('Content-Transfer-Encoding: binary');
        header("Content-Disposition: attachment; filename=" . basename($file_path));
        header('Pragma: no-cache');
        header('Expires: 0');
        //输出文件内容
        echo fread($file, filesize($file_path));
        fclose($file);
        exit;
    }

    public function delete() {
        $file = input('id');
        if(empty($file)) {
            echo 'empty file';
            exit;
        }
        $file_path = base64_url_decode($file);
        unlink($file_path);
        return $this->jsonSuccess();
    }
}