<?php

namespace app\td\controller;

use app\td\model\User;
use app\td\model\File;
use app\td\model\UserRole;
use think\Db;

class UserController extends BaseController
{
    protected $actionActiveMenuMap = [
        'add' => 'td/user/index',
    ];

    public function initialize()
    {
        parent::initialize();
        $this->model = new User();
    }

    public function index() {

        $where = $this->getQueryParams();
        $list = User::where('is_staff', 1)->where($where)->paginate($this->page_count, false, ['query' => $this->paginateParams()]);

        $page = $list->render();

        $this->assign('userList', $list);
        $this->assign('page', $page);
        return view();
    }

    public function delete() {

        $id = $this->request->param('id');
        $idList = explode(',', $id);
        if(empty($idList)) {
            return $this->jsonFailed('删除失败, id参数错误');
        }


        db()->transaction(function() use($idList) {
            db('user')->where('id', 'in', $idList)->delete();
            db('user_role')->where('uid', 'in', $idList)->delete();
        });

        return $this->jsonSuccess('删除成功');
    }

    public function enable() {
        $id = $this->request->param('id');
        $enable =$this->request->param('enable');
        $user = User::get($id);
        if(empty($user)) {
            return $this->jsonFailed('用户不存在');
        }
        if($user->username == 'admin') {
            return $this->jsonFailed('系统管理员帐号无法禁用');
        }
        $new_val = $enable == 1 ? 0 : 1;
        $user->enable = $new_val;
        $user->save();
        return $this->jsonSuccess(['enable' => $new_val], $message='更新成功');
    }

    public function edit()
    {
        $uid = input('id');
        $user = User::get($uid);
        if($this->isGet()) {
            $roleSelect = db('role')->field('id, name as text')->select();
            $user_role_list = UserRole::where('uid', $uid)->column('role_id');

            foreach ($roleSelect as $k => &$role) {
                $role['selected'] = in_array($role['id'], $user_role_list);
            }

            $this->assign('roleSelect', json_encode($roleSelect));
            $this->assign('vo', $user);
            return view();
        }

        //修改
        $nickname = input('nickname', '');
        $password = input('password', '');
        $password2 = input('password2');
        $roles = input('roles/a', []);
        if(empty($nickname)) {
            return $this->jsonFailed('昵称不能为空');
        }

        if(!empty($password) && $password != $password2) {
            return $this->jsonFailed('两次密码不一致');
        }

        if(empty($roles)) {
            return $this->jsonFailed('角色不能为空');
        }
        $user->nickname = $nickname;
        if(!empty($password)) {
            $user->password = User::genPassword($password);
        }
        db()->transaction(function() use($user, $roles) {
            $user->save();
            $roles_to_add = [];
            foreach ($roles as $k => $role) {
                $roles_to_add[] = [
                    'uid' => $user->id,
                    'role_id' => $role
                ];
            }
            $userRole = new UserRole();
            $userRole->where('uid', $user->id)->delete();
            $userRole->saveAll($roles_to_add);
        });
        return $this->jsonSuccess(null, '修改用户成功', url('index'));
    }

    /**
     * 用户设置
     */
    public function profile() {

        if($this->isGet()) {
            if(!empty($this->user->photo_fid)) {
                $file = File::where('id', $this->user->photo_fid)->find();
                $this->assign('photo_file', $file);
            }

            return view();
        }
        else {
            $nickname = $this->request->param('nickname');
            $photo_fid = $this->request->param('photo_fid');
            $password = $this->request->param('password');
            $password2 = $this->request->param('password2');
            $data = ['nickname' => $nickname];
            if(!empty($password) || !empty($password2)) {
                if($password != $password2) {
                    return $this->jsonFailed('两次密码不一致');
                }
                $data['password'] = User::genPassword($password);
            }
            if(!empty($photo_fid)) {
                $data['photo_fid'] = $photo_fid;
            }
            User::where('id', $this->user->id)->update($data);

            return $this->jsonSuccess();
        }
    }

    /**
     * 新增后台用户
     */
    public function add() {
        if($this->isGet()) {
            $roleSelect = db('role')->field('id, name as text')->select();
            $this->assign('roleSelect', json_encode($roleSelect));
            return view();
        }

        //新增
        $username = input('username', '');
        $nickname = input('nickname', '');
        $password = input('password', '');
        $password2 = input('password2');
        $roles = input('roles/a', []);

        if(empty($nickname) || empty($username)) {
            return $this->jsonFailed('用户名和昵称不能为空');
        }
        if(empty($password) || empty($password2)) {
            return $this->jsonFailed('密码不能为空');
        }
        if($password != $password2) {
            return $this->jsonFailed('两次密码不一致');
        }
        $check_user = User::where('username', $username)->find();
        if(!empty($check_user)) {
            return $this->jsonFailed('用户名已存在');
        }
        if(empty($roles)) {
            return $this->jsonFailed('角色不能为空');
        }
        $res = User::addStaff([
            'username' => $username,
            'nickname' => $nickname,
            'password' => $password,
        ], $roles);
        return $this->jsonSuccess(null, '新增用户成功', url('td/user/index'));
    }

}