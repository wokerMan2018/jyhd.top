<?php
namespace app\td\controller;
use app\td\model\Menu;


/**
 * 后台菜单管理控制器
 * Class MenuController
 * @package app\td\Controller
 */
class MenuController extends BaseController {


    public function index() {
        $menuList = Menu::where(['grouping' => 'admin'])->order('sorting')->select();
        $menuTree = Menu::buildMenuTree($menuList);
        $this->assign('menuList', $menuTree);

        return view();
    }

    /**
     * 更新菜单树结构
     * data格式
     * @return \think\response\Json
     * @throws \Exception
     */
    public function update_tree() {
        $data = input('data');
        $sort_index = 1;
        $list = [];
        foreach ($data as $key => $menu) {
            $menu_id = $menu['id'];
            $list[] = [
                'id' => $menu_id,
                'sorting' => $sort_index * 10,
                'is_leaf' => isset($menu['children']) ? '0' : 1,
                'pid' => null,
            ];
            if(isset($menu['children'])) {
                foreach ($menu['children'] as $s_key => $s_menu) {
                    $list[] = [
                        'id' => $s_menu['id'],
                        'sorting' => $sort_index * 10,
                        'is_leaf' => 1,
                        'pid' => $menu_id
                    ];
                    $sort_index++;
                }
            }
            $sort_index++;
        }
        $menuModel = new Menu();
        $menuModel->saveAll($list);
        Menu::clearCache();
        return $this->jsonSuccess();
    }

    public function add() {
        $pid = input('pid', null);
        $module = input('module', 'admin');
        $ctrl = input('controller');
        $action = input('action');
        if($pid == ""){
            $pid = null;
        }
        $data = [
            'pid' => $pid,
            'title' => input('title', ''),
            'icon' => 'fa ' . input('icon', 'fa-circle-thin'),
            'module' => $module,
            'controller' => $ctrl,
            'action' => $action,
            'grouping' => input('grouping', 'admin')
        ];
        if($ctrl == "" && $action == "" && !$pid){
            $data['is_leaf'] = 0 ;
        }
        Menu::create($data)->save();
        Menu::clearCache();
        return $this->jsonSuccess(null, '更新成功');
    }

    public function edit() {
        $id = input('id');
        if(empty($id)) {
            $this->error('id为空');
        }
        $menu = Menu::get($id);
        if($this->isGet()) {


            $menu['icon'] = str_replace('fa ', '', $menu['icon']);
            $this->assign('vo', $menu);
            return view();
        }

        // 修改
        $pid = input('pid');
        if($pid == ""){
            $pid = null;
        }
        $module = input('module', 'admin');
        $ctrl = input('controller');
        $action = input('action');
        $data = [
            'pid' => $pid,
            'title' => input('title', ''),
            'icon' => 'fa ' . input('icon', 'fa-circle-thin'),
            'module' => $module,
            'controller' => $ctrl,
            'action' => $action,
        ];
        if($ctrl == "" && $action == "" && !$pid){
            $data['is_leaf'] = 0 ;
        }

        Menu::where('id', $id)->update($data);
        Menu::clearCache();
        return $this->jsonSuccess(null, '添加成功');
    }

    /**
     * 设置是否隐藏
     * @return \think\response\Json
     */
    public function enable() {
        $id = input('id', 0);
        $enable = input('enable', 0);
        if(empty($id)) {
            return $this->jsonFailed('id不能为空');
        }
        $enable = $enable == 1 ? 0 : 1;
        Menu::where('id', $id)->update(['enable' => $enable]);
        if(!$enable) {
            // 禁用子菜单状态
            Menu::where('pid', $id)->update(['enable' => $enable]);
        }
        Menu::clearCache();
        return $this->jsonSuccess(['enable' => $enable], '更新成功');
    }

    public function get_menu_select() {
        $selected_id = input('selected_id', '');
        $menu_list = Menu::where('pid', 'null')->order('sorting')->field('id, title as text')->select()->toArray();
        // select数据格式 https://select2.org/data-sources/ajax
        $results = [['id' => '', 'text' => '请选择']];
        $results = array_merge($results, $menu_list);
        foreach ($results as $k => &$sel) {
            if($sel['id'] == $selected_id) {
                $sel['selected'] = true;
            }
        }
        return json([
            'results' => $results
        ]);
    }
}