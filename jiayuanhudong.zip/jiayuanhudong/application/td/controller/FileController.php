<?php

namespace app\td\controller;

use app\td\TdController;
use app\td\model\File;
use helper\QinNiu;

/**
 * 文件通用控制器
 * Class FileController
 * @package app\td\controller
 */
class FileController extends BaseController {

    public static $MAX_FILE_SIZE = 1024 * 1024 * 100; // 100M
    public static $ALLOW_FILE_EXT = [
        "png", "jpg", "jpeg", "gif", "bmp",
        "flv", "swf", "mkv", "avi", "rm", "rmvb", "mpeg", "mpg",
        "ogg", "ogv", "mov", "wmv", "mp4", "webm", "mp3", "wav", "mid",
        "rar", "zip", "tar", "gz", "7z", "bz2", "cab",
        "doc", "docx", "xls", "xlsx", "ppt", "pptx", "pdf", "txt", "md", "xml"
    ];

    protected $exceptAuthActions = ['upload', 'get_qiniu_upload_token'];

    /**
     * 根据hash显示文件
     */
    public function show($hash) {

    }

    public function index() {
        return 'aaaa';
    }

    /**
     * 单文件上传文件
     */
    public function upload() {
        $cat = $this->request->param('cat', 'editor');
        if(!preg_match('/[a-zA-Z1-9]/', $cat)) {
            return $this->jsonFailed('cat参数只能为字母和数字');
        }
        $f = $this->request->file($cat);
        if(empty($f)) {
            return $this->jsonFailed('未获取文件');
        }
        $upload = $f->validate(['size' => self::$MAX_FILE_SIZE,'ext'=> implode(',', self::$ALLOW_FILE_EXT) ])
            ->rule('sha1')->move(UPLOAD_DIR . '/' . $cat);
        if($upload){
            $file = new File();
            $file->sha1 = $upload->sha1();
            $exists_file = File::where('sha1', $file->sha1)->find();
            if(!empty($exists_file)) {
                // 文件sha1已存在，直接使用原来的
                return $this->jsonSuccess(['fid' => $exists_file->id, 'url' => get_base_url() . $exists_file->file_path]);
            }
            $file->category = $cat;
            $file->name = $upload->getInfo('name');
            $file->file_name = $upload->getFilename();
            $file->file_ext = $upload->getExtension();
            $file->file_path = '/uploads/' . $cat . '/' . str_replace('\\', '/', $upload->getSaveName());
            $file->file_size = $upload->getInfo('size');
            if(!empty($this->user)) {
                $file->upload_by = $this->user->id;
            }
            $file->mime_type = $upload->getInfo('type');

            $file->save();
            return $this->jsonSuccess(['fid' => $file->id, 'url' => get_base_url() . $file->file_path]);

        }else{
            // 上传失败获取错误信息
            return $this->jsonFailed("上传文件失败:{$f->getError()}");
        }

    }
    public function get_qiniu_upload_token(){
        $qiniu = new QinNiu();
        $token = $qiniu->get_upload_token();
        return $this->jsonSuccess(['token' => $token, 'QINIU_URL' => env('QINIU_URL')]);
    }


    /**
     * 下载文件
     */
    public function download() {

    }

    public function photo() {
        $id = $this->request->param('id');
    }
}