<?php

namespace app\td\controller;

use think\Controller;

class InfoController extends Controller{

    public function ex() {
        $code = input('code');
        $error_image = get_base_url() . '/static/common/image/error.jpg';
        $this->assign('error_code', $code);
        $this->assign('error_image', $error_image);
        return view();
    }
}