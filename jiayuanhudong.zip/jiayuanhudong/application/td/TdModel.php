<?php
/**
 * Created by cheng. Time: 2018-09-08 14:28:26
 */

namespace app\td;

use think\Model;
use think\facade\Cache;
use helper\framework\ModelHelper;

class TdModel extends Model {
    use ModelHelper;

    /**
     * 获取模型的缓存tag
     * @param string $group
     * @return mixed|string
     */
    public static function getCacheTag($group='') {
        if($group === '') {
            return str_replace('\\', '_', static::class);
        }
        else {
            return str_replace('\\', '_', static::class) . ':' . $group;
        }
    }

    /**
     *
     * @param $key
     * @param string $group
     * @return string
     */
    public static function getCacheKey($key, $group='') {
        return self::getCacheTag($group) . ':' . $key;
    }

    /**
     * 按tag设置缓存
     * @param $key
     * @param $value
     * @param null|int $expire
     * @param string $group
     */
    public static function setTCache($key, $value, $expire=null,  $group='') {
        $_tag = self::getCacheTag($group);
        $_key = self::getCacheKey($key, $group);
        Cache::tag($_tag)->set($_key, $value, $expire);
    }


    public static function getTCache($key, $group='') {
        return Cache::get(self::getCacheKey($key, $group));
    }

    /**
     * 清空缓存，key为空清空模型关联tag的缓存
     * @param string $key
     * @param string $group
     */
    public static function clearCache($key='', $group='') {
        if($key === '') {
            Cache::clear(self::getCacheTag($group));
        }
        else {
            Cache::rm(self::getCacheKey($key='', $group=''));
        }
    }
}