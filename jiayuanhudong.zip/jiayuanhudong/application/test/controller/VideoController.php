<?php

namespace app\test\controller;

use helper\QinNiu;
use think\Controller;
use think\Request;
use app\admin\service\CurlUploadFile;
// 引入鉴权类
use Qiniu\Auth;
// 引入上传类
use Qiniu\Storage\UploadManager;

class VideoController extends Controller
{
    public function demo3()
    {
        $json = [
            (object)[
                'car_id' => 4,
                'gid' => 28,
                'goods_num' =>2 ,
                'stockId' =>47
            ],
            (object)[
                'car_id' => 5,
                'gid' => 30,
                'goods_num' => 2,
                'stockId' =>37
            ]
        ];
        echo json_encode($json);
    }
    public function demo()
    {
        $qiniu = new QinNiu();
        $token = $qiniu->get_upload_token();
        $file = $this->request->file('video');
        $fileName = $file->getInfo()['name'];
        $data = [
            'token' => $token,
            'file' => $file,
            'filename' => $fileName,
            'key' => $fileName
        ];
        $part = CurlUploadFile::getInstance()->putFile($data);
        dump($part);

//        $curl = curl_init();
//        curl_setopt_array($curl, array(
//            CURLOPT_URL => env('QINIU_UPLOAD_URL'),
//            CURLOPT_SSL_VERIFYPEER => false,
//            CURLOPT_SSL_VERIFYHOST => false,
//            CURLOPT_RETURNTRANSFER => true,
//            CURLOPT_ENCODING => "",
//            CURLOPT_MAXREDIRS => 10,
//            CURLOPT_TIMEOUT => 0,
//            CURLOPT_FOLLOWLOCATION => false,
//            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//            CURLOPT_CUSTOMREQUEST => "POST",
//            CURLOPT_POSTFIELDS => array('token' => $token,'file'=> $file,'fileName' => $fileName,'key' => $fileName),
//        ));
//        $response = curl_exec($curl);
//        $err = curl_error($curl);
//        curl_close($curl);
//        dump($err);
//        dump($response);


    }

    public function demo1()
    {
        $file = $this->request->file('video');
//        dump($file);
        $filePath = $file->getInfo()['tmp_name'];
        $fileName = $file->getInfo()['name'];
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        // 构建鉴权对象
        $auth = new Auth($accessKey, $secretKey);
        // 生成上传 Token
        $token = $auth->uploadToken($bucket);
        // 初始化 UploadManager 对象并进行文件的上传。
        $uploadMgr = new UploadManager();
        // 调用 UploadManager 的 putFile 方法进行文件的上传。
        list($ret, $err) = $uploadMgr->putFile($token, $fileName, $filePath);
        echo "\n====> putFile result: \n";
        if ($err !== null) {
            var_dump($err);
        } else {
            var_dump($ret);
        }
    }
}
