<?php

namespace app\test\controller;

use app\api\controller\BaseController;
use app\test\model\Auth;
use function Complex\add;
use think\Controller;
use think\Db;
use think\Request;

class DataController extends BaseController
{
    protected $exceptAuthActions = ['makedata', 'vipdata'];
    /**
     * vip充值所需积分配置写入
     */
    public function vipData()
    {
        $data = [
            [
                'key' => 'monthCard',
                'operate' => '月卡充值所需积分',
                'integ_num' => 1000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ],
            [
                'key' => 'seasonCard',
                'operate' => '季卡卡充值所需积分',
                'integ_num' => 4000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ],
            [
                'key' => 'yearCard',
                'operate' => '年卡充值所需积分',
                'integ_num' => 10000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ]
        ];
        Db::table('td_integ_config')->insertAll($data);
        echo 'done';
    }
    /**
     * 创建权限管理表 td_auth表数据
     */
    public function makeData()
    {
        $auth = new Auth();
        //auth_type 为1 游客身份 未填写手机号
        $arr = [
            0, 0, 0,
            0, 0, 0,
            1, 1, 0,
            1, 1, 0, 0, 0, 0
        ];
        $add = self::template(1, $arr);
        $res = $auth->saveAll($add);
        unset($add);

        $arr = [
            0, 0, 0,
            0, 0, 0,
            1, 1, 0,
            1, 1, 1, 1, 1, 1
        ];
        $add = self::template(2, $arr);
        $auth->saveAll($add);
        unset($add);
        unset($arr);

        $arr = [
            0, 0, 0,
            0, 0, 0,
            1, 1, 1,
            1, 1, 1, 1, 1, 1
        ];
        $add = self::template(3, $arr);
        $auth->saveAll($add);
        unset($add);
        unset($arr);

        $arr = [
            1, 1, 1,
            0, 0, 0,
            1, 1, 1,
            1, 1, 1, 1, 1, 1
        ];
        $add = self::template(4, $arr);
        $auth->saveAll($add);
        unset($add);
        unset($arr);

        $arr = [
            0, 0, 0,
            1, 1, 1,
            1, 1, 1,
            1, 1, 1, 1, 1, 1
        ];
        $add = self::template(5, $arr);
        $auth->saveAll($add);
        unset($add);
        unset($arr);

        $arr = [
            1, 1, 1,
            1, 1, 1,
            1, 1, 1,
            1, 1, 1, 1, 1, 1
        ];
        $add = self::template(5, $arr);
        $auth->saveAll($add);
        unset($add);
        unset($arr);
        echo 'done';
    }

    /**
     * @param $auth_type 角色类型 取值 1到6
     * @param array $auth 由0和1组成长度为15 的数组
     */
    public static function template($auth_type,array $auth)
    {
        $add_temp = [
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zhome',
                'action' => 'submitSolution',
                'description' => '提交作业',
                'auth' => $auth['0']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zhome',
                'action' => 'forwarding',
                'description' => '发布作业',
                'auth' => $auth['1']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zhome',
                'action' => 'remarkOnSolutionId',
                'description' => '点评作业',
                'auth' => $auth['2']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Ztrain',
                'action' => 'trainList',
                'description' => '查看培训文章列表',
                'auth' => $auth['3']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Ztrain',
                'action' => 'trainDetail',
                'description' => '查看培训文章详情',
                'auth' => $auth['4']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Ztrain',
                'action' => 'addComment',
                'description' => '添加培训文章评论',
                'auth' => $auth['5']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zinformation',
                'action' => 'infoList',
                'description' => '资讯文章列表',
                'auth' => $auth['6']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zinformation',
                'action' => 'infoDetail',
                'description' => '资讯文章详情',
                'auth' => $auth['7']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zinformation',
                'action' => 'addComment',
                'description' => '添加资讯文章评论',
                'auth' => $auth['8']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'goodsList',
                'description' => '商品列表',
                'auth' => $auth['9']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'goodsDetail',
                'description' => '商品详情',
                'auth' => $auth['10']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'buyNow',
                'description' => '立即购买',
                'auth' => $auth['11']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'AttentionGoods',
                'description' => '关注商品',
                'auth' => $auth['12']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'addCar',
                'description' => '添加到购物车',
                'auth' => $auth['13']
            ],
            [
                'auth_type' => $auth_type,
                'module' => 'api',
                'controller' => 'Zmall',
                'action' => 'shoppingCarList',
                'description' => '查看购物车列表',
                'auth' => $auth['14']
            ]
        ];
        return $add_temp;
    }
}
