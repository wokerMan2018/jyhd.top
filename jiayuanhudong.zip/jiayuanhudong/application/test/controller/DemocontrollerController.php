<?php

namespace app\test\controller;

use app\admin\model\Article;
use app\admin\model\User;
use app\api\controller\BaseController;
use app\facade\Jwt;
use Hashids\Hashids;
use think\Controller;
use think\Db;
//use think\Request;
use DfaFilter\SensitiveHelper;
use helper\filter\Filter;
use think\facade\Cache;
use think\facade\Request;

class DemocontrollerController extends BaseController
{
    use Filter;
    const USER_HIDDEN_FIELDS = ['password', 'withdraw_pwd', 'wx_openid', 'delete_time'];
    protected $exceptAuthActions = ['create','test', 'makedata','createdata'];
    /**
     * hashids 编码
     */
    public static function encode($id)
    {
        $hashids = new Hashids('td',6);
//        $code = $hashids->encode($id);
        $code = $hashids->encode($id);
        return $code;
    }
    /**
     * 测试token
     */
    public function test()
    {
        $user = User::get('43');
        $token = $this->handlerUserLogin($user);
        $user->hidden(self::USER_HIDDEN_FIELDS)->toArray();
        $response = [
            'token' => $token,
            'user' => $user
        ];
        return $this->jsonResult(true, $response, '', '2000');
    }
    /**
     * hashids 解码
     */
    public static function decode($code)
    {
        $hashids = new Hashids('td', 6);
        $inviteID = $hashids->decode($code);
        if (!$inviteID) {
            return [];
        }
        return $inviteID;

    }

    public function hashids()
    {
        $code = self::encode('23');
        echo $code;
    }
    public function hashidsdecode()
    {
        $code = self::decode('ZWx0WP');
        halt($code);
    }
    public function demo()
    {

        $content = '操，机构开草发的结果看到    you！ 激情';
        // 获取感词库文件路径
        $path = './../vendor/lustre/php-dfa-sensitive/tests/data/words2.txt';
//        $myfile = fopen($path, "r") or die("Unable to open file!");
//        echo fread($myfile,filesize($path));
//        fclose($myfile);
//        die;

//        $wordFilePath = 'tests/data/words.txt';
        $wordFilePath = $path;
        // get one helper
        $handle = SensitiveHelper::init()->setTreeByFile($wordFilePath);
        // 敏感词替换为*为例（会替换为相同字符长度的*）
        $filterContent = $handle->replace($content, '*', true);
        //标记敏感词
//        $markedContent = $handle->mark($content, '<mark>', '</mark>');
        echo $filterContent;
    }

    public function demo1()
    {
        $content = '操，机构开草发的结果看到  fuck fuck you！ 激情';
        echo self::sudo($content);

    }

    public function deluser()
    {
        //字符串where写法
//        $users=  User::where('id','neq',1)->field('id')->select();
        //数组where写法
//        $where['id'] = array('gt', 1,);//TP32d的map写法
        $where[] = ['id','neq',1];//TP51的map写法或下面的写法
//        $where = [
//            ['id','neq',1]
//        ];
//        $users=  User::where($where)->field('*')->select();
//        开启事务
        Db::startTrans();
        try{
            //闭包查询例子
//            withTrashed函数查询出软删除标记的记录
            $users = User::all(function ($query) {
                $query->where('id','neq',1);
            });
            foreach ($users as $value){
                // 软删除
//                User::destroy($value['id']);
                // 真实删除
                User::destroy($value['id'],true);
            }
            // 提交事务
            Db::commit();
        } catch (\Exception $e) {
            echo $e->getMessage();
            // 回滚事务
            Db::rollback();
        }
        dump($users);
    }

    public function change()
    {
        $all = Db::name('merchants')->select();
        foreach ($all as $value){
            Db::name('merchants')->where(['id'=>$value['id']])->update(['type'=>1]);
        }
    }

    /**
     *创建测试用户
     */
    public function addPerson()
    {
        $user = User::create([
            'u_type'=>5,
            'username'=>'学生1',
            'password'=>User::genPassword('123456'),
            'nickname'=>'学生1',
            'photo_url'=>'https://gss1.bdstatic.com/-vo3dSag_xI4khGkpoWK1HF6hhy/baike/s%3D220/sign=571122a7b07eca8016053ee5a1229712/8d5494eef01f3a29c8f5514a9925bc315c607c71.jpg',
            'gender'=>1,
            'regi_code'=>13115501,
            'phone'=>'18871467915',
            'last_login_ip'=>ip2long(\think\facade\Request::ip()),
            'last_login_time'=>date('Y-m-d H:i:s',time()),
            'enable'=>1,
            'wx_openid'=>'111141dd1111311'
        ]);
    }

    /**
     * 生成测试用户登录token
     */
    public function getToken()
    {
        $id = Request::param('id');
        $user  = User::get($id);
        if ($user){
            $token = Jwt::login($user,'','',$auto = true);
            self::ReturnAjax(2000,'',$token);
        }
    }

    /**
     * 清除token
     */
    public function rmToken()
    {
        Cache::rm(Request::param('token'));
    }

    public function code()
    {
        $id = 132;
        $token = encrypt($id, 'E', 'a');
        echo '加密:'.encrypt($id, 'E', 'a');
        echo '
';
        echo '解密：'.encrypt($token, 'D', 'a');
    }

    /**
     * 生成文章类型数据 存入数据库中
     */
    public function insertData()
    {
        $row = [
            1,2,3
        ];
        $col = [
            1,2
        ];
        foreach ($col as $value){
            foreach ($row as $vvalue){
                Db::name('article_type')->insert(['push_plate'=>$value,'push_person'=>$vvalue]);
            }
        }
    }
    /**
     * 创建批量文章表数据
     */
    public function createData()
    {
        $articles = Article::where('uid', '张老师')
            ->hidden(['id'])
            ->select()->toArray();

        $res = Db::name('article')->insertAll($articles);
        if ($res) {
            self::ReturnAjax(2000, 'ok');
        }

    }
    /**
     * 生成通知消息类型表数据
     */
    public function makeData()
    {
        $add = [
            [
                'type' => 1,
                'typename' => '购买成功'
            ],
            [
                'type' => 2,
                'typename' => '商品已发货'
            ],
            [
                'type' => 3,
                'typename' => '作业通知'
            ],
            [
                'type' => 4,
                'typename' => '留言通知'
            ]
        ];
        $res = Db::name('notice_type')
            ->insertAll($add);
        //返回记录数
        self::ReturnAjax(2000, '', $res);
    }
    /**
     * 新建数据
     */
    public function create()
    {
        $add = [
            'uid' => 43,
            'operation' => '购买商品',
            'number' => -50,
            'create_time' => date('Y-m-d H:i:s', time()),
            'update_time' => date('Y-m-d H:i:s', time()),
        ];
        Db::name('integ_log')
            ->insertGetId($add);
    }
}
