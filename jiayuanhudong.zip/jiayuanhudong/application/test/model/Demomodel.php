<?php

namespace app\test\model;

use think\Model;

class Demomodel extends Model
{
    protected $name='tablename';
    protected $pk = 'id';
    protected $autoWriteTimestamp = 'datetime';
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $auto = [];
    protected $insert = ['create_time',];
    protected $update = ['update_time'];
    //修改器举例
    public function setPasswordAttr($value)
    {
        return password_hash($value, PASSWORD_BCRYPT);
    }
    //获取器举例
    public function getImgAttr($v){
        if(empty($v)){
            return $v;
        }
        return url($v,'',false,true);
    }
}
