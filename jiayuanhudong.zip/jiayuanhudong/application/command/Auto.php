<?php

namespace app\command;

use app\api\model\Order;
use app\api\model\OrderGoods;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;
use think\exception\DbException;

class Auto extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('auto');
        // 设置描述
        $this->setDescription('24小时订单未支付自动失效 - 定时任务');
        
    }

    protected function execute(Input $input, Output $output)
    {
        while (true) {
            // 查询当前时间前两天没有支付的订单数据
            $orders = Order::where('create_time', 'between', [date('Y-m-d H:i:s', strtotime('-2 day')), date('Y-m-d H:i:s', time())])
                ->where('order_status', 10)
                ->field('id,order_status, expiration_time')
                ->select();
            if (!$orders->isEmpty()) {
                Db::startTrans();
                try {
                    foreach ($orders as $key => $order) {
                        if (strtotime($order->expiration_time) < time()) {
                            //当前时间大于过期时间
                            $order->order_status = 0;
                            $order->delete_time = date('Y-m-d H:i:s', time());
                            $order->save();
                            $order_goods = OrderGoods::destroy(function ($query) use ($order) {
                                $query->where('oid', $order->id);
                            });
                        }
                    }
                    Db::commit();
                } catch (DbException $e) {
                    Db::rollback();
                    return $this->jsonFailed('server error', '2001');
                }
            }
            sleep(60 * 10);
        }
    }
}
