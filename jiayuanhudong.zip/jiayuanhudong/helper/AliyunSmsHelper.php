<?php

namespace helper;
/**
 * aliyun短信发送，配置在.env文件中
 * Class AliyunSmsHelper
 */
class AliyunSmsHelper {

    /**
     * @param $mobile string 手机号
     * @param $code string 验证码
     * @param $templateCode string 阿里云短信模版编号
     * @return bool|\stdClass
     */
    public static function sendSms($mobile, $code, $templateCode=null){
        if(empty($templateCode)) {
            $templateCode = env('ALIYUN_SMS_TEMPLATE_CODE');
        }
        $params = array ();
        $accessKeyId = env('ALIYUN_SMS_KEY');
        $accessKeySecret =  env('ALIYUN_SMS_KEY_SECRET');
        $params["PhoneNumbers"] = $mobile;
        $params["SignName"] = env('ALIYUN_SMS_SIGN');
        $params["TemplateCode"] = $templateCode;
        $params['TemplateParam'] = Array (
            "code" => $code,
            "product" => $code
        );
        $params['OutId'] = "12345";
        $params['SmsUpExtendCode'] = "1234567";
        if(!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {
            $params["TemplateParam"] = json_encode($params["TemplateParam"], JSON_UNESCAPED_UNICODE);
        }
        $helper = new AliyunSignatureHelper();
        $content = $helper->request(
            $accessKeyId,
            $accessKeySecret,
            "dysmsapi.aliyuncs.com",
            array_merge($params, array(
                "RegionId" => "cn-hangzhou",
                "Action" => "SendSms",
                "Version" => "2017-05-25",
            ))
        );
        return $content;
    }
}