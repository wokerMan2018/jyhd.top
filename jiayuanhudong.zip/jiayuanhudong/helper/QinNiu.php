<?php
/**
 * Created by PhpStorm.
 * User: EDZ
 * Date: 2018/11/30
 * Time: 16:14
 */

namespace helper;


use Qiniu\Auth;
use Qiniu\Storage\BucketManager;
use Qiniu\Storage\UploadManager;
use think\Request;
use think\Validate;
use think\facade\Cache;
use think\Db;
use think\facade\Log;
use Qiniu\Config;
class QinNiu
{
    const PAGE_SEIZ = 1000;
    //服务器获取凭证
    public static function set_auth(){
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $result = [];

        $auth = new Auth($accessKey,$secretKey);
        $policy['callbackBodyType'] = 'application/json';
        $callbackBody = ['fname'=>'$(fname)',"fkey"=>"$(key)"];

        $policy['callbackBody'] =json_encode($callbackBody);;
        $policy['fsizeLimit'] = 3097152;
        $expires = 3600*2;
        $upToken = $auth->uploadToken($bucket,null,$expires,$policy);
        $result = $upToken;

        return $result;

//        $bucket = env('QINIU_BUCKET_NAME');
//        $accessKey = env('QINIU_ACCESS_KEY');
//        $secretKey = env('QINIU_SECRET_KEY');
//        $result = [];
//
//        $auth = new Auth($accessKey,$secretKey);
//        $policy['callbackUrl'] = 'http://ykcc.tudingsoft.com/api/index/save_img';
//        $policy['callbackBodyType'] = 'application/json';
//        $callbackBody = ['fname'=>'$(fname)',"fkey"=>"$(key)"];
//        $policy['callbackBody'] =json_encode($callbackBody);;
//        $policy['fsizeLimit'] = 3097152;
//        $expires = 3600*6;
//        $upToken = $auth->uploadToken($bucket,null,$expires,$policy);
//        $result = $upToken;
    }

    /**
     * 返回无回调上传凭证
     * @return string 获取的上传凭证
     */
    public static function get_upload_token() {
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');

        $auth = new Auth($accessKey,$secretKey);
        $expires = 3600*6;
        $upToken = $auth->uploadToken($bucket,null,$expires, null);
        return $upToken;
    }

    /**
     * 返回覆盖上传的凭证
     */
    public static function getUploadToken($keyToOverwrite)
    {
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $expires = 3600*6;
        $auth = new Auth($accessKey,$secretKey);
        $upToken = $auth->uploadToken($bucket, $keyToOverwrite, $expires, null, true);
        return $upToken;
    }


    /**
     * 返回有回调的上传凭证
     * @param $hid
     * @param $uid
     * @return string
     */
    public static function getCallbackUploadToken($hid,$uid)
    {
        $policy = array(
            'callbackUrl' => 'http://jiayuanhudong.tudingsoft.com/api/Zhome/callback',
            'callbackBody' => '{"uid":'. $uid . ',"hid":'. $hid .',"key":"$(key)","hash":"$(etag)","fsize":$(fsize),"bucket":"$(bucket)","name":"$(x:name)"}',
            'callbackBodyType' => 'application/json'
        );
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');

        $auth = new Auth($accessKey,$secretKey);
        $expires = 3600*6;
        $upToken = $auth->uploadToken($bucket,null,$expires, $policy,true);
        return $upToken;
    }

    //接收回调
    public function qn_callback(Request $request){
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $bucket = env('QINIU_BUCKET_NAME');

        $callbackBody = file_get_contents('php://input');

        $body = json_decode($callbackBody, true);
        Log::record("回调获取的信息：".var_export($body,true));
        $type = $body['type'];
        $fkey = $body['fkey'];
        $uid = $body['uid'];
        $auth = new Auth($accessKey, $secretKey);
        //获取回调的body信息


        //回调的contentType
        $contentType = 'application/json';//与凭证设置对应
        //$contentType = 'application/x-www-form-urlencoded';
        //回调的签名信息，可以验证该回调是否来自七牛
        $authorization = $_SERVER['HTTP_AUTHORIZATION'];
        //七牛回调的url，
        $host = $this->request->host();
        $url = 'http://'.$host.'/api/Qin/qn_callback';
//        $url = 'http://zhenjindao.tudingsoft.com/api/Qin/qn_callback';
        $isQiniuCallback = $auth->verifyCallback($contentType, $authorization, $url, $callbackBody);
        header('Content-Type: application/json');
        if ($isQiniuCallback) {

            switch ($type){
                case 1:
                    //上传音乐封面

                    if(isset($body['hash_name'])){
                        $music = Db::table('td_music')
                            ->where('hash_name',$body['hash_name'])
                            ->where('uid',$uid)
                            ->find();
                        if($music){
                            $re = Db::table('td_music')
                                ->where('id',$music['id'])
                                ->setField('phode_addr',$fkey);
                        }else{
                            $re = 0;
                        }
                        if($re){
                            $result = ['success'=>true,'message'=>'音乐封面上传成功'];
                        }else{
                            $result = ['success'=>false,'message'=>'音乐封面上传失败'];
                        }
                    }
                    else{
                        $result = ['success'=>false,'message'=>'未找到已上传的指定音乐'];
                    }

                    break;
                case 2:
                    //上传音乐
                    $mtype = $body['mtype'];
                    $title = $body['title'];
                    $hash_name = $body['hash_name'];
                    $lengt = $body['lengt'];
                    $author = $body['author'];

                    if($mtype == 4){
//                        $music_type = Db::table('td_music_type')->where('title','我的')->find();
                        $user  = Db::table('td_user')->where('id',$uid)->find();
                        $insert_data = [
                            'uid'=>$uid,
                            'music_addr'=>$fkey,
                            'type_id'=>$mtype,
                            'music_title'=>$title,
                            'hash_name'=>$hash_name,
                            'phode_addr'=>$user['photo_fid'],
                            'lengt'=>$lengt,
                            'author'=>$author,
                            'vip_level'=>1,
                            'status'=>1,
                        ];

                    }else{
                        $insert_data = [
                            'uid'=>$uid,
                            'music_addr'=>$fkey,
                            'type_id'=>$mtype,
                            'music_title'=>$title,
                            'hash_name'=>$hash_name,
                            'phode_addr'=>'',
                            'lengt'=>$lengt,
                            'author'=>$author,
                            'status'=>1,
                        ];
                    }


                    $user_profile = Db::table('td_user_profile')->where('uid',$uid)->find();
                    if($user_profile['vip_level'] == 20){
                        $insert_data ['vip_level'] = 1;
                    }else{
                        $insert_data ['vip_level'] = 0;
                    }
                    $re = Db::table('td_music')->insertGetId($insert_data);

                    if($re){
                        $result = ['success'=>true,'data'=>$re,'message'=>'音乐上传成功'];
                    }else{
                        $result = ['success'=>false,'message'=>'音乐上传失败'];
                    }
                    break;
                case 3:
                    //上传视频封面
                    Log::record("视频封面取数据库对应存储字段：".$body['hash_name']);
                    if(isset($body['hash_name'])){
                        $video = Db::table('td_video')
                            ->where('hash_name',$body['hash_name'])
                            ->find();
                        Log::record("视频结果：".var_export($video,true));
                        if($video){
                            $re = Db::table('td_video')
                                ->where('id',$video['id'])
                                ->setField('phode_addr',$fkey);
                        }else{
                            $re = 0;
                        }
                        if($re){
                            $result = ['success'=>true,'message'=>'视频封面上传成功'];
                        }else{
                            $result = ['success'=>false,'message'=>'视频封面上传失败'];
                        }

                    }else{

                        $result = ['success'=>false,'message'=>'未找到已上传的指定视频'];
                    }

                    break;
                case 4:
                    //上传视频
                    // $mtype = $body['mtype'];//视频的分类

                    $title = $body['title'];
//                    $desc = $body['desc'];
                    $hash_name = $body['hash_name'];
                    $lengt = $body['lengt'];
                    $mid = $body['mid'];
                    $ftype = $body['ftype'];
                    $address = $body['address'];
                    $insert_data = [
                        'uid'=>$uid,//用户id
                        'video_addr'=>$fkey,//视频七牛文件名
                        //'tage_id'=>$mtype,//视频标签分类
                        // 'create_time'=>date('Y-m-d H:i:s',time()),//视频创建时间
                        'video_title'=>$title,
                        'hash_name'=> $hash_name,
                        'phode_addr'=>'',
                        'lengt'=>$lengt,
                        'mid'=>$mid,
                        'address'=>$address
                    ];
                    if($ftype == 1){
                        $insert_data['status'] = 0;
                    }else{
                        $insert_data['status'] = 2;
                    }
                    // 启动事务
                    Db::startTrans();
                    try {

                        // 判断该上传视频用户是否为推荐用户，如果是，推荐用户是否首次上传视频
                        $user = Db::table('td_user')->alias('td_u')
                            ->field('td_u.uid,td_u.id,td_u_p.receive_total,td_u_p.receive_count,td_u_p.balance')
                            ->leftJoin('td_user_profile td_u_p','td_u_p.uid=td_u.id')
                            ->where('td_u.id',$uid)->find();
//                        Log::record("回调获取的信息：".var_export($user,true));
                        $is_zc_jl = Db::table('td_config')->field('val')->where('key','IS_ZC_JL')->find();
                        Log::record("安卓拍摄：".var_export($is_zc_jl,true));
                        if($is_zc_jl['val'] == 1){
                            if($user['uid']){
                                $up_video = Db::table('td_video')->where('uid',$uid)->find();
//                                Log::record('up_video:'.var_export($up_video,true));
                                if(!$up_video){
                                    Log::record('up_video:没有视频');
                                    $zhuce_jl = Db::table('td_config')->field('val')->where('key','ZHUCE_JL')->find();
//                                    $jiangli = env('ZHUCE_JL');
                                    $jiangli = $zhuce_jl['val'];
                                    if($jiangli){
//                                Log::record('奖励数量:'.$jiangli);
                                        //收到的奖励总金额
                                        $my_receive_total = bcadd($user['receive_total'],$jiangli,2);
//                                Log::record('my_receive_total:'.$my_receive_total);
                                        //收到的奖励总数量
                                        $my_receive_count = $user['receive_count'] + 1;
//                                Log::record('my_receive_count:'.$my_receive_count);
                                        //账户余额
                                        $my_balance = bcadd($user['balance'],$jiangli,2);
//                                Log::record('my_balance:'.$my_balance);
                                        $re_update = Db::table('td_user_profile')
                                            ->where('uid',$uid)
                                            ->update(['receive_total'=>$my_receive_total,'receive_count'=>$my_receive_count,'balance'=>$my_balance,'update_time'=>date('Y-m-d H:i:s',time())]);
//                                Log::record('更新被邀请用户返回结果:'.$re_update);
                                        $tj_user = Db::table('td_user')->alias('td_u')
                                            ->field('td_u.uid,td_u.id,td_u_p.receive_total,td_u_p.receive_count,td_u_p.balance')
                                            ->leftJoin('td_user_profile td_u_p','td_u_p.uid=td_u.id')
                                            ->where('td_u.id',$user['uid'])->find();
//                                Log::record('获取推荐人信息:'.var_export($tj_user,true));
                                        $tj_receive_total = bcadd($tj_user['receive_total'],$jiangli,2);
//                                Log::record('获取推荐人tj_receive_total:'.$tj_receive_total);
                                        $tj_receive_count = $tj_user['receive_count'] + 1;
//                                Log::record('获取推荐人信息tj_receive_count:'.$tj_receive_count);
                                        $tj_balance = bcadd($tj_user['balance'],$jiangli,2);
//                                Log::record('获取推荐人信息tj_balance:'.$tj_balance);
                                        $re_tj = Db::table('td_user_profile')
                                            ->where('uid',$user['uid'])
                                            ->update(['receive_total'=>$tj_receive_total,'receive_count'=>$tj_receive_count,'balance'=>$tj_balance,'update_time'=>date('Y-m-d H:i:s',time())]);
//                                Log::record('更新邀请用户返回结果:'.$re_tj);
                                        //添加资金记录
                                        $balance_log = [
                                            ['uid'=>$uid,'amount'=>$jiangli,'balance'=>$my_balance,'change_type'=>30,'remarks'=>'被邀请用户首次拍摄视频'],
                                            ['uid'=>$user['uid'],'amount'=>$jiangli,'balance'=>$tj_balance,'change_type'=>30,'remarks'=>'邀请用户首次拍摄视频'],
                                        ];
//                                Log::record('添加数据:'.var_export($balance_log,true));
//                                $ree = Db::table('td_balance_log')->fetchSql()->insertAll($balance_log);
//                                Log::record('sql:'.$ree);
                                        $re_ss = Db::table('td_balance_log')->insertAll($balance_log);
                                        Log::record('添加资金日志:'.$re_ss);
                                    }
                                }
                            }
                        }


                        Log::record('开始增加视频:');
//                        Log::record('增加的视频数据:'.var_export($insert_data,true));
                        //增加一条视频
                        $re_v = Db::table('td_video')->insertGetId($insert_data);
                        Log::record('增加视频:'.$re_v);
                        //对应音乐添加一条点击数量
                        Db::table('td_music')->where('id',$mid)->setInc('click_music');
//                        Log::record('增加视频:'.$re_v);


                        // 提交事务
                        Db::commit();
                        $result = ['success'=>true,'message'=>'视频上传成功'];
                    }
                    catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        Log::record('错误****:'.var_export($e->getMessage(),true));
                        $result = ['success'=>false,'message'=>'视频上传失败'];
                    }
                    break;
                case 5:

                    // 启动事务
                    Db::startTrans();
                    try {
                        //用户上传图片
                        $re = Db::table('td_user')->where('id',$uid)->setField('photo_fid',$fkey);
                        $user = Db::table('td_user')->field('nickname,yun_id,yun_token')->where('id',$uid)->find();
                        if($body['utype']){
                            if($re){
                                $key_old = $body['u_photo'];
                                $auth = new Auth($accessKey, $secretKey);
                                $config = new \Qiniu\Config();
                                $bucketManager = new \Qiniu\Storage\BucketManager($auth, $config);
                                $err = $bucketManager->delete($bucket, $key_old);
                                Db::table('td_music')->where(['uid'=>$uid,'type_id'=>4])->setField('phode_addr',$fkey);
                                if ($err) {
                                    Log::record("删除七牛用户原来使用用户图像失败：".var_export($err,true));
                                }
                                //修改网易云保存的图像
                                $create_r1 = new YxUtils();//网易云信
                                $yun_img = 'http://'.env('QINIU_URL').'/'. $fkey;
//                                $re_yun = $create_r1->updateUinfo($user['yun_id'],$icon=$yun_img);
                                $re_yun = $create_r1->updateUinfo($user['yun_id'],$user['nickname'],$yun_img,'','','','','0','');
                                if($re_yun['code'] != 200){
                                    Log::record("用户修改图片，并更改网易云用户图像失败，返回信息：".var_export($re_yun,true));
                                }
                            }
                        }
                        // 提交事务
                        Db::commit();
                        $result = ['success'=>true,'message'=>'图像上传成功'];
                    }
                    catch (\Exception $e) {
                        // 回滚事务
                        Db::rollback();
                        $result = ['success'=>false,'message'=>'图像上传失败'];
                    }
                    break;
                default:
                    //return $this->jsonFailed('未知请求类型');
                    $result = ['success'=>false,'message'=>'未知上传类型'];
            }

        }
        else {
            http_response_code(500);
            $result = ['success'=>false,'message'=>'不是安全请求地址'];
        }


//        echo json_encode($result);
        return json($result);
    }

    //远程拉去文件
    /**
     * @param $img_url 远程图片地址
     * @param $uid 有用户使用用户ID 未登录随机数 为了区分文件名重复
     * @return array
     */
    public function remote_picture($img_url,$uid){
//        $img_url = 'http://thirdwx.qlogo.cn/mmopen/vi_32/icvN5ice7Ql0JeAALwdficlS3YCXByKekS8FIRfB1RicUJiaZej8WbkTfMVtpEibVhjlaeePak3zn7WwvVgGaF0HA2Kg/132';
//        $uid = 6;
        $time = time();
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $auth = new Auth($accessKey,$secretKey);
        $bucketMgr = new BucketManager($auth);
        $extension = pathinfo( parse_url( $img_url, PHP_URL_PATH ), PATHINFO_EXTENSION );
        if(!$extension){
            $extension = 'jpg';
        }
        list($ret,$err) = $bucketMgr->fetch($img_url,$bucket,$time.$uid.'.'.$extension);

        if ($err !== null) {
            Log::record('拉取第三方用户图片');
            //出现错误
            return [];
        } else {
            //正常
            return ['name'=>$time.$uid.'.'.$extension];
        }
    }

    //后台上传音乐（未使用）
    public function hou_up(Request $request){
        $post = $request->post();
        $rule = [
            'type|类型'  => 'require|number',

        ];
        $msg = [
            'type.require' => '未获取到请求类型',
            'type.number' => '请求的类型必须是数字',
        ];
        $validate = new Validate($rule,$msg);
        if (!$validate->check($post)) {
            return $this->jsonFailed($validate->getError());
        }

        $uid = $this->uid;
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $auth = new Auth($accessKey,$secretKey);

        $policy1['callbackBodyType'] = 'application/json';
        $hash_name = time().mt_rand(0,100).$uid;
        //上传音乐 mtype 是音乐的类型 20m以内
        $callbackBody_music = ['fname'=>'$(fname)',"fkey"=>"$(key)"];
        $policy1['callbackBody'] = json_encode($callbackBody_music);
        $policy1['fsizeLimit'] = 20485760;
        $policy1['hash_name'] = $hash_name;

        $callbackBody_fengmian = ['fname'=>'$(fname)',"fkey"=>"$(key)"];

        $policy2['callbackBodyType'] = 'application/json';
        $policy2['callbackBody'] =json_encode($callbackBody_fengmian);;
        $policy2['fsizeLimit'] = 3097152;

        $upToken_music = $auth->uploadToken($bucket,null,3600,$policy1);

        $upToken_fengmian = $auth->uploadToken($bucket,null,3600,$policy2);
        $re_data['success'] = true;
        $re_data['music'] = $upToken_music;
        $re_data['fengmian'] = $upToken_fengmian;
        if($upToken_music || $upToken_fengmian){
            $re = $this->jsonSuccess($re_data);
        }else{
            $re = $this->jsonFailed('获取上传凭证失败');
        }
        return $re;

    }

    //服务器上传图像
    public function hou_userimg(Request $request){
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $auth = new Auth($accessKey,$secretKey);
        $policy['callbackBodyType'] = 'application/json';
        $callbackBody = ['fname'=>'$(fname)',"fkey"=>"$(key)"];

        $policy['callbackBody'] =json_encode($callbackBody);;
        $policy['fsizeLimit'] = 3097152;
        $upToken = $auth->uploadToken($bucket,null,3600,$policy);
        $re_data['success'] = true;
        $re_data['upToken'] = $upToken;
        return json($re_data);
    }


    /**删除指定的文件,最大1000个(使用中lyh)
     * @param $photo_arr 包含文件名的数组
     * @return bool
     */
    public static function hou_del($photo_arr){
        if(count($photo_arr) > 1000){
            return false;
        }
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $bucket = env('QINIU_BUCKET_NAME');
        $auth = new Auth($accessKey, $secretKey);
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($auth, $config);
        foreach ($photo_arr as $v){
            $keys [] = $v;
        }

        $ops = $bucketManager->buildBatchDelete($bucket, $keys);
        list($ret, $err) = $bucketManager->batch($ops);
        if ($err) {
            $re = false;
            Log::record("后台删除返回错误：" . print_r($err, true));
        } else {
            $re = true;
        }
        return $re;
    }


    /**
     * 后台批量删除,最大1000个
     * @param $arr 保存的图片文件名，包含后缀
     * @return bool
     */
    public function del($arr){
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        $bucket = env('QINIU_BUCKET_NAME');
        $auth = new Auth($accessKey, $secretKey);
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($auth, $config);

        foreach ($arr as $v){
            $keys [] = $v;
        }

        $ops = $bucketManager->buildBatchDelete($bucket, $keys);
        list($ret, $err) = $bucketManager->batch($ops);
        if ($err) {
            $re = false;
            Log::record("后台删除返回错误：" . print_r($err, true));
        } else {
            $re = true;
        }
        return $re;
    }


    /**获取七牛上保存的图片最多每次1000个（未完成）
     * @param $page 显示的页数，每页显示PAGE_SIZE个
     * @return array 查询的图片名称
     */
    public function show_photo($page){
        $accessKey = getenv('QINIU_ACCESS_KEY');
        $secretKey = getenv('QINIU_SECRET_KEY');
        $bucket = getenv('QINIU_TEST_BUCKET');
        $auth = new Auth($accessKey, $secretKey);
        $bucketManager = new BucketManager($auth);
        // 要列取文件的公共前缀
        $prefix = '';
        // 上次列举返回的位置标记，作为本次列举的起点信息。
        $marker = '';
        // 本次列举的条目数
        $limit = 100;
        $delimiter = '/';
        // 列举文件
        list($ret, $err) = $bucketManager->listFiles($bucket, $prefix, $marker, $limit, $delimiter);
        if ($err !== null) {
            echo "\n====> list file err: \n";
            var_dump($err);
        } else {
            if (array_key_exists('marker', $ret)) {
                echo "Marker:" . $ret["marker"] . "\n";
            }
            echo "\nList Iterms====>\n";
            //var_dump($ret['items']);
        }
        $list = [];
        return $list;
    }


    /**批量上传二进制图片信息（未使用）
     * @param $data 二进制数据
     * @return bool|int 是否上传成功
     */
    public function uploads_rb($data){
        $bucket = env('QINIU_BUCKET_NAME');
        $accessKey = env('QINIU_ACCESS_KEY');
        $secretKey = env('QINIU_SECRET_KEY');
        // 构建鉴权对象
        $auth = new Auth($accessKey, $secretKey);
        // 生成上传 Token
        $token = $auth->uploadToken($bucket);

        $bin = fread($data, 2); //只读2字节
        $str_info  = @unpack("C2chars", $bin);
        $type_code = intval($str_info['chars1'].$str_info['chars2']);
        $file_type = '';
        switch ($type_code) {
            case 255216:
                $file_type = 'jpg';
                break;
            case 13780:
                $file_type = 'png';
                break;
            default:
               return 100;
        }

        // 上传到七牛后保存的文件名

        // 初始化 UploadManager 对象并进行文件的上传。
        $uploadMgr = new UploadManager();

        list($ret, $err) = $uploadMgr->put($token,time().'png',$data);
        if ($err) {
            Log::record("二进制流上传返回错误：" . print_r($err, true));
            return false;
        }
        return $ret;

    }





}