<?php
/**
 * Created by PhpStorm.
 * User: cheng
 * Date: 2018/11/5
 * Time: 11:09 PM
 */
namespace helper\framework;

use think\Db;
use think\db\Where;
use think\Model;

/**
 * 基于 left_id 和 right_id 的树模型
 * 对应的表需要有 n_left_id, n_right_id, n_depth, n_p_id 四个字段
 * Trait NestedSetModel
 */
trait NestedSetModel {
//    public $n_left_id = 'n_left_id';
//    public $n_right_id = 'n_right_id';
//    public $n_depth = 'n_depth';
//    public $n_parent_id = 'n_p_id';
//    public $n_pk = 'id';

    /**
     * 是否使用统一的表树
     * @var bool
     */
    public $useNestedTable = false;


    /**
     * 获取子节点，不包含孙节点
     * @param $cur_id int 节点id
     * @return mixed
     */
    public function children() {
        return self::withTrashed()->where('n_p_id', $this->id)->order('n_left_id')->select();
    }

    /**
     * 当前节点的所有后代元素
     * @param int $max_depth 最大深度(相对当前深度) 为0获取所有
     * @return mixed
     */
    public function descendants($max_depth=0) {
        $q = self::withTrashed()->where('n_left_id', '>', $this->n_left_id)->where('n_right_id', '<', $this->n_right_id);
        if($max_depth > 0) {
            $q = $q->where('n_depth', '<=', $max_depth + $this->n_depth);
        }
        return $q;
    }

    /**
     * 当前节点的祖先节点
     * @param $cur_id int
     * @return mixed
     */
    public function ancestors() {
        $q = self::withTrashed()->where('n_left_id', '<', $this->n_left_id)->where('n_right_id', '>', $this->n_right_id);
        return $q;
    }

    /**
     * 按区间获取
     */
    public function ancestorsRang($from, $to) {
        $q = self::withTrashed()->where('n_left_id', '<', $this->n_left_id)->where('n_right_id', '>', $this->n_right_id);
        $q = $q->where('n_depth', '<=', $this->n_depth - $from)->where('n_depth', '>=', $this->n_depth - $to);
        return $q;
    }

    /**
     * 是否有子节点
     * @return bool
     */
    public function hasChildren() {
        if($this->n_left_id === null) {
            return false;
        }
        return !($this->n_left_id == $this->n_right_id - 1);
    }

    /**
     * 设置当前节点为根节点
     * @param $cur_id
     * @return mixed
     * @throws \Exception
     */
    public static function makeRoot($cur_id) {
        $obj = self::where('id', $cur_id)->find();
        self::validateNode($obj);
        $obj->n_left_id = 1;
        $obj->n_right_id = 2;
        $obj->n_depth = 0;
        $obj->n_p_id = 0;
        $obj->save();
        return $obj;
    }

    /**
     * 当前节点增加子节点
     * @param int $cur_id
     * @param int $node_id
     */
    public static function addChild($cur_id, $node_id) {
        self::setIsolationLevel();
        self::validateNode($node_id);
        $obj = self::withTrashed()->where('id', $cur_id)->find();
        if(!$obj->hasChildren()) {
            // 没有子元素
            Db::transaction(function () use($obj, $node_id) {
                self::withTrashed()->where('n_right_id', '>', $obj->n_left_id)->setInc('n_right_id', 2);
                self::withTrashed()->where('n_left_id', '>', $obj->n_left_id)->setInc('n_left_id', 2);
                self::withTrashed()->where('id', $node_id)->update([
                    'n_left_id' => $obj->n_left_id + 1,
                    'n_right_id' => $obj->n_left_id + 2,
                    'n_p_id' => $obj->id,
                    'n_depth' => $obj->n_depth + 1
                ]);
            });
        }
        else {
            // 有子元素找到最后一个子节点
            $last_child = self::withTrashed()->where('n_right_id', $obj->n_right_id - 1)->find();
            self::addSibling($last_child->id, $node_id);
        }
        self::setIsolationLevel(true);
    }


    /**
     * 当前节点增加后增加同级节点
     * @param $cur_id
     * @param $node_id
     * @return mixed
     */
    public static function addSibling($cur_id, $node_id) {
        self::setIsolationLevel();
        Db::transaction(function () use($cur_id, $node_id){
            self::validateNode($node_id);
            $obj = self::withTrashed()->where('id', $cur_id)->find();
            self::withTrashed()->where('n_right_id', '>', $obj->n_right_id)->setInc('n_right_id', 2);
            self::withTrashed()->where('n_left_id', '>', $obj->n_right_id)->setInc('n_left_id', 2);
            return self::withTrashed()->where('id', $node_id)->update([
                'n_left_id' => $obj->n_right_id + 1,
                'n_right_id' => $obj->n_right_id + 2,
                'n_p_id' => $obj->n_p_id,
                'n_depth' => $obj->n_depth
            ]);
        });
        self::setIsolationLevel(true);
    }

    /**
     * 删除节点，子节点移动上移到当前节点同级
     * @param $cur_id int 节点id
     */
    public static function deleteNode($cur_id) {
        self::setIsolationLevel();
        Db::transaction(function () use($cur_id){
            $obj = self::where('id', $cur_id)->find();
//            var_dump($obj);
            // 更新depth和p_id
            self::where('n_p_id', $cur_id)->update(['n_p_id' => $obj->n_p_id]);
            self::where('n_left_id', '>', $obj->n_left_id)->where('n_right_id', '<', $obj->n_right_id)->setDec('n_depth');

            self::where('n_left_id', $obj->n_left_id)->delete();
            self::whereBetween('n_left_id', [$obj->n_left_id, $obj->n_right_id])->setDec('n_right_id');
            self::whereBetween('n_left_id', [$obj->n_left_id, $obj->n_right_id])->setDec('n_left_id');
            self::where('n_right_id', '>', $obj->n_right_id)->setDec('n_right_id', 2);
            self::where('n_left_id', '>', $obj->n_right_id)->setDec('n_left_id', 2);

        });
        self::setIsolationLevel(true);
    }

    /**
     * 删除节点及子孙节点，
     * @param $cur_id int 节点ip
     */
    public static function deleteNodeTree($cur_id) {
        self::setIsolationLevel();
        Db::transaction(function () use($cur_id) {
            $obj = self::where('id', $cur_id)->find();
            $node_width = $obj->n_right_id - $obj->n_left_id + 1;
            self::whereBetween('n_left_id', [$obj->n_left_id, $obj->n_right_id])->delete();
            self::where('n_right_id', '>', $obj->n_right_id)->setDec('n_right_id', $node_width);
            self::where('n_left_id', '>', $obj->n_right_id)->setDec('n_left_id', $node_width);
        });
        self::setIsolationLevel(true);
    }


    /**
     * 验证node
     * @param int|Model $node
     * @throws \Exception
     */
    private static function validateNode($node) {
        if(is_numeric($node)) {
            $node = self::withTrashed()->where('id', $node)->find();
        }
        if($node->n_left_id !== null && $node->n_right_id !== null) {
            exception('已初始化的节点不能添加到树中');
        }
    }

    /**
     * 当前节点前增加同级节点
     */
    public static function addSiblingBefore() {
        exception('未实现');
    }

    /**
     * 修改数据库隔离级别
     * @param bool $default
     */
    private static function setIsolationLevel($default=false) {
        if($default) {
            Db::execute('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
        }
        else {
            Db::execute('SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE');
        }
    }


    /**
     * 增加 NestedSet 相关的字段 n_left_id, n_right_id, n_depth, n_p_id
     * @param $table string 表名
     */
    public static function addNestedSetFields($table) {
        $sql = "alter table $table add ( " .
            "n_left_id integer null COMMENT '根节点为1'," .
            "n_right_id integer null COMMENT '根节点为2', " .
            "n_depth integer null COMMENT '根节点为0', " .
            "n_p_id integer null COMMENT '根节点为0'" .
            ");";
        db()->execute($sql);
        $sql = "alter table $table add index index_n_left_id(n_left_id);";
        db()->execute($sql);
        $sql = "alter table $table add index index_n_right_id(n_right_id);";
        db()->execute($sql);
        $sql = "alter table $table add index index_n_p_id(n_p_id);";
        db()->execute($sql);
    }
}