<?php
namespace helper\framework;

trait ModelHelper {

    public static $EXCEPT_PARAMS = ['jwt_payload', 'TD_PAGE', ];

    /**
     * 分页查询条件
     * @return mixed
     */
    public function paginateParams() {
        return request()->except(self::$EXCEPT_PARAMS);
    }

    /**
     * 关联查询，转化为n+1查询， 如查询用户信息:
     *    selectRelated($dataList, db('User'), $on=['uid', 'id'], $field="id as uid, username")
     * @param $dataList array|\think\Collection
     * @param $model \think\db\Query
     * @param $on array 连接字段
     * @param $field string 表2字段名
     * @return array
     */
    public static function selectRelated($dataList, $model, $on, $field) {

        if(!count($dataList)) {
            return $dataList;
        }

        $field_value = array();

        foreach ($dataList as $k => $item) {
            if(!in_array($item[$on[0]], $field_value)) {
                $field_value[] = $item[$on[0]];
            }
        }
        $data_map = [];

        if(!empty($field_value)) {
            // 查询关联的数据
            $related_result = $model->where($on[1], 'in', $field_value)->field($on[1])->field($field)
                ->fetchCollection()->select();
            $related_result->each(function($item) use ($on, &$data_map) {
                $data_map[$item[$on[1]]] = $item;
            });
        }

        $related_fields = array_map(function($item){
            $field_info = preg_split('/\s+AS\s+/i', trim($item));
            return array_pop($field_info);
        }, explode(',', $field));

        foreach ($dataList as $k => &$item) {
            $key = $item[$on[0]];
            if(array_key_exists($key, $data_map)) {
                foreach ($related_fields as $r_k => $r_field) {
                    $item[$r_field] = $data_map[$key][$r_field];
                }
            }
            else {
                // 关联表没有数据，默认为null
                array_map(function($f) use(&$item) {
                    $item[$f] = null;
                }, $related_fields);
            }
        }
        unset($item);

        return $dataList;

    }

}