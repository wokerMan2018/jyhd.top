<?php
namespace helper\framework;

class ExceptionHandler {
    
}