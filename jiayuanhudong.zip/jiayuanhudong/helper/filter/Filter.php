<?php


namespace helper\filter;
use DfaFilter\SensitiveHelper;

trait Filter{
    /**
     * 评论脱敏操作
     * @purpose
     * @access
     * @param
     * @return
     * @author drzhong2015@gmail.com
     * @date 2019/5/21
     */
    public function sudo($content)
    {
        $path = './../vendor/lustre/php-dfa-sensitive/tests/data/words2.txt';
        $handle = SensitiveHelper::init()->setTreeByFile($path);
        // 敏感词替换为*为例（会替换为相同字符长度的*）
        $filterContent = $handle->replace($content, '*', true);
        //标记敏感词
//        $markedContent = $handle->mark($content, '<mark>', '</mark>');
        return $filterContent;
    }

}