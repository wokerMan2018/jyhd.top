<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// +----------------------------------------------------------------------
// | Trace设置 开启 app_trace 后 有效
// +----------------------------------------------------------------------
return [
    // 内置Html Console 支持扩展
    // 'appId' 		=> '8aaf0708639129c4016391df875f00db',
    // 'accountSid' 	=> '8aaf0708639129c4016391df870e00d5',
    // 'accountToken' 	=> 'd6a993bab3844aa5b520311acd22e57e',

    // 'serverIP' 		=> 'sandboxapp.cloopen.com',//sandboxapp.cloopen.com
    // 'softVersion' 	=> '2013-12-26',
    // 'serverPort' 	=> '8883',
    // 'tempId' 		=> '1', //模板id
    // 'expireTime' 	=> '3' //3分钟内有效
    // 
    // 
    'appId' 		=> '8aaf070865310d1f016537f31fd7056f',
    'accountSid' 	=> '8aaf0708639129c4016391df870e00d5',
    'accountToken' 	=> 'd6a993bab3844aa5b520311acd22e57e',

    'serverIP' 		=> 'app.cloopen.com',//sandboxapp.cloopen.com
    'softVersion' 	=> '2013-12-26',
    'serverPort' 	=> '8883',
    'tempId' 		=> '316742', //模板id
    'expireTime' 	=> '3' //3分钟内有效
];
