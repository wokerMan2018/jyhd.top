<?php
return [
    'wx_config' => [
        //'appid' => 'wxdf54a37e9ddb4ce8',
        //'secret' => '9b8a429f5fcb5aa77e64e53e499ff1be',


        'appid' => 'wxdc13494b3c2a01e1',/*公众号appid*/
        'secret' => '9a58f42bf12eee9b4c879057fc2d47f7',/*开发者密码*/
        'mch_id'  =>'1538040681',
        'key'=>'PzOzgu996x5Sm4IE08VQmYDjwzf7N2yE',
    ]
];