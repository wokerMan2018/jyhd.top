<?php
return [
    'key'=>'jfdksajfkl;dsajfkdjsaklfdajffdsafdsfdsfdsfdsklfdsafdsafdsafdsdsajlkfdsa',
    'type'=> array('HS256'),
];