<?php

return [
    'tpl_replace_string'  =>  [
        '__STATIC__' => '/static/portal',
        '__COMMON__' => '/static/common'
    ]
];

