<?php

return [
    'tpl_replace_string'  =>  [
        '__STATIC__' => '/static/admin',
        '__COMMON__' => '/static/common'
    ]
];

