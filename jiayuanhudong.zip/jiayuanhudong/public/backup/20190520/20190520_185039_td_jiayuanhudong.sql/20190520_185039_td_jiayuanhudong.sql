-- Created at 20.5.2019 18:50 using David Grudl MySQL Dump Utility
-- Host: jyhd.top
-- MySQL Server: 5.7.21
-- Database: td_jiayuanhudong

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_balance_log`;

CREATE TABLE `td_balance_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `amount` decimal(10,0) NOT NULL COMMENT '变动金额，增加为正数，减少为负数',
  `balance` decimal(10,0) NOT NULL COMMENT '变动后金额',
  `change_type` int(11) NOT NULL COMMENT '变动类型,10:充值,20:提现',
  `change_id` int(11) DEFAULT NULL COMMENT '变动关联id',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账户变动表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_config`;

CREATE TABLE `td_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL COMMENT '键',
  `val` varchar(4000) NOT NULL COMMENT '值',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `grouping` varchar(128) DEFAULT NULL COMMENT '分组',
  `remark` varchar(256) DEFAULT NULL COMMENT '说明',
  `format` varchar(256) NOT NULL DEFAULT 'string' COMMENT '数据格式|验证正则: int,float,string,datetime',
  `help_text` varchar(512) DEFAULT NULL COMMENT '字段说明',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='配置';

INSERT INTO `td_config` (`id`, `key`, `val`, `sorting`, `grouping`, `remark`, `format`, `help_text`, `delete_time`, `create_time`, `update_time`) VALUES
(1,	'admin_site_name',	'后台管理系统',	100,	'admin',	NULL,	'string',	NULL,	NULL,	'2019-05-20 18:30:30',	'2019-05-20 18:30:30'),
(2,	'admin_copyright',	'武汉图叮科技',	100,	'admin',	NULL,	'string',	NULL,	NULL,	'2019-05-20 18:30:30',	'2019-05-20 18:30:30');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_file`;

CREATE TABLE `td_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL COMMENT '显示名称',
  `file_name` varchar(256) NOT NULL COMMENT '文件名，包含后缀',
  `file_ext` varchar(64) DEFAULT NULL COMMENT '文件后缀',
  `file_path` varchar(512) DEFAULT NULL COMMENT '文件相对url路径',
  `file_size` int(11) NOT NULL COMMENT '文件大小',
  `category` varchar(64) NOT NULL DEFAULT 'default' COMMENT '文件分类',
  `upload_by` int(11) DEFAULT NULL COMMENT '上传用户uid',
  `sha1` varchar(64) DEFAULT NULL COMMENT 'sha1值',
  `is_public` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否能公开访问',
  `ext_url` varchar(512) DEFAULT NULL COMMENT 'mime类型',
  `mime_type` varchar(64) NOT NULL COMMENT 'mime类型',
  `media_type` varchar(64) NOT NULL DEFAULT 'file' COMMENT '文件类型,video,image,txt,file',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1` (`sha1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_menu`;

CREATE TABLE `td_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '上级id',
  `is_leaf` int(11) NOT NULL DEFAULT '1' COMMENT '是否叶子节点',
  `module` varchar(64) DEFAULT NULL COMMENT '所属应用',
  `controller` varchar(64) DEFAULT NULL COMMENT '控制器',
  `action` varchar(64) DEFAULT NULL COMMENT '方法',
  `params` varchar(256) DEFAULT NULL COMMENT '参数',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `icon` varchar(32) DEFAULT 'fa fa-circle-o' COMMENT 'icon class',
  `type` varchar(32) NOT NULL DEFAULT 'action' COMMENT '链接类型:action, page, ext_url',
  `ext_url` varchar(256) DEFAULT NULL COMMENT '外部链接地址',
  `target` varchar(32) DEFAULT NULL COMMENT '打开方式',
  `enable` int(11) NOT NULL DEFAULT '1' COMMENT '是否可见',
  `grouping` varchar(32) DEFAULT NULL COMMENT '分组',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单';

INSERT INTO `td_menu` (`id`, `pid`, `is_leaf`, `module`, `controller`, `action`, `params`, `title`, `icon`, `type`, `ext_url`, `target`, `enable`, `grouping`, `sorting`, `delete_time`, `create_time`, `update_time`) VALUES
(1,	NULL,	0,	'',	'',	'',	NULL,	'用户管理',	'fa fa-user',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(2,	1,	1,	'admin',	'user',	'index',	NULL,	'用户列表',	'fa fa-table',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(3,	NULL,	0,	'',	'',	'',	NULL,	'系统设置',	'fa fa-gear',	'action',	NULL,	NULL,	1,	'admin',	999,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(4,	3,	1,	'td',	'config',	'index',	NULL,	'站点设置',	'fa fa-circle-o',	'action',	NULL,	NULL,	1,	'admin',	999,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(5,	3,	1,	'td',	'menu',	'index',	NULL,	'菜单设置',	'fa fa-th-list',	'action',	NULL,	NULL,	1,	'admin',	10,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(6,	3,	1,	'td',	'user',	'index',	NULL,	'后台用户',	'fa fa-address-book',	'action',	NULL,	NULL,	1,	'admin',	20,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(7,	3,	1,	'td',	'role',	'index',	NULL,	'角色管理',	'fa fa-users',	'action',	NULL,	NULL,	1,	'admin',	30,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_migrations`;

CREATE TABLE `td_migrations` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `td_migrations` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20180520102725,	'User',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134217,	'Config',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134221,	'Menu',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134226,	'Role',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520140029,	'UserRole',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520140039,	'RoleMenu',	'2019-05-20 18:30:22',	'2019-05-20 18:30:23',	0),
(20180520172046,	'Page',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180520172050,	'File',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180612111143,	'BalanceLog',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180919055141,	'UserToken',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_page`;

CREATE TABLE `td_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL COMMENT '标题',
  `photo_id` int(11) DEFAULT NULL COMMENT '封面照片id',
  `link_name` text NOT NULL COMMENT '链接名称',
  `content` text NOT NULL COMMENT '内容',
  `slug` varchar(128) DEFAULT NULL COMMENT '短连接, 唯一',
  `grouping` varchar(32) DEFAULT NULL COMMENT '分组',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='页面表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_role`;

CREATE TABLE `td_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL COMMENT '权限代码',
  `name` varchar(32) NOT NULL COMMENT '权限名称',
  `home_page` varchar(32) DEFAULT NULL COMMENT '角色首页',
  `is_sys` int(11) NOT NULL DEFAULT '1' COMMENT '是否系统内置(系统内置1不能删除)',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='角色';

INSERT INTO `td_role` (`id`, `code`, `name`, `home_page`, `is_sys`, `sorting`) VALUES
(1,	'admin',	'管理员',	'admin/user/index',	1,	100);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_role_menu`;

CREATE TABLE `td_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `menu_id` int(11) NOT NULL COMMENT '菜单id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色菜单对应表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user`;

CREATE TABLE `td_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `password` varchar(256) NOT NULL COMMENT '用户密码',
  `withdraw_pwd` varchar(256) DEFAULT NULL COMMENT '提现密码',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `photo_fid` int(11) DEFAULT NULL COMMENT '头像文件id',
  `photo_url` varchar(256) DEFAULT NULL COMMENT '头像文件url',
  `tel` varchar(64) DEFAULT NULL COMMENT '电话号码',
  `is_staff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否后台用户',
  `wx_openid` varchar(128) DEFAULT NULL COMMENT '微信open id',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `gender` int(11) DEFAULT NULL COMMENT '性别1:男,2:女',
  `bio` varchar(2000) DEFAULT NULL COMMENT '个人签名',
  `qrcode_url` int(11) DEFAULT NULL COMMENT '二维码地址',
  `province` int(11) DEFAULT NULL COMMENT '省代码',
  `city` int(11) DEFAULT NULL COMMENT '市代码',
  `county` int(11) DEFAULT NULL COMMENT '区代码',
  `last_login_ip` bigint(20) DEFAULT NULL COMMENT '最后登录IP',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `enable` int(11) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `ext` json DEFAULT NULL COMMENT '存储json数据',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `wx_openid` (`wx_openid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO `td_user` (`id`, `username`, `password`, `withdraw_pwd`, `nickname`, `photo_fid`, `photo_url`, `tel`, `is_staff`, `wx_openid`, `birthday`, `gender`, `bio`, `qrcode_url`, `province`, `city`, `county`, `last_login_ip`, `last_login_time`, `enable`, `ext`, `delete_time`, `create_time`, `update_time`) VALUES
(1,	'admin',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'',	NULL,	NULL,	NULL,	1,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2019-05-20 18:50:08',	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:50:09'),
(2,	'test1',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test1',	NULL,	NULL,	'13600029625',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(3,	'test2',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test2',	NULL,	NULL,	'13600024750',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(4,	'test3',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test3',	NULL,	NULL,	'13600025950',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(5,	'test4',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test4',	NULL,	NULL,	'13600095676',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(6,	'test5',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test5',	NULL,	NULL,	'13600093063',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(7,	'test6',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test6',	NULL,	NULL,	'13600089202',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(8,	'test7',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test7',	NULL,	NULL,	'13600040896',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(9,	'test8',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test8',	NULL,	NULL,	'13600082576',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(10,	'test9',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test9',	NULL,	NULL,	'13600056429',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(11,	'test10',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test10',	NULL,	NULL,	'13600065946',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(12,	'test11',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test11',	NULL,	NULL,	'13600056550',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(13,	'test12',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test12',	NULL,	NULL,	'13600060932',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(14,	'test13',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test13',	NULL,	NULL,	'13600081389',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(15,	'test14',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test14',	NULL,	NULL,	'13600034180',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(16,	'test15',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test15',	NULL,	NULL,	'13600089609',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(17,	'test16',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test16',	NULL,	NULL,	'13600081729',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(18,	'test17',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test17',	NULL,	NULL,	'13600065819',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(19,	'test18',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test18',	NULL,	NULL,	'13600090687',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(20,	'test19',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test19',	NULL,	NULL,	'13600069806',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(21,	'test20',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test20',	NULL,	NULL,	'13600082269',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(22,	'test21',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test21',	NULL,	NULL,	'13600080455',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(23,	'test22',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test22',	NULL,	NULL,	'13600099245',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(24,	'test23',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test23',	NULL,	NULL,	'13600050192',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(25,	'test24',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test24',	NULL,	NULL,	'13600083991',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(26,	'test25',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test25',	NULL,	NULL,	'13600085059',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(27,	'test26',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test26',	NULL,	NULL,	'13600053712',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(28,	'test27',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test27',	NULL,	NULL,	'13600019449',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(29,	'test28',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test28',	NULL,	NULL,	'13600095829',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(30,	'test29',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test29',	NULL,	NULL,	'13600057658',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(31,	'test30',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test30',	NULL,	NULL,	'13600082075',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(32,	'test31',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test31',	NULL,	NULL,	'13600011313',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(33,	'test32',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test32',	NULL,	NULL,	'13600021927',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(34,	'test33',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test33',	NULL,	NULL,	'13600037626',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(35,	'test34',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test34',	NULL,	NULL,	'13600022521',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(36,	'test35',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test35',	NULL,	NULL,	'13600012553',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(37,	'test36',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test36',	NULL,	NULL,	'13600092061',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(38,	'test37',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test37',	NULL,	NULL,	'13600027703',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(39,	'test38',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test38',	NULL,	NULL,	'13600030795',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32'),
(40,	'test39',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'test39',	NULL,	NULL,	'13600054126',	0,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-20 18:30:32');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user_role`;

CREATE TABLE `td_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `role_id` int(11) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户角色';

INSERT INTO `td_user_role` (`id`, `uid`, `role_id`) VALUES
(1,	1,	1);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user_token`;

CREATE TABLE `td_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `token` varchar(256) NOT NULL COMMENT '用户token, 唯一',
  `expire_time` datetime NOT NULL COMMENT '过期时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户token表';



-- THE END
