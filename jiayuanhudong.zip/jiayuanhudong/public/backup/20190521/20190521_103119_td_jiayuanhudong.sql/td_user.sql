/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : td_jiayuanhudong

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2019-05-21 15:12:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `td_user`
-- ----------------------------
DROP TABLE IF EXISTS `td_user`;
CREATE TABLE `td_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `password` varchar(256) NOT NULL COMMENT '用户密码',
  `withdraw_pwd` varchar(256) DEFAULT NULL COMMENT '提现密码',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `photo_fid` int(11) DEFAULT NULL COMMENT '头像文件id',
  `photo_url` varchar(256) DEFAULT NULL COMMENT '头像文件url',
  `tel` varchar(64) DEFAULT NULL COMMENT '电话号码',
  `is_staff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否后台用户',
  `wx_openid` varchar(128) DEFAULT NULL COMMENT '微信open id',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `gender` int(11) DEFAULT NULL COMMENT '性别1:男,2:女',
  `bio` varchar(2000) DEFAULT NULL COMMENT '个人签名',
  `qrcode_url` int(11) DEFAULT NULL COMMENT '二维码地址',
  `province` int(11) DEFAULT NULL COMMENT '省代码',
  `city` int(11) DEFAULT NULL COMMENT '市代码',
  `county` int(11) DEFAULT NULL COMMENT '区代码',
  `last_login_ip` bigint(20) DEFAULT NULL COMMENT '最后登录IP',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `enable` int(11) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `ext` json DEFAULT NULL COMMENT '存储json数据',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `wx_openid` (`wx_openid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ----------------------------
-- Records of td_user
-- ----------------------------
INSERT INTO `td_user` VALUES ('1', 'admin', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, '', null, null, null, '1', null, null, null, null, null, null, null, null, null, '2019-05-21 09:56:17', '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('2', 'test1', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test1', null, null, '13600029625', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('3', 'test2', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test2', null, null, '13600024750', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('4', 'test3', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test3', null, null, '13600025950', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('5', 'test4', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test4', null, null, '13600095676', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('6', 'test5', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test5', null, null, '13600093063', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('7', 'test6', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test6', null, null, '13600089202', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('8', 'test7', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test7', null, null, '13600040896', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('9', 'test8', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test8', null, null, '13600082576', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('10', 'test9', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test9', null, null, '13600056429', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('11', 'test10', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test10', null, null, '13600065946', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('12', 'test11', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test11', null, null, '13600056550', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('13', 'test12', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test12', null, null, '13600060932', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('14', 'test13', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test13', null, null, '13600081389', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('15', 'test14', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test14', null, null, '13600034180', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('16', 'test15', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test15', null, null, '13600089609', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('17', 'test16', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test16', null, null, '13600081729', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('18', 'test17', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test17', null, null, '13600065819', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('19', 'test18', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test18', null, null, '13600090687', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('20', 'test19', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test19', null, null, '13600069806', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('21', 'test20', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test20', null, null, '13600082269', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('22', 'test21', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test21', null, null, '13600080455', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('23', 'test22', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test22', null, null, '13600099245', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('24', 'test23', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test23', null, null, '13600050192', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('25', 'test24', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test24', null, null, '13600083991', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('26', 'test25', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test25', null, null, '13600085059', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('27', 'test26', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test26', null, null, '13600053712', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('28', 'test27', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test27', null, null, '13600019449', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('29', 'test28', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test28', null, null, '13600095829', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('30', 'test29', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test29', null, null, '13600057658', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('31', 'test30', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test30', null, null, '13600082075', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('32', 'test31', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test31', null, null, '13600011313', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('33', 'test32', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test32', null, null, '13600021927', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('34', 'test33', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test33', null, null, '13600037626', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('35', 'test34', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test34', null, null, '13600022521', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('36', 'test35', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test35', null, null, '13600012553', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('37', 'test36', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test36', null, null, '13600092061', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('38', 'test37', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test37', null, null, '13600027703', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('39', 'test38', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test38', null, null, '13600030795', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
INSERT INTO `td_user` VALUES ('40', 'test39', 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b', null, 'test39', null, null, '13600054126', '0', null, null, null, null, null, null, null, null, null, null, '1', null, null, '2019-05-20 18:30:32');
