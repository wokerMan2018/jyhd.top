-- Created at 22.5.2019 18:55 using David Grudl MySQL Dump Utility
-- Host: jyhd.top
-- MySQL Server: 5.7.21
-- Database: td_jiayuanhudong

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_article`;

CREATE TABLE `td_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `atype` int(4) DEFAULT NULL COMMENT '类型，1为文章类型 2 为培训（培训只有老师可见）',
  `uid` int(11) DEFAULT NULL COMMENT '用户id（作者）',
  `atitle` varchar(256) DEFAULT NULL COMMENT '文章标题',
  `acontent` text COMMENT '文章内容',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章表 article';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_attention`;

CREATE TABLE `td_attention` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) DEFAULT NULL COMMENT '被关注的商品id',
  `uid` int(11) DEFAULT NULL COMMENT '关注人id',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户关注商品表 attention';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_balance_log`;

CREATE TABLE `td_balance_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `amount` decimal(10,0) NOT NULL COMMENT '变动金额，增加为正数，减少为负数',
  `balance` decimal(10,0) NOT NULL COMMENT '变动后金额',
  `change_type` int(11) NOT NULL COMMENT '变动类型,10:充值,20:提现',
  `change_id` int(11) DEFAULT NULL COMMENT '变动关联id',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账户变动表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_car`;

CREATE TABLE `td_car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `detail` varchar(1024) DEFAULT NULL COMMENT '购物车详情数据',
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户购物车表 car';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_comments`;

CREATE TABLE `td_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) DEFAULT NULL COMMENT '文章表id',
  `uid` int(11) DEFAULT NULL COMMENT '评论者id',
  `content` varchar(256) DEFAULT NULL COMMENT '评论内容',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论表 comments';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_config`;

CREATE TABLE `td_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) NOT NULL COMMENT '键',
  `val` varchar(4000) NOT NULL COMMENT '值',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `grouping` varchar(128) DEFAULT NULL COMMENT '分组',
  `remark` varchar(256) DEFAULT NULL COMMENT '说明',
  `format` varchar(256) NOT NULL DEFAULT 'string' COMMENT '数据格式|验证正则: int,float,string,datetime',
  `help_text` varchar(512) DEFAULT NULL COMMENT '字段说明',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='配置';

INSERT INTO `td_config` (`id`, `key`, `val`, `sorting`, `grouping`, `remark`, `format`, `help_text`, `delete_time`, `create_time`, `update_time`) VALUES
(1,	'admin_site_name',	'后台管理系统',	100,	'admin',	NULL,	'string',	NULL,	NULL,	'2019-05-20 18:30:30',	'2019-05-20 18:30:30'),
(2,	'admin_copyright',	'武汉图叮科技',	100,	'admin',	NULL,	'string',	NULL,	NULL,	'2019-05-20 18:30:30',	'2019-05-20 18:30:30');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_file`;

CREATE TABLE `td_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL COMMENT '显示名称',
  `file_name` varchar(256) NOT NULL COMMENT '文件名，包含后缀',
  `file_ext` varchar(64) DEFAULT NULL COMMENT '文件后缀',
  `file_path` varchar(512) DEFAULT NULL COMMENT '文件相对url路径',
  `file_size` int(11) NOT NULL COMMENT '文件大小',
  `category` varchar(64) NOT NULL DEFAULT 'default' COMMENT '文件分类',
  `upload_by` int(11) DEFAULT NULL COMMENT '上传用户uid',
  `sha1` varchar(64) DEFAULT NULL COMMENT 'sha1值',
  `is_public` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否能公开访问',
  `ext_url` varchar(512) DEFAULT NULL COMMENT 'mime类型',
  `mime_type` varchar(64) NOT NULL COMMENT 'mime类型',
  `media_type` varchar(64) NOT NULL DEFAULT 'file' COMMENT '文件类型,video,image,txt,file',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sha1` (`sha1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文件表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_goods`;

CREATE TABLE `td_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gtype` int(4) DEFAULT NULL COMMENT '商品类型，1为实体商品，2为虚拟商品',
  `gimages` varchar(256) DEFAULT NULL COMMENT '商品图片',
  `gname` varchar(256) DEFAULT NULL COMMENT '商品名称',
  `gprice` varchar(256) DEFAULT NULL COMMENT '商品价格',
  `gintro` text COMMENT '商品简介',
  `gdetail` text COMMENT '商品详情',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表 goods';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_grade`;

CREATE TABLE `td_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL COMMENT '所属学校',
  `gtype` varchar(50) DEFAULT NULL COMMENT '所属年级，如大班 中班 小班',
  `gname` varchar(256) DEFAULT NULL COMMENT '班级名称',
  `gperson` varchar(256) DEFAULT NULL COMMENT '班级联系人',
  `gphone` varchar(256) DEFAULT NULL COMMENT '班级联系电话',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='班级表  grade';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_homework`;

CREATE TABLE `td_homework` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL COMMENT '所属学校',
  `gid` int(11) DEFAULT NULL COMMENT '所属学校',
  `title` varchar(256) DEFAULT NULL COMMENT '作业标题',
  `content` text COMMENT '作业内容',
  `uid` int(11) DEFAULT NULL COMMENT '布置老师id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='作业表 homework';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_integ_config`;

CREATE TABLE `td_integ_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operate` varchar(256) DEFAULT NULL COMMENT '操作名称',
  `integ_num` int(4) DEFAULT NULL COMMENT '增加积分数',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '| 更新时间 |',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分配置表 integ_config';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_menu`;

CREATE TABLE `td_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '上级id',
  `is_leaf` int(11) NOT NULL DEFAULT '1' COMMENT '是否叶子节点',
  `module` varchar(64) DEFAULT NULL COMMENT '所属应用',
  `controller` varchar(64) DEFAULT NULL COMMENT '控制器',
  `action` varchar(64) DEFAULT NULL COMMENT '方法',
  `params` varchar(256) DEFAULT NULL COMMENT '参数',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `icon` varchar(32) DEFAULT 'fa fa-circle-o' COMMENT 'icon class',
  `type` varchar(32) NOT NULL DEFAULT 'action' COMMENT '链接类型:action, page, ext_url',
  `ext_url` varchar(256) DEFAULT NULL COMMENT '外部链接地址',
  `target` varchar(32) DEFAULT NULL COMMENT '打开方式',
  `enable` int(11) NOT NULL DEFAULT '1' COMMENT '是否可见',
  `grouping` varchar(32) DEFAULT NULL COMMENT '分组',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COMMENT='后台菜单';

INSERT INTO `td_menu` (`id`, `pid`, `is_leaf`, `module`, `controller`, `action`, `params`, `title`, `icon`, `type`, `ext_url`, `target`, `enable`, `grouping`, `sorting`, `delete_time`, `create_time`, `update_time`) VALUES
(1,	NULL,	0,	'',	'',	'',	NULL,	'用户管理',	'fa fa-user',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(2,	1,	1,	'admin',	'user',	'index',	NULL,	'用户列表',	'fa fa-table',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(3,	NULL,	0,	'',	'',	'',	NULL,	'系统设置',	'fa fa-gear',	'action',	NULL,	NULL,	1,	'admin',	999,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(4,	3,	1,	'td',	'config',	'index',	NULL,	'站点设置',	'fa fa-circle-o',	'action',	NULL,	NULL,	1,	'admin',	999,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(5,	3,	1,	'td',	'menu',	'index',	NULL,	'菜单设置',	'fa fa-th-list',	'action',	NULL,	NULL,	1,	'admin',	10,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(6,	3,	1,	'td',	'user',	'index',	NULL,	'后台用户',	'fa fa-address-book',	'action',	NULL,	NULL,	1,	'admin',	20,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(7,	3,	1,	'td',	'role',	'index',	NULL,	'角色管理',	'fa fa-users',	'action',	NULL,	NULL,	1,	'admin',	30,	NULL,	'2019-05-20 18:30:31',	'2019-05-20 18:30:31'),
(8,	NULL,	0,	'admin',	'',	'',	NULL,	'注册码管理',	'fa fa-500px',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-22 10:59:15',	'2019-05-22 10:59:15'),
(9,	8,	1,	'admin',	'Zcode',	'index',	NULL,	'注册码管理',	'fa fa-align-center',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-22 11:00:12',	'2019-05-22 11:00:12'),
(10,	8,	1,	'admin',	'Zcode',	'create_code_view',	NULL,	'生成注册码',	'fa fa-align-justify',	'action',	NULL,	NULL,	1,	'admin',	100,	NULL,	'2019-05-22 11:17:01',	'2019-05-22 11:17:01');


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_migrations`;

CREATE TABLE `td_migrations` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `td_migrations` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20180520102725,	'User',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134217,	'Config',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134221,	'Menu',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520134226,	'Role',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520140029,	'UserRole',	'2019-05-20 18:30:22',	'2019-05-20 18:30:22',	0),
(20180520140039,	'RoleMenu',	'2019-05-20 18:30:22',	'2019-05-20 18:30:23',	0),
(20180520172046,	'Page',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180520172050,	'File',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180612111143,	'BalanceLog',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0),
(20180919055141,	'UserToken',	'2019-05-20 18:30:23',	'2019-05-20 18:30:23',	0);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_page`;

CREATE TABLE `td_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL COMMENT '标题',
  `photo_id` int(11) DEFAULT NULL COMMENT '封面照片id',
  `link_name` text NOT NULL COMMENT '链接名称',
  `content` text NOT NULL COMMENT '内容',
  `slug` varchar(128) DEFAULT NULL COMMENT '短连接, 唯一',
  `grouping` varchar(32) DEFAULT NULL COMMENT '分组',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='页面表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_regi_code`;

CREATE TABLE `td_regi_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `rtype` int(4) DEFAULT NULL COMMENT '注册码使用对象类型，1为老师 2 二为家长',
  `number` varchar(256) DEFAULT NULL COMMENT '注册码',
  `status` int(4) DEFAULT NULL COMMENT '是否失效 1为可使用 2为失效',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT ' 更新时间 ',
  `use_time` datetime DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL COMMENT '绑定手机号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COMMENT='注册码表 regi_code ';

INSERT INTO `td_regi_code` (`id`, `rtype`, `number`, `status`, `create_time`, `update_time`, `use_time`, `phone`) VALUES
(1,	1,	'5510055981',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(2,	1,	'5650511005',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(3,	1,	'1025553102',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(4,	1,	'5599491009',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(5,	1,	'1019957971',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(6,	1,	'5157509849',	1,	'2019-05-22 14:06:34',	'2019-05-22 14:06:34',	NULL,	NULL),
(7,	1,	'9754975456',	1,	'2019-05-22 14:06:35',	'2019-05-22 14:06:35',	NULL,	NULL),
(8,	1,	'5699101555',	1,	'2019-05-22 14:06:35',	'2019-05-22 14:06:35',	NULL,	NULL),
(9,	1,	'5356102539',	1,	'2019-05-22 14:06:35',	'2019-05-22 14:06:35',	NULL,	NULL),
(10,	1,	'9899545348',	1,	'2019-05-22 14:06:35',	'2019-05-22 14:06:35',	NULL,	NULL),
(11,	2,	'5355100991',	1,	'2019-05-22 14:08:47',	'2019-05-22 14:08:47',	NULL,	NULL),
(12,	2,	'1021005751',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(13,	2,	'5252985110',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(14,	2,	'5157985510',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(15,	2,	'5199101491',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(16,	2,	'1025256554',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(17,	2,	'5355579757',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(18,	2,	'9852102101',	1,	'2019-05-22 14:08:48',	'2019-05-22 14:08:48',	NULL,	NULL),
(19,	2,	'9810257519',	1,	'2019-05-22 14:08:49',	'2019-05-22 14:08:49',	NULL,	NULL),
(20,	2,	'5749989910',	1,	'2019-05-22 14:08:49',	'2019-05-22 14:08:49',	NULL,	NULL);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_remark`;

CREATE TABLE `td_remark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL COMMENT '答案id',
  `rate` int(4) DEFAULT NULL COMMENT '评级 1为良好 2为优秀 3为超赞',
  `uid` int(11) DEFAULT NULL COMMENT '评论人id（某位老师）',
  `score` int(11) DEFAULT NULL COMMENT '老师打分',
  `content` text COMMENT '评论内容',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='老师对提交的作业做出评价表 remark';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_role`;

CREATE TABLE `td_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL COMMENT '权限代码',
  `name` varchar(32) NOT NULL COMMENT '权限名称',
  `home_page` varchar(32) DEFAULT NULL COMMENT '角色首页',
  `is_sys` int(11) NOT NULL DEFAULT '1' COMMENT '是否系统内置(系统内置1不能删除)',
  `sorting` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='角色';

INSERT INTO `td_role` (`id`, `code`, `name`, `home_page`, `is_sys`, `sorting`) VALUES
(1,	'admin',	'管理员',	'admin/user/index',	1,	100);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_role_menu`;

CREATE TABLE `td_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `menu_id` int(11) NOT NULL COMMENT '菜单id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色菜单对应表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_school`;

CREATE TABLE `td_school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(50) DEFAULT NULL COMMENT '学校编号',
  `name` varchar(256) DEFAULT NULL COMMENT '学校名称',
  `address` varchar(1024) DEFAULT NULL COMMENT '地址',
  `contact_person` varchar(256) DEFAULT NULL COMMENT '联系人',
  `contact_phone` varchar(256) DEFAULT NULL COMMENT '联系方式',
  `detail` varchar(256) DEFAULT NULL COMMENT '全部班级',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学校表  school';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_solution`;

CREATE TABLE `td_solution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '提交人id',
  `hid` int(11) DEFAULT NULL COMMENT '作业表id',
  `type` int(4) DEFAULT NULL COMMENT '是否能够修改，1为能修改，2不能修改',
  `content` text COMMENT '提交具体内容',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='答案表（提交作业）solution';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user`;

CREATE TABLE `td_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL COMMENT '用户名',
  `password` varchar(256) NOT NULL COMMENT '用户密码',
  `withdraw_pwd` varchar(256) DEFAULT NULL COMMENT '提现密码',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `photo_fid` int(11) DEFAULT NULL COMMENT '头像文件id',
  `photo_url` varchar(256) DEFAULT NULL COMMENT '头像文件url',
  `tel` varchar(64) DEFAULT NULL COMMENT '电话号码',
  `is_staff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否后台用户',
  `wx_openid` varchar(128) DEFAULT NULL COMMENT '微信open id',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `gender` int(4) DEFAULT NULL COMMENT '性别1:男,2:女',
  `bio` varchar(2000) DEFAULT NULL COMMENT '个人签名',
  `qrcode_url` int(11) DEFAULT NULL COMMENT '二维码地址',
  `province` int(11) DEFAULT NULL COMMENT '省代码',
  `city` int(11) DEFAULT NULL COMMENT '市代码',
  `county` int(11) DEFAULT NULL COMMENT '区代码',
  `last_login_ip` bigint(20) DEFAULT NULL COMMENT '最后登录IP',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `enable` int(11) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `ext` json DEFAULT NULL COMMENT '存储json数据',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `regi_code` varchar(256) DEFAULT NULL COMMENT '注册码',
  `integral` int(4) DEFAULT NULL COMMENT '积分',
  `u_type` int(4) DEFAULT NULL COMMENT '用户类型，1为管理员，2教师， 3 家长  4游客',
  `phone` varchar(50) DEFAULT NULL COMMENT '用户手机',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `wx_openid` (`wx_openid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO `td_user` (`id`, `username`, `password`, `withdraw_pwd`, `nickname`, `photo_fid`, `photo_url`, `tel`, `is_staff`, `wx_openid`, `birthday`, `gender`, `bio`, `qrcode_url`, `province`, `city`, `county`, `last_login_ip`, `last_login_time`, `enable`, `ext`, `delete_time`, `create_time`, `update_time`, `regi_code`, `integral`, `u_type`, `phone`) VALUES
(1,	'admin',	'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',	NULL,	'',	NULL,	NULL,	NULL,	1,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2019-05-22 18:55:15',	1,	NULL,	NULL,	'2019-05-20 18:30:32',	'2019-05-22 18:55:15',	NULL,	NULL,	NULL,	NULL);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user_profile`;

CREATE TABLE `td_user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `m_id` int(11) DEFAULT '0' COMMENT '机构ID',
  `following_count` int(11) NOT NULL DEFAULT '0' COMMENT '关注数量',
  `followed_count` int(11) NOT NULL DEFAULT '0' COMMENT '粉丝数量',
  `zan_count` int(11) NOT NULL DEFAULT '0' COMMENT '用户被赞总数量',
  `send_total` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '打赏的奖励总金额',
  `send_count` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '打赏奖励总数量',
  `receive_total` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '收到的打赏奖励总数',
  `receive_count` int(11) NOT NULL DEFAULT '0' COMMENT '收到打赏总数量',
  `receive_best_id` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '收到最奖励资金记录ID',
  `balance` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '帐号余额',
  `balance_freeze` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '冻结的金额，冻结的金额是无法提现的',
  `vip_level` int(11) NOT NULL DEFAULT '0' COMMENT 'vip级别,0非VIP, 10普通VIP, 20高级VIP（暂时未设计vip）',
  `identity` int(11) NOT NULL DEFAULT '0' COMMENT '用户身份（高中、初中、老师应该对应身份表）废弃保存到user表中',
  `user_type` int(11) NOT NULL DEFAULT '0' COMMENT '用户的类别（美术、编导、播音..对应平台分类表）废弃保存到user表中 ',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `status` int(11) DEFAULT NULL COMMENT '0(在职)   1(离职)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=45665 DEFAULT CHARSET=utf8mb4 COMMENT='用户信息表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user_role`;

CREATE TABLE `td_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `role_id` int(11) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='用户角色';

INSERT INTO `td_user_role` (`id`, `uid`, `role_id`) VALUES
(1,	1,	1);


-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_user_token`;

CREATE TABLE `td_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `token` varchar(256) NOT NULL COMMENT '用户token, 唯一',
  `expire_time` datetime NOT NULL COMMENT '过期时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户token表';



-- --------------------------------------------------------

DROP TABLE IF EXISTS `td_website`;

CREATE TABLE `td_website` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `desc` varchar(256) DEFAULT NULL,
  `adpath` text COMMENT '商户列表广告图片地址',
  `price` varchar(256) DEFAULT NULL COMMENT '虚拟商品价格',
  `effective_time` tinyint(4) DEFAULT NULL COMMENT 'vip有效时长 单位：年',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `td_website` (`id`, `name`, `desc`, `adpath`, `price`, `effective_time`) VALUES
(1,	'家园互动',	' 家园互动 微信小程序存储',	'{\"0\":\"\\/uploads\\/20190517\\/img_20190517175114_2068.png\",\"1\":\"\\/uploads\\/20190517\\/img_20190517175114_8216.png\",\"2\":\"\\/uploads\\/20190517\\/img_20190517175115_2437.png\",\"3\":\"\\/uploads\\/20190517\\/img_20190517175115_8456.png\",\"4\":\"\\/uploads\\/20190517\\/img_20190517175116_2541.png\",\"5\":\"\\/uploads\\/20190517\\/img_20190517175117_6893.png\",\"6\":\"\\/uploads\\/20190517\\/img_20190517175117_9293.png\",\"7\":\"\\/uploads\\/20190517\\/img_20190517175117_9805.png\",\"8\":\"\\/uploads\\/20190517\\/img_20190517175118_5541.png\",\"9\":\"\\/uploads\\/20190517\\/img_20190517175118_2145.png\"}',	'0.01',	1);


-- THE END
