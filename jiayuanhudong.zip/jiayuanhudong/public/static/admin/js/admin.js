window.TD = {};

TD.alert = function(message) {
    return swal(message);
};
TD.editors = [];


function update_ck_editor() {
    if(window.ck_editors) {
        for (var i = 0; i < window.ck_editors.length; i++) {
            if(window.ck_editors[i].sourceElement) {
                window.ck_editors[i].updateSourceElement();
            }
        }
    }
}


/**
 * 确认提示
 * @param message
 * @param on_confirm 点击取消执行的函数
 * @returns {*}
 */
TD.confirm = function(message, on_confirm) {
    return swal({
        title: message,
        buttons: {
            cancel: {
                text: "取消",
                value: null,
                visible: true,
                closeModal: true,
            },
            confirm: {
                text: "确定",
                value: true,
                visible: true,
                closeModal: true
            }}
    })
        .then(function (value) {
            return on_confirm(value);
        });
};

/**
 * ajax请求toastr处理
 * @param res
 */
TD.toastr = function(res) {
    var mesage = res.message;
    if(!res.success) {
        message = mesage || '更新失败';
        toastr.error(message);
        return;
    }
    else {
        message = mesage || '更新成功';
        toastr.success(message);
        if(res['redirect_url']) {
            window.location.href = res['redirect_url'];
        }
    }

};

$(function () {
    // init_adminlte();
    $.support.transition = false;  // 禁用bootstrap过渡效果
    init_toastr();

    try {

        NProgress.configure({parent: '.nprogress-parent', showSpinner: false});
        if($.fn.select2) {
            $.fn.select2.defaults.set("theme", "bootstrap");
            $.fn.select2.defaults.set("minimumResultsForSearch", Infinity);
        }

        if($.fn.datepicker) {
            // 设置日期
            $('.td-date').datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true,
                language: 'zh-CN'
            });
        }

        var _editors = document.querySelectorAll('.td-ckeditor5');

        if(_editors.length >0) {
            for(var i=0; i< _editors.length; i++) {
                ClassicEditor
                    .create(_editors[i], {
                        imageUploadPlugin: {
                            // type: "serverSide",
                            // uploadUrl: "/index.php/td/file/upload"
                            // uploadUrl: "upload/ckediter"
                            type: "qiniu",
                            getTokenUrl: "/index.php/td/file/get_qiniu_upload_token",
                            uploadUrl: "https://upload-z2.qiniup.com"
                        }
                    })
                    .then(function(editor) {
                        if(editor.sourceElement) {
                            window.ck_editors = window.ck_editors || [];
                            window.ck_editors.push(editor);
                        }
                    })
                    .catch(error => {
                        console.log(error)
                    });
            }
        }

    }
    catch (e) {
        console.log(e);
    }
});

function init_toastr() {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-center",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
}


function clean_cache(link) {
    var url = $(link).data('url');
    $.get(url, function (res) {
        toastr['success']('清除成功');
    });
}

/**
 *  NProgress设置
 */
$(document).ajaxStart(function () {
    try {
        NProgress.start();
    }
    catch (e) {
        console.log(e);
    }
});

$(document).ajaxStop(function () {
    try {
        NProgress.done();
    }
    catch (e) {
        console.log(e);
    }
});

function resetSearchForm(btn) {
    var url = $(btn).data('url');
    window.location.href = url;
}