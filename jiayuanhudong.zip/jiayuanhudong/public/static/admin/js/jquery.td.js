﻿// (function ($) {
//     $.fn.tdAlert = function (message) {
//         alert(message);
//     };
// })(jQuery);

// $.fn.tdAlert = function (message) {
//     alert(message);
// };

function isJsonString(str) {
    try {
        if (typeof JSON.parse(str) == "object") {
            return true;
        }
    } catch (e) {
    }
    return false;
}

// tdGrid 插件
// 表格
(function ($) {
    $.fn.tdGrid = function (options) {
        var _this = this;
        var _table = _this.find('table.td-table');
        /**
         * 点击对象
         * @param sender
         * @returns {boolean}
         */
        var beforeDelete = function (sender) {
            return true;
        };

        /**
         * @param sender
         * @param result ajax返回对象
         */
        var afterDelete = function (sender, result) {
            if (result.success) {
                var msg = result['message'] || '删除成功';
                toastr['success'](msg);
                window.location.replace(TD_PAGE.url);
            }
            else {
                toastr['error'](result.message);
            }
        };

        var beforeDeleteMany = function (sender) {
            if(!sender.data('id')) {
                toastr['error']('请选择删除的记录');
                return;
            }
            return true
        };

        var afterDeleteMany = function (sender, result) {
            if (result.success) {
                var msg = result['message'] || '删除成功';
                toastr['success'](msg);
                window.location.replace(TD_PAGE.url);
            }
            else {
                toastr['error'](result.message);
            }
        };

        // 初始化 options
        var _options = $.extend({
            "beforeDelete": beforeDelete,
            "afterDelete": afterDelete,
            "beforeDeleteMany": beforeDeleteMany,
            "afterDeleteMany": afterDeleteMany,
            "beforeAdd": function () {
                return true;
            },
            "beforeEdit": function () {
                return true;
            },
            "beforeRefresh": function () {
                return true;
            }
        }, options);


        // 列表全选 获取选中的id，逗号分割
        var getSelectIds = function () {
            var result = [];
            _table.find('input[type=checkbox].td-tr-check:checked').each(function () {
                result.push($(this).data('id'));
            });
            return result.length ? result.join(',') : '';
        };

        _table.find('input.td-th-check').change(function () {
            var checked = $(this).prop('checked');
            _table.find('input[type=checkbox].td-tr-check').prop('checked', checked);
        });

        _table.find('input.td-tr-check').change(function () {
            var checkStatus = [];
            _table.find('input[type=checkbox].td-tr-check').each(function () {
                checkStatus.push($(this).prop('checked'));
            });

            _table.find('input[type=checkbox].td-th-check').prop('checked',
                checkStatus.every(function (value) {
                    return value;
                })
            );
        });

        // 编辑
        _table.find('.td-tr-edit').click(function (e) {
            var sender = $(this);

            if ($.isFunction(_options.beforeEdit) && _options.beforeEdit(sender)) {
                window.location.href = TD_PAGE.edit_url + '/id/' + sender.data('id');
            }
        });

        /**
         * 删除
         */
        _table.find('.td-tr-delete').click(function (e) {
            var sender = $(this);
            if(!$.isFunction(_options.beforeDelete) || !$.isFunction(_options.afterDelete)) {
                alert('错误: beforeDelete/afterDelete应为函数');
                return;
            }
            TD.confirm('确定要删除吗?', function(ok) {
                if(!ok) return;
                if(_options.beforeDelete(sender)) {
                    $.post(TD_PAGE.delete_url, {id: sender.data('id')}, function (result) {
                        return _options.afterDelete(sender, result);
                    });
                }
            });
        });

        // 批量删除
        _this.find('.td-grid-delete').click(function (e) {
            var sender = $(this);
            var selectedIds = getSelectIds();
            sender.data('id', selectedIds);
            if(!$.isFunction(_options.beforeDeleteMany) || !$.isFunction(_options.afterDeleteMany)) {
                alert('错误: beforeDeleteMany/afterDeleteMany应为函数');
                return;
            }
            TD.confirm('确定要删除吗?', function (ok) {
                if(!ok) return;
                if(_options.beforeDeleteMany(sender)) {
                    $.post(TD_PAGE.delete_url, {id: sender.data('id')}, function (result) {
                        return _options.afterDeleteMany(sender, result);
                    });
                }
            });
        });

        // 新增
        _this.find('.td-grid-add').click(function (e) {
            var sender = $(this);
            if ($.isFunction(_options.beforeAdd) && _options.beforeAdd(sender)) {
                window.location.href = TD_PAGE.add_url;
            }
        });

        _this.find('.td-grid-search').click(function (e) {

            if(_this.find('.td-form').hasClass('hidden')) {
                _this.find('.td-form').removeClass('hidden');
            }
            else {
                _this.find('.td-form').addClass('hidden');
            }
        });

        // 刷新
        _this.find('.td-grid-refresh').click(function (e) {
            var sender = $(this);
            if ($.isFunction(_options.beforeRefresh) && _options.beforeRefresh(sender)) {
                window.location.reload();
            }
        });

    };

})(jQuery);

//form
(function () {
    $.fn.tdForm = function (options) {
        var _this = this;

        var beforeSubmit = function () {
            return true;
        };

        var onJsonSuccess = function (res) {
            var msg = res['message'] || '更新成功';
            toastr.success(msg);
            var redirect_url = res['redirect_url'] || window.location.href;
            window.location.href = redirect_url;
        };
        var onJsonFailed = function (res) {
            var msg = res['message'] || '更新失败';
            toastr.error(msg);
        };


        // 初始化 options
        var _options = $.extend({
            'beforeSubmit': beforeSubmit,
            'onJsonSuccess': onJsonSuccess,
            'onJsonFailed': onJsonFailed
        }, options);

        _this.on('submit', function(e) {
            _this.find('[type=submit]').prop('disabled', true);
            e.preventDefault(); // prevent native submit

            if ($.isFunction(_options.beforeSubmit) && _options.beforeSubmit()) {
                if(window.ck_editors) {
                    for (var i = 0; i < window.ck_editors.length; i++) {
                        if(window.ck_editors[i].sourceElement) {
                            window.ck_editors[i].updateSourceElement();
                        }
                    }
                }
                $(this).ajaxSubmit({
                    success: function (res) {
                        _this.find('[type=submit]').prop('disabled', false);
                        return res.success ? _options.onJsonSuccess(res) : _options.onJsonFailed(res);
                    }
                })
            }
            else {
                _this.find('[type=submit]').prop('disabled', false);
            }

        });


    };
})(jQuery);

//LYH 查询
(function () {
    $.fn.tdGridInlineSearch = function (options) {
        var _this = this;

        var beforeSubmit = function () {
            return true;
        };

        var onJsonSuccess = function (res) {
            // var msg = res['message'] || '更新成功';
            // toastr.success(msg);
            // var redirect_url = res['redirect_url'] || window.location.href;
            // window.location.href = redirect_url;
        };
        var onJsonFailed = function (res) {
            // var msg = res['message'] || '更新失败';
            // toastr.error(msg);
        };


        // 初始化 options
        var _options = $.extend({
            'beforeSubmit': beforeSubmit,
            'onJsonSuccess': onJsonSuccess,
            'onJsonFailed': onJsonFailed
        }, options);



        _this.on('click',function(e){
            var inp = $("#td-search-field").val();
            var status = $(this).attr('status');
            if(inp == ''){
                toastr.error('请输入查询条件');
                return false;
            }
            var url = $(this).attr('data-url');
            //status 扩展的状态，现在用户查询、视频查询、音乐查询均未使用该参数
            if(status == undefined || status == ''){
                window.location.href= url+'?id='+inp;
            }else{
                //查询用户的粉丝使用
                window.location.href= url+'?id='+inp+'&status='+status;
            }


        });



    };
})(jQuery);

function parseDataAttr(dataList) {

}

(function () {
    var do_click = function (e) {
        var _this = $(e.currentTarget);
        var _before = _this.data('ajax-before');

        // 防止连续点击
        _this.prop('disabled', true);
        _this.unbind('click');

        var call_reuslt = true;
        if(window[_before] && typeof window[_before] === 'function') {
            call_reuslt = window[_before](_this);
            if(call_reuslt === false) {
                _this.prop('disabled', false);
                _this.bind('click', do_click);
                return;
            }
        }

        var _url = _this.data('url');
        var _method = _this.data('ajax-method') || 'POST';
        var _callback = _this.data('ajax-callback');
        var _dataAttr = _this.data() || {};
        var _data = {};
        for(var o in _dataAttr) {
            if(o.startsWith('content')) {
                var _attr = o.replace('content', '');
                _data[_attr.toLowerCase()] = _dataAttr[o];
            }
        }
        if(!_url) {
            alert('data-url 为空');
        }

        var _confirm_msg = _this.data('ajax-confirm');

        if(!_confirm_msg) {
            // 没有确认信息
            $.ajax({method: _method, url: _url, data: _data,
                success: function (res) {
                    _this.prop('disabled', false);
                    _this.bind('click', do_click);
                    if(window[_callback] && typeof window[_callback] === 'function') {
                        return window[_callback](_this, res);
                    }
                    else {
                        return res.success ? toastr.success(res.message) : toastr.error(res.message);
                    }
                }
            });
        }
        else {
            TD.confirm(_confirm_msg, function (ok) {
                if(!ok) {
                    // 点击取消执行
                    _this.prop('disabled', false);
                    _this.bind('click', do_click);
                    return;
                }
                $.ajax({method: _method, url: _url, data: _data,
                    success: function (res) {
                        _this.prop('disabled', false);
                        _this.bind('click', do_click);
                        if(window[_callback] && typeof window[_callback] === 'function') {
                            return window[_callback](_this, res);
                        }
                        else {
                            return res.success ? toastr.success(res.message) : toastr.error(res.message);
                        }
                    }
                });
            });
        }

    };

    $('a.td-ajax-btn, button.td-ajax-btn, input[type=button].td-ajax-btn').bind('click', do_click);
})();