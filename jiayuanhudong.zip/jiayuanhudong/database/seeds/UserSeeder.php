<?php

use think\migration\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'username'    => 'admin',
                'password' => 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',
                'is_staff' => 1,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ]
        ];

        $table = $this->table('user');
        $table->insert($data)->save();

        $testData = [];
        for($i = 1; $i < 40; $i++) {
            $user = [
                'username'    => 'test' . $i,
                'nickname' => 'test' . $i,
                'tel' => '136000' . rand(10000, 99999),
                'password' => 'sha256$ECHO$284b9237ac2894483a814953d3bb47dc89a69e3277e8083b3a285028e189e11b',
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ];
            $testData[] = $user;
        }
        $table->insert($testData)->save();
    }
}