<?php

use think\migration\Seeder;

class VipDateSeeder extends Seeder
{
    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $data = [
            [
                'key' => 'monthCard',
                'operate' => '月卡充值所需积分',
                'integ_num' => 1000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ],
            [
                'key' => 'seasonCard',
                'operate' => '季卡卡充值所需积分',
                'integ_num' => 4000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ],
            [
                'key' => 'yearCard',
                'operate' => '年卡充值所需积分',
                'integ_num' => 10000,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s')
            ]
        ];
        $table = $this->table('integ_config');
        $table->insert($data)->save();
    }
}