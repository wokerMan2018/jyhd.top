<?php

use think\migration\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'code' => 'admin',
                'name' => '管理员',
                'is_sys' => 1,
                'home_page' => 'admin/user/index'
            ]
        ];

        $table = $this->table('role');
        $table->insert($data)
            ->save();
    }
}