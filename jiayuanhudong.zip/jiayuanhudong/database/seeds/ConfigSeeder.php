<?php

use think\migration\Seeder;

class ConfigSeeder extends Seeder
{
    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $data = [
            [
                'key' => 'admin_site_name',
                'val' => '后台管理系统',
                'grouping' => 'admin',
                'format' => 'string'
            ],
            [
                'key' => 'admin_copyright',
                'val' => '武汉图叮科技',
                'grouping' => 'admin',
                'format' => 'string'
            ],
        ];

        $table = $this->table('config');
        $table->insert($data)
            ->save();
    }
}