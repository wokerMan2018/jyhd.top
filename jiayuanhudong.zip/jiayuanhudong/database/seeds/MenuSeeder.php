<?php

use think\migration\Seeder;

class MenuSeeder extends Seeder
{

    /**
     * ->addColumn('is_leaf', 'integer', ['default' => 1, 'comment' => '是否叶子节点'])
    ->addColumn('module', 'string', ['limit' => 64, 'null' => true, 'comment' => '所属应用'])
    ->addColumn('controller', 'string', ['limit' => 64, 'null' => true, 'comment' => '控制器'])
    ->addColumn('action', 'string', ['limit' => 64, 'null' => true, 'comment' => '方法'])
    ->addColumn('params', 'string', ['limit' => 256, 'null' => true, 'comment' => '参数'])
    ->addColumn('title', 'string', ['limit' => 64, 'default' => '', 'comment' => '标题'])
    ->addColumn('icon', 'string', ['limit' => 32, 'default' => 'fa fa-circle-o', 'null' => true, 'comment' => 'icon class'])
    ->addColumn('type', 'string', ['limit' => 32, 'default' => 'action', 'comment' => '链接类型:action, page, ext_url'])
    ->addColumn('ext_url', 'string', ['limit' => 256, 'null' => true, 'comment' => '外部链接地址'])
    ->addColumn('target', 'string', ['limit' => 32, 'null' => true, 'comment' => '打开方式'])
    ->addColumn('grouping', 'string', ['limit' => 32, 'null' => true, 'comment' => '分组'])
    ->addColumn('sorting', 'integer', ['default' => 100, 'comment' => '排序'])
    ->addColumn('delete_time', 'datetime', ['null' => true, 'comment' => '删除时间'])
    ->addColumn('create_time', 'datetime', ['comment' => '创建时间'])
    ->addColumn('update_time', 'datetime', ['comment' => '修改时间']);
     */

    /**
     * Run Method.
     *
     * Write your database seeder using this method.
     *
     * More information on writing seeders is available here:
     * http://docs.phinx.org/en/latest/seeding.html
     */
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'is_leaf' => 0,
                'module' => '',
                'controller' => '',
                'action' => '',
                'title' => '用户管理',
                'icon' => 'fa fa-user',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 100,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => 2,
                'pid' => 1,
                'is_leaf' => 1,
                'module' => 'admin',
                'controller' => 'user',
                'action' => 'index',
                'title' => '用户列表',
                'icon' => 'fa fa-table',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 100,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'id' => 3,
                'is_leaf' => 0,
                'module' => '',
                'controller' => '',
                'action' => '',
                'title' => '系统设置',
                'icon' => 'fa fa-gear',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 999,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'pid' => 3,
                'is_leaf' => 1,
                'module' => 'td',
                'controller' => 'config',
                'action' => 'index',
                'title' => '站点设置',
                'icon' => 'fa fa-circle-o',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 999,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'pid' => 3,
                'is_leaf' => 1,
                'module' => 'td',
                'controller' => 'menu',
                'action' => 'index',
                'title' => '菜单设置',
                'icon' => 'fa fa-th-list',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 10,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'pid' => 3,
                'is_leaf' => 1,
                'module' => 'td',
                'controller' => 'user',
                'action' => 'index',
                'title' => '后台用户',
                'icon' => 'fa fa-address-book',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 20,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
            [
                'pid' => 3,
                'is_leaf' => 1,
                'module' => 'td',
                'controller' => 'role',
                'action' => 'index',
                'title' => '角色管理',
                'icon' => 'fa fa-users',
                'type' => 'action',
                'grouping' => 'admin',
                'sorting' => 30,
                'create_time' => date('Y-m-d H:i:s'),
                'update_time' => date('Y-m-d H:i:s'),
            ],
        ];

        $table = $this->table('menu');
        $table->insert($data)->save();
    }
}