<?php

use think\migration\Migrator;
use think\migration\db\Column;

class Config extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('config', ['collation' => 'utf8mb4_general_ci', 'comment' => '配置']);
        $table->addColumn('key', 'string', ['limit' => 64, 'comment' => '键'])
            ->addColumn('val', 'string', ['limit' => 4000, 'comment' => '值'])
            ->addColumn('sorting', 'integer', ['default' => 100, 'comment' => '排序'])
            ->addColumn('grouping', 'string', ['limit' => 128, 'null' => true, 'comment' => '分组'])
            ->addColumn('remark', 'string', ['limit' => 256, 'null' => true, 'comment' => '说明'])
            ->addColumn('format', 'string', ['limit' => 256, 'default' => 'string', 'comment' => '数据格式|验证正则: int,float,string,datetime'])
            ->addColumn('help_text', 'string', ['limit' => 512, 'null' => true, 'comment' => '字段说明'])
            ->addColumn('delete_time', 'datetime', ['null' => true, 'comment' => '删除时间'])
            ->addColumn('create_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP', 'comment' => '创建时间'])
            ->addColumn('update_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP','comment' => '修改时间']);
        $table->addIndex(['key'], ['unique' => true]);
        $table->create();
    }
}
