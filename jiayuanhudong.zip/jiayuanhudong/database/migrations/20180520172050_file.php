<?php

use think\migration\Migrator;
use think\migration\db\Column;

class File extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('file', ['collation' => 'utf8mb4_general_ci', 'comment' => '文件表']);
        $table->addColumn('name', 'string', ['limit' => 256, 'null' => true, 'comment' => '显示名称'])
            ->addColumn('file_name', 'string', ['limit' => 256, 'comment' => '文件名，包含后缀'])
            ->addColumn('file_ext', 'string', ['limit' => 64, 'null' => true, 'comment' => '文件后缀'])
            ->addColumn('file_path', 'string', ['limit' => 512, 'null' => true, 'comment' => '文件相对url路径'])
            ->addColumn('file_size', 'integer', ['comment' => '文件大小'])
            ->addColumn('category', 'string', ['limit' => 64, 'default' => 'default', 'comment' => '文件分类'])
            ->addColumn('upload_by', 'integer', ['null' => true, 'comment' => '上传用户uid'])
            ->addColumn('sha1', 'string', ['null' => true, 'limit' => 64, 'comment' => 'sha1值'])
            ->addColumn('is_public', 'boolean', ['default' => 0, 'comment' => '是否能公开访问'])
            ->addColumn('ext_url', 'string', ['limit' => 512, 'null' => true, 'comment' => 'mime类型'])
            ->addColumn('mime_type', 'string', ['limit' => 64, 'comment' => 'mime类型'])
            ->addColumn('media_type', 'string', ['limit' => 64, 'default'=> 'file', 'comment' => '文件类型,video,image,txt,file'])
            ->addColumn('delete_time', 'datetime', ['null' => true,'comment' => '删除时间'])
            ->addColumn('create_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP', 'comment' => '创建时间'])
            ->addColumn('update_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP','comment' => '修改时间']);
        $table->addIndex(['sha1'], ['unique' => true]);
        $table->create();
    }
}
