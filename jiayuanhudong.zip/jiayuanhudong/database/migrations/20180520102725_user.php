<?php

use think\migration\Migrator;
use think\migration\db\Column;

class User extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('user', ['collation' => 'utf8mb4_general_ci', 'comment' => '用户表']);
        $table->addColumn('username', 'string', ['limit' => 64, 'comment' => '用户名'])
            ->addColumn('password', 'string', ['limit' => 256, 'comment' => '用户密码'])
            ->addColumn('withdraw_pwd', 'string', ['limit' => 256, 'null' => true, 'comment' => '提现密码'])
            ->addColumn('nickname', 'string', ['limit' => 64, 'default' => '', 'comment' => '用户昵称'])
            ->addColumn('photo_fid', 'integer', ['null' => true, 'comment' => '头像文件id'])
            ->addColumn('photo_url', 'string', ['null' => true, 'limit' => 256,'comment' => '头像文件url'])
            ->addColumn('tel', 'string', ['limit' => 64, 'null' => true, 'comment' => '电话号码'])
            ->addColumn('is_staff', 'boolean', ['default' => 0, 'comment' => '是否后台用户'])
            ->addColumn('wx_openid', 'string', ['limit' => 128, 'null' => true, 'comment' => '微信open id'])
            ->addColumn('birthday', 'date', ['null' => true, 'comment' => '生日'])
            ->addColumn('gender', 'integer', ['null' => true, 'comment' => '性别1:男,2:女'])
            ->addColumn('bio', 'string', ['null' => true,'limit' => 2000, 'comment' => '个人签名'])
            ->addColumn('qrcode_url', 'integer', ['null' => true, 'comment' => '二维码地址'])
            ->addColumn('province', 'integer', ['null' => true, 'comment' => '省代码'])
            ->addColumn('city', 'integer', ['null' => true, 'comment' => '市代码'])
            ->addColumn('county', 'integer', ['null' => true, 'comment' => '区代码'])
            ->addColumn('last_login_ip', 'biginteger', ['limit' => 11, 'null' => true, 'comment' => '最后登录IP'])
            ->addColumn('last_login_time', 'datetime', ['null' => true, 'comment' => '最后登录时间'])
            ->addColumn('enable', 'integer', ['default' => 1, 'comment' => '是否启用'])
            ->addColumn('ext', 'json', ['null' => true, 'comment' => '存储json数据'])
            ->addColumn('delete_time', 'datetime', ['null' => true, 'comment' => '删除时间'])
            ->addColumn('create_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP', 'comment' => '创建时间'])
            ->addColumn('update_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP','comment' => '修改时间']);
        $table->addIndex(['username'], ['unique' => true]);
        $table->addIndex(['wx_openid'], ['unique' => true]);
        $table->create();

    }
}
