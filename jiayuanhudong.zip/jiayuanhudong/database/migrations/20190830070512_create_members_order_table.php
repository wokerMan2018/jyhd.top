<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateMembersOrderTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
//    public function change()
//    {
//
//    }
    public function up()
    {
        if (!$this->hasTable('members_order')) {
            $table = $this->table('members_order', ['collation' => 'utf8mb4_general_ci', 'comment' => '会员充值订单表']);
            $table->addColumn('order_num', 'string', ['limit' => 256, 'null' => true, 'comment' => '订单号'])
                ->addColumn('uid', 'integer', ['limit' => 11, 'null' => true, 'comment' => '用户id'])
                ->addColumn('total_price', 'decimal', ['precision' => 10, 'scale' => 5, 'null' => true, 'comment' => '实际支付'])
                ->addColumn('reduce_integer', 'integer', ['limit' => 11, 'null' => true, 'comment' => '消耗积分数量'])
                ->addColumn('wx_openid', 'string', ['limit' => 256, 'null' => true, 'comment' => '微信openid'])
                ->addColumn('order_status', 'integer', ['limit' => 4, 'null' => true, 'comment' => '订单状态 0为取消， 10代付款， 20为已付款'])
                ->addColumn('pay_type', 'integer', ['limit' => 4, 'null' => true, 'comment' => '支付类型 1为微信支付'])
                ->addColumn('pay_time', 'datetime', ['null' => true, 'comment' => '支付时间'])
                ->addColumn('members_type', 'integer', ['limit' => 4, 'null' => true, 'comment' => '会员类型， 1为月卡 2 为季卡 3为年卡'])
                ->addColumn('transaction_id', 'string', ['limit' => 256, 'null' => true, 'comment' => '交易id'])
                ->addColumn('order_info', 'string', ['limit' => 256, 'null' => true, 'comment' => '订单说明'])
                ->addColumn('delete_time', 'datetime', ['null' => true])
                ->addColumn('create_time', 'datetime', ['null' => true])
                ->addColumn('update_time', 'datetime', ['null' => true])
                ->create();
        }
    }

    public function down()
    {
        if ($this->hasTable('members_order')) {
            $this->dropTable('members_order');
        }
    }
}
