<?php

use think\migration\Migrator;
use think\migration\db\Column;

class Menu extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('menu', ['collation' => 'utf8mb4_general_ci', 'comment' => '后台菜单']);
        $table->addColumn('pid', 'integer', ['null' => true, 'comment' => '上级id'])
            ->addColumn('is_leaf', 'integer', ['default' => 1, 'comment' => '是否叶子节点'])
            ->addColumn('module', 'string', ['limit' => 64, 'null' => true, 'comment' => '所属应用'])
            ->addColumn('controller', 'string', ['limit' => 64, 'null' => true, 'comment' => '控制器'])
            ->addColumn('action', 'string', ['limit' => 64, 'null' => true, 'comment' => '方法'])
            ->addColumn('params', 'string', ['limit' => 256, 'null' => true, 'comment' => '参数'])
            ->addColumn('title', 'string', ['limit' => 64, 'default' => '', 'comment' => '标题'])
            ->addColumn('icon', 'string', ['limit' => 32, 'default' => 'fa fa-circle-o', 'null' => true, 'comment' => 'icon class'])
            ->addColumn('type', 'string', ['limit' => 32, 'default' => 'action', 'comment' => '链接类型:action, page, ext_url'])
            ->addColumn('ext_url', 'string', ['limit' => 256, 'null' => true, 'comment' => '外部链接地址'])
            ->addColumn('target', 'string', ['limit' => 32, 'null' => true, 'comment' => '打开方式'])
            ->addColumn('enable', 'integer', ['default' => 1, 'comment' => '是否可见'])
            ->addColumn('grouping', 'string', ['limit' => 32, 'null' => true, 'comment' => '分组'])
            ->addColumn('sorting', 'integer', ['default' => 100, 'comment' => '排序'])
            ->addColumn('delete_time', 'datetime', ['null' => true, 'comment' => '删除时间'])
            ->addColumn('create_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP', 'comment' => '创建时间'])
            ->addColumn('update_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP','comment' => '修改时间']);
        $table->create();
    }
}
