<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateVideoTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('video', ['collation' => 'utf8mb4_general_ci', 'comment' => '视频解析表']);
        $table->addColumn('title', 'string', array('limit' => 256, 'null' => true, 'comment' => '视频标题'))
            ->addColumn('upload_type', 'integer', array('limit' => 4, 'null' => true, 'comment' => '上传类型'))
            ->addColumn('video_url', 'string', array('limit' => 1024, 'null' => true, 'comment' => '视频链接'))
            ->addColumn('watch_num', 'integer', array('limit' => 11, 'null' => true, 'comment' => '观看数'))
            ->addColumn('like_num', 'integer', array('limit' => 11, 'null' => true, 'comment' => '点赞数'))
            ->addColumn('comment_num', 'integer', array('limit'=>11, 'null'=> true, 'comment'=> '评论数'))
            ->addColumn('video_introduction', 'text', array('null' => true, 'comment' => '商品简介'))
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->create();
    }
}
