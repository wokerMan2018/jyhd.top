<?php

use think\migration\Migrator;
use think\migration\db\Column;

class Page extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('page', ['collation' => 'utf8mb4_general_ci', 'comment' => '页面表']);
        $table->addColumn('title', 'string', ['limit' => 512, 'comment' => '标题'])
            ->addColumn('photo_id', 'integer', ['null' => true, 'comment' => '封面照片id'])
            ->addColumn('link_name', 'text', ['limit' => 64,  'comment' => '链接名称'])
            ->addColumn('content', 'text', ['comment' => '内容'])
            ->addColumn('slug', 'string', ['null' => true, 'limit' => 128, 'comment' => '短连接, 唯一'])
            ->addColumn('grouping', 'string', ['limit' => 32, 'null' => true, 'comment' => '分组'])
            ->addColumn('sorting', 'integer', ['default' => 100, 'comment' => '排序'])
            ->addColumn('delete_time', 'datetime', ['null' => true, 'comment' => '删除时间'])
            ->addColumn('create_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP', 'comment' => '创建时间'])
            ->addColumn('update_time', 'datetime', ['default'=> 'CURRENT_TIMESTAMP','comment' => '修改时间']);
        $table->addIndex(['slug'], ['unique' => true]);
        $table->create();
    }
}
