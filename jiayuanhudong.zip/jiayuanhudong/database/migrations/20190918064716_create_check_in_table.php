<?php

use think\migration\Migrator;
use think\migration\db\Column;

class CreateCheckInTable extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
//    public function change()
//    {
//
//    }
    public function down()
    {
        if ($this->hasTable('check_in')) {
            $this->dropTable('check_in');
        }
    }

    public function up()
    {
        if (!$this->hasTable('check_in')) {
            $table = $this->table('check_in', ['collation' => 'utf8mb4_general_ci', 'comment' => '签到记录表']);
            $table->addColumn(Column::integer('uid')->setNullable()->setComment('签到用户id'))
                ->addColumn(Column::tinyInteger('number')->setNullable()->setComment('连续签到'))
                ->addColumn(Column::dateTime('created_at')->setNullable()->setComment('签到时间'))
                ->create();
        }
    }
}
